// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <algorithm>
#include <vector>
using namespace Rcpp;
using namespace std;
using namespace arma;
// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//


// [[Rcpp::plugins(cpp11)]]
std::vector<int> torus_sftxC(std::vector<int> x, int ylim) {

  //std::vector<int> x;
  //auto it = std::find(x.begin(), x.end(), splitElement);
  //IntegerVector z(x);
  //std::vector<int> z = Rcpp::as<std::vector<int> >(x);
  //auto it = x.begin()+ylim;
  std::vector<int>::iterator it = x.begin()+ylim;

  std::rotate(x.begin(), it, x.end());
  return x;
}

// [[Rcpp::export]]
IntegerVector torus_sftx(SEXP x, int ylim) {

  IntegerVector xi(x);
  std::vector<int> out = torus_sftxC(Rcpp::as<std::vector<int> >(xi),ylim);
  return wrap(out);
}

std::vector<int> torus_sftyC(std::vector<int> x, int ylim) {

  //IntegerVector xi(x);
  //std::vector<int> z = Rcpp::as<std::vector<int> >(xi);

  int blksz = floor(x.size()/ylim);
  std::vector<int>::reverse_iterator it = x.rbegin()+ylim;
  for (int j = 0; j < blksz; j++) {
    std::rotate(it-ylim, it-ylim+1, it);
    it = min(it + ylim, x.rend());
  }

  return x;
}

// [[Rcpp::export]]
IntegerVector torus_sfty(SEXP x, int ylim) {

  IntegerVector xi(x);
  std::vector<int> out = torus_sftyC(Rcpp::as<std::vector<int> >(xi),ylim);
  return wrap(out);
}

std::vector<int> torus_mirrxC(std::vector<int> x, int ylim) {

  //IntegerVector xi(x);
  //std::vector<int> z = Rcpp::as<std::vector<int> >(xi);

  int blksz = floor(x.size()/ylim/2);
  std::vector<int>::iterator it = x.begin()+ylim;
  std::vector<int>::iterator rit = x.end()-ylim;
  //std::vector<int>::reverse_iterator rit = z.rbegin()+ylim;
  for (int j = 0; j < blksz; j++) {
    std::transform(it-ylim, it,
                   rit,
                   it-ylim,
                   [](int& x, int& y)
                   {
                     std::swap(x, y);
                     return x;
                   });
    it = it + ylim;
    rit= rit- ylim;
  }

  return x;
}

// [[Rcpp::export]]
IntegerVector torus_mirrx(SEXP x, int ylim) {

  IntegerVector xi(x);
  std::vector<int> out = torus_mirrxC(Rcpp::as<std::vector<int> >(xi),ylim);
  return wrap(out);
}


//# include <iostream> // debug only
std::vector<int> torus_rotateC(std::vector<int> x, int ylim) {

  //IntegerVector xi(x);
  std::vector<int> z;
  arma::uvec zi = conv_to<uvec>::from(x); //x.begin(), x.size(), false);
  int segsz, segblk, seglim;

  int blksz = floor(x.size()/ylim);

  // Special cases: if ylim(transect length) < transect(blk) num, we need to transpose -> swap(rotate) -> transpose again
  if (blksz > ylim) {
    //arma::mat M = mat(ylim, blksz); //Rcpp::as<arma::mat>(m);   // normal matrix
    //std::cout << "blksz = " << blksz << "; "; //debug only
    //zi = Rcpp::as<arma::uvec>(x);  // unsigned int vec
    arma::umat Mz(&zi[0],ylim, blksz);
    z= arma::conv_to< std::vector<int> >::from(vectorise(Mz.t()));  // index matrix by vec, 1st transpose
    //for (int m =  xi.size()- 1; m >= 0; m--) //debug only
    //  cout << z[m] << " ";

    //z= arma::conv_to< std::vector<int> >::from(vectorise(M.cols(zi).t()));  // index matrix by vec, 1st transpose
    segsz = floor(blksz/ylim);
    segblk= ylim;
    seglim= blksz;
    //return Rcpp::wrap(Mt);
  } else {
    z = x; //Rcpp::as<std::vector<int> >(xi);
    segsz = floor(ylim/blksz);
    segblk= blksz;
    seglim= ylim;
  }
  // for debug only
  //std::cout << "segsz = " << segsz << "; ";
  //std::cout << "segblk = " << segblk << "; ";
  //std::cout << "seglim = " << seglim << endl;
  //for (auto k = z.begin(); k != z.end(); ++k)
  //  std::cout << *k << " ";
  //cout << endl;

  std::vector<int>::iterator xit,yit;
// swapping
  for (int i = 0; i < (segblk-1); i++) {
    yit = z.begin()+i*seglim+(i+1)*segsz;
    xit = z.begin()+(i+1)*seglim+i*segsz;

    for (int j = 1; j < (segblk-i); j++) {
      std::transform(yit, yit+segsz,
                     xit,
                     yit,
                     [](int& x, int& y)
                     {
                       std::swap(x, y);
                       return x;
                     });
      yit = yit + segsz;
      xit = xit + seglim;
      //debug only
      //std::cout << "j = " << j << "; ";
      //std::cout << "i = " << i << "; ";
      //std::cout << "yit = " << yit-z.begin() << "; ";
      //std::cout << "xit = " << xit-z.begin() << endl;
    }
  }

  if (blksz > ylim) {
    zi = conv_to<uvec>::from(z);
    arma::umat Mt(&zi[0],blksz,ylim); //(&z.front()),blksz,ylim);// = mat(blksz, ylim);

    z = arma::conv_to< std::vector<int> >::from(vectorise(Mt.t())); //.cols(Rcpp::as<arma::uvec>(z)).t()));  // 2nd transpose
    //return wrap(zt);
  } //else {

  return z;
  //}
}

// [[Rcpp::export]]
IntegerVector torus_rotate(SEXP x, int ylim) {

  IntegerVector xi(x);
  std::vector<int> out = torus_rotateC(Rcpp::as<std::vector<int> >(xi),ylim);
  return wrap(out);
}

// Not easily to take care index-0(cpp) or index-1(R) problems: causing Crash..
//# include <iostream>
/*
arma::umat torus_indexC (int xlim, int ylim) {

  int L = xlim*ylim;
  arma::umat tr(L, 4*L, fill::zeros);

  //uvec tt = linspace<uvec>(1, L, L);
  //for (int m =  tt.size()- 1; m >= 0; m--) //debug only
  //cout << tt[m] << " ";

  tr.col(0)=linspace<uvec>(1, L, L);
  std::vector<int> ori(L);
  std::iota(std::begin(ori), std::end(ori), 1); // Fill with 1:L
  //for (int m =  L- 1; m >= 0; m--) //debug only
    //cout << ori[m] << " ";

  std::vector<int> idx = ori;//arma::conv_to< std::vector<int> >::from(tr.col(0));
  //std::vector<int> ori = idx;

  for (int i=1; i<2; i++) { //i<4*L; i++) {
    if ((i%L)==0) {
      idx = ori;//arma::conv_to< std::vector<int> >::from(tr.col(0));
      if (i/L==3) {
        idx = torus_mirrxC(idx, ylim);
        idx = torus_rotateC(idx, ylim);
      } else if (i/L==2) {
        idx = torus_mirrxC(idx, ylim);
      } else if (i/L==1) {
        idx = torus_rotateC(idx, ylim);
      }
    } else if (i%ylim==0) {
      idx = torus_sftyC(idx, ylim); // back to former start
      idx = torus_sftxC(idx, ylim); // then shift x+1
    } else {
      idx = torus_sftyC(idx, ylim);
    }
    for (int m =  L- 1; m >= 0; m--) //debug only
      cout << idx[m] << " ";

    tr.col(i)=arma::conv_to<uvec>::from(idx);

    //for (int m =  L- 1; m >= 0; m--) //debug only
    //  cout << tr.col(i)[m] << " ";

  }

  return tr;
}

IntegerMatrix torus_index4L (int xlim, int ylim) {

  arma::mat out = arma::conv_to<arma::mat>::from(torus_indexC(xlim, ylim));

  return Rcpp::wrap(out);
}
*/

// You can include R code blocks in C++ files processed with sourceCpp
// (useful for testing and development). The R code will be automatically
// run after the compilation.
//

///*** R
//timesTwo(42)
//*/
