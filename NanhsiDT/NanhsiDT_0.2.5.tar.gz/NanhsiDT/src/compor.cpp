// Original code provided by Celestialgod: http://pastebin.com/HthDsLnz
// Original version is "outer_join2" by cywhale, but then modified to faster version by Celestialgod
// Discussion issued by cywhale: https://goo.gl/IATVOo

// #include <Rcpp.h>
// using namespace Rcpp;

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <Rcpp.h>
#include <string>
#include <vector>
#include <algorithm>
using namespace Rcpp;
using namespace std;
using namespace arma;

// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::export]]
NumericVector vadd_narm(SEXP x, SEXP y){
  NumericVector xr(x);
  NumericVector yr(y);
  colvec xt(xr.begin(), xr.size(), false);
  colvec yt(yr.begin(), yr.size(), false);
  uvec loc_na_x = find_nonfinite(xt);
  uvec loc_na_y = find_nonfinite(yt);
  //colvec z = x + y;
  vector<uword> loc_na_std;
  set_intersection(loc_na_x.begin(), loc_na_x.end(),
                   loc_na_y.begin(), loc_na_y.end(),
                   back_inserter(loc_na_std));
  uvec loc_na = conv_to<uvec>::from(loc_na_std);
  xt.elem(loc_na_x).zeros();
  yt.elem(loc_na_y).zeros();
  colvec z = xt + yt;
  z.elem(loc_na).fill(NA_REAL);
  Rcpp::NumericVector out=Rcpp::wrap(z);
  out.attr("dim") = R_NilValue;
  return out;
}

// [[Rcpp::export]]
NumericVector row2col(SEXP x) {
  NumericVector xr(x);
  colvec xt(xr.begin(), xr.size(), false);
  colvec z = xt;
  return wrap(z);
}

// [[Rcpp::export]]
DataFrame ladd_by_cols(List dfs){
  DataFrame out(dfs[0]);
  vector<string> df_names = out.names();
  for (int i = 1; i < dfs.length(); i++)
  {
    DataFrame tmp(dfs[i]);
    vector<string> tmp_names = tmp.names();
    for (int j = 1; j < tmp.length(); j++)
    {
      if (find(df_names.begin(), df_names.end(), tmp_names[j]) != df_names.end())
        out[tmp_names[j]] = vadd_narm(out[tmp_names[j]], tmp[tmp_names[j]]);
      else
      {
        out.push_back(tmp[tmp_names[j]], tmp_names[j]);
        df_names.push_back(tmp_names[j]);
        //out[tmp_names[j]] = row2col(out[tmp_names[j]]);
      }
    }
  }
  return wrap(out);
}

/* Not faster than x[is.na(x)] = 0, so not export
// [[Rcpp::export]]
NumericMatrix mat_nafillC(arma::mat x) {

  arma::mat out(x);
  out.elem(find_nonfinite(out)).zeros();

  return wrap(out);
}
*/

// [[Rcpp::export]]
NumericMatrix randmatC(int xdim, int ydim) { //, unsigned int seed) {
/*
  if (is_finite(seed)) {
    arma::arma_rng::set_seed(seed);
  } else {
    arma::arma_rng::set_seed_random();
  }
*/ //  When called from R, the RNG seed has to be set at the R level via set.seed()

  arma::mat out = randu<mat>(xdim, ydim);
  return wrap(out);
}

// [[Rcpp::export]]
NumericMatrix sweep_rowsumC(arma::mat x) {

  arma::mat out(x);
  out.elem(find_nonfinite(out)).zeros();
  arma::colvec rs = arma::sum(out, 1); // dim = 0: colSum, dim = 1: rowSum
  out.each_col() /= rs;
  return wrap(out);
}

// To replace 'vegan::diversity',reduce pkg dependency and speed-up. Test version in test_base_func01.R
// default index 0: shannon (H), 1: simpson (D), 2: invsimpson (N2), 3: species number (S)
// 4 : HillN1 (N1), where N1 = exp(div$H); Evenness based on Hill's number Ev= (div$N2-1)/(div$N1-1), not implemented
// [[Rcpp::export]]
NumericVector diverC(arma::mat x, int index=0) {
  //int n = x.n_rows;
  //int xdim = x.n_cols;

  arma::mat dx(x);
  arma::colvec dvx;

  if (index==3) {
    dx.for_each([](mat::elem_type& val) {if(is_finite(val) && val>0) val = 1.0; else val = 0.0;} );
    dvx = arma::sum(dx, 1); // dim = 0: colSum, dim = 1: rowSum
  } else {
    dx.elem(find_nonfinite(dx)).zeros();
    dvx = arma::sum(dx, 1); // dim = 0: colSum, dim = 1: rowSum
    dx.each_col() /= dvx;

    if (index==0 || index==4) { // 1:simpson
      //arma::mat out = -dx % log(dx);
      //out.elem(find_nonfinite(out)).zeros();
      dx.for_each([](mat::elem_type& val) {if(val>0) val *= -log(val); else val = 0.0;} );
    } else {
      dx.for_each([](mat::elem_type& val) {val *= val;} );
    }

    dvx = arma::sum(dx, 1);
    if (index==1) { // 1:simpson
      dvx.for_each([](colvec::elem_type& val) {val = 1 - val;});
    } else if (index==2) { //2:invsimpson
      dvx.for_each([](colvec::elem_type& val) {val = 1/val;});
    } else if (index==4) { //4:N1
      dvx.for_each([](colvec::elem_type& val) {val = exp(val);});
    }
  }
  Rcpp::NumericVector out = wrap(dvx);
  out.attr( "dim" ) = R_NilValue; // output vector, not matrix
  return out;
}

/* old version, combined with diverC
NumericVector spnumC(arma::mat x) {

  arma::mat out(x);
  out.for_each([](mat::elem_type& val) {if(is_finite(val) && val>0) val = 1.0; else val = 0.0;} );
  arma::colvec rs = arma::sum(out, 1); // dim = 0: colSum, dim = 1: rowSum

  return(wrap(rs));
}
*/

// You can include R code blocks in C++ files processed with sourceCpp
// (useful for testing and development). The R code will be automatically
// run after the compilation.
//

///*** R
//timesTwo(42)
//*/
