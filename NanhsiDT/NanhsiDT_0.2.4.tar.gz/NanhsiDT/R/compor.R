#' NanhsiDT: A package includes raw dataset in Nanhsi Forest Dynamics Plot in Taiwan, and utilities to do specific data manipulation
#'
#' The NanhsiDT package provides datasets including tree, seedling, and understory species assemblages
#' Temporarily, this is only a trial-version, providing some funtions to manipulate composition(site-variable) data
#'
#' @section NanhsiDT functions:
#' vadd
#' ladd_merge
#' sweepM_rsum
#' vsp_dividx
#' diverT_Nanhsi
#' shuffleM_idx
#' torusM_idx
#' quadDT_cov
#' quadArea_weight
#' pt_NanhsiBA
#' ppp_NanhsiTree
#' testMEM
#' testResid
#'
#' @docType package
#' @name NanhsiDT
NULL

#' @useDynLib NanhsiDT
#' @importFrom Rcpp sourceCpp
#' @importFrom spatstat ppp marks owin
NULL

#' Merge dataframes in list by one column with key index and summing other common variables.
#'
#' Original code provided by Celestialgod (modified by cywhale to only data.table, purrr needed):
#' \url{http://pastebin.com/HthDsLnz}
#' Original version is 'outer_join2' by cywhale, but then modified to faster version by Celestialgod
#' Discussion issued by cywhale:
#' \url{https://goo.gl/IATVOo}

#' @param data A list includes all dataframes or data.tables in r which needed to be merged.
#' @param y A string indicated one colname existed in all dataframes in list.
#' @return The merged data.table.
#' @examples
#' ladd_merge(list(x,y,z,...), 'species')
#' @export
ladd_merge <- function(data, by) {
  overall_keys <- data %>% map(~.[,by,with=FALSE]) %>% rbindlist %>% unique
  ladd_by_cols(data %>% map(~merge(., overall_keys, by = by, all = TRUE))) %>% data.table()
}

idxfun <- function(x,v) {v[x]}

#' Shuffle vector by randomization index (without replacement) with reproducible seed
#'
#' @param x A numeric vector to be shuffled by randomizing its index
#' @param B An integer: numbers of randomization
#' @param seed An integer indicate reproducible randomization, default: NULL (non-reproducible)
#' @param index_only A boolean value indicate whether or not to return randomized index only, otherwise return shuffled results of \code{x}
#' @param keep_origin A boolean value indicate whether or not to keep original \code{x} in first column of returned matrix
#' @return A numeric matrix \code{length(x) * times}, includes all shuffled vector results
#' @examples
#' shuffleM_idx(x)
#' @rdname shuffleM_idx
#' @export
shuffleM_idx <- function(x, B = 1000, seed = NULL, keep_origin = TRUE, index_only = FALSE) {

  set.seed(seed)

  dx <- data.table(randmatC(length(x),B)) %>%
    .[,lapply(.SD,rank), .SDcols = c(1:B)]

  if (!index_only) {
    dx %<>% .[,lapply(.SD,idxfun,v=x), .SDcols = c(1:B)]
  }

  dx %<>% as.matrix()

  if (keep_origin) {
    if (index_only) {
      dx[,1] <- c(1:length(x))
    } else {
      dx[,1] <- x
    }
  }

  return(dx)
}

#' Sweep rows in composition data by dividing row sum to get relative value/abundance
#'
#' @seealso Rcpp version to do things like: \code{apply(x, 1, sum)} and pipe into \code{sweep(x, 1, ., "/")}
#' @param x A numeric matrix, usually composition data (species in columns, observation in rows)
#' @return A numeric matrix with relative value/abundance which normalized by row sum.
#' @examples
#' sweepM_rsum(x)
#' @rdname sweepM_rsum
#' @export
sweepM_rsum <- sweep_rowsumC

#' add two vector with na.rm=TRUE.
#'
#' @seealso \code{\link{ladd_merge}} documents which have provide original issue and code url
#' @param x A numeric vector.
#' @param y A numeric vector.
#' @return The sum of \code{x} and \code{y} with missing values(NA) have no effects.
#' @examples
#' vadd(c(0,1,NA,NA,NA,4,NA),c(NA,2,3,NA,NA,NA,NA))
#' vadd(x$V1, y$V1) if x, y are dataframes with the same rows.
#' @rdname vadd
#' @export
vadd <- vadd_narm


#' Diversity (shannon, simpson, invsimpson, species number) of species matrix
#'
#' @param x A (row-)vector, matrix or dataframe with species in columns, observations in rows.
#' @param index A character string indicate diversity index: "shannon", "simpson", "invsimpson", "spnum", "HillN1".
#' @return A numeric vector returned species diversity of each observations.
#' @examples
#' vsp_dividx(data,'shannon')
#' @rdname vsp_dividx
#' @export
vsp_dividx <- function (x, index, use_names=c(), ...) { ##... to replace 'vegan::diversity' but some parameters fixed
  INDICES <- c("shannon", "simpson", "invsimpson", "spnum", "HillN1")
  idx <- which(INDICES == match.arg(index, INDICES))[1]-1

  if (is.matrix(x)) {
    out <- diverC(x,idx)
  } else if (is.vector(x)) {
    out <- diverC(matrix(x, 1, length(x)),idx)
  } else if (is.data.frame(x)) {
    out <- diverC(as.matrix(x),idx)
  } else {
    stop("Type error of x in spdivM: must be a vector, matrix, dataframe or data.table")
  }
  if (length(use_names)>0) {
    names(out) <- use_names
  }

  return(out)

  #} else if (is.data.table(x)) {
    #if (haskey(x)) {
    #  out <- divfun(as.matrix(x[,-c(key(x)),with=FALSE]),idx)
    #  names(out) <- names(x)[!(names(x) %in% key(x))]
    #} else {
    #  out <- divfun(as.matrix(x),idx)
    #  names(out) <- names(x)
    #}
    #return(out)
}

#' Query Nanhsi tree species diversity index (or other survey data)
#' @param data A data.frame to indicate survey data (must have columns: tplot, spcode, DBH), default (no assigning) use tree survey 2006 in Nanhsi plot
#' @param index A character string indicate diversity index: "shannon", "simpson", "invsimpson", "spnum", "HillN1".
#' @param stage A character vector to specify which life-history of trees will be included in evaluation, data should include 'layer' variable.
#'   \describe{
#'     \item{'all'}{Includes all stages}
#'     \item{'adult'}{Includes only overstory (layer!='S') or DBH>=5 cm}
#'     \item{'shrub'}{Includes only shrub layer: S and DBH<5 cm}
#'   }
#' @param site A character vector to specify which name of sampling site/subplot.. will be used as per unit when caculating diversity
#'    \describe{
#'     \item{'tplot'}{default 10 m x 10 m site in Nanhsi plot}
#'     \item{'subplot'}{5 m x 5 m subplot in Nanhsi plot}
#'   }
#' @return A numeric vector returned species diversity of each observations, the same as call function vsp_dividx
#' @examples
#' diverT_Nanhsi(index="HillN1")
#' @rdname diverT_Nanhsi
#' @export
diverT_Nanhsi <- function(index, data=data.frame(), stage="all", site="tplot") {
  #data(spdt)
  if (nrow(data)==0) {
    xtree <- compo_tree_sp06[,.(tplot, subx, suby, spcode,main_cir,sprout_ba,layer)] %>%
      #merge(spdt[,.(spcode, family)],by="spcode",all.x=TRUE) %>%
      .[,':='(DBH=main_cir/pi, BA=pi*(main_cir/(200*pi))^2)] %>%
      #.[,.(tplot,spcode,DBH)] %>%
      .[,BA:=ifelse(layer=="S",BA + sprout_ba/10000, BA)] #%>%
      #.[,.(tplot,spcode,BA)]

    if (site=="subplot") {
      xtree[,site:=paste(subx,suby,sep="_")]
    } else {
      setnames(xtree,1,"site")
    }

  } else {
    if (!is.data.table(data)) {
      xtree <- data %>% data.table() %>%
        .[,BA:= pi*(DBH/200)^2] %>%
        #.[,.(tplot,spcode,BA)]
        setnames(match(site, colnames(.)),"site")
    }
  }
  if ("layer" %in% colnames(xtree) & tolower(stage)!='all') {
    if (tolower(stage)=='adult') {
      xtree %<>% .[layer!="S" | DBH>=5, ]
    } else if (tolower(stage)=='juven') {
      xtree %<>% .[layer=="S" & DBH<5,]
    }
  }

  xt <-  xtree[,.(site,spcode,BA)] %>% data.table::dcast(site~spcode,fun=sum,fill=0)

  return(vsp_dividx(xt[,-1,with=F], index=index, use_names=xt$site))
}

#' Toroidal permutation for indices of subplots (length L), to do shift in y, x, rotate, mirror(in x), and mirror then rotate the indices, totally 4L times.
#' @param xblk A integer indicate numbers of blocks (transects), usually in x-direction.
#' @param ycell A integer indicate numbers of subplots (quadrats or cells), usually in y-direction. Thus L = xblk * ycell
#' @return A matrix with dimension equals \code{L} * \code{4*L} with toroidal-permtated index
#' @examples
#' torusM_idx(xblk = 10, ycell = 100)
#' @rdname torusM_idx
#' @export
torusM_idx <- function (xblk = 10L, ycell = 100L) {

  L <- xblk * ycell
  out <- matrix(0, nrow=L, ncol=4*L)
  out[,1] <- seq(1:L)
  idx <- out[,1]
  for (i in 1:(4*L-1)) {
    if ((i%%L)==0)  {
      idx <- out[,1]
      if (i/L == 3) {
        idx <- torus_rotate(torus_mirrx(idx, ycell), ycell)
        #idx<- torus_rotate(idx, ycell)
      } else if (i/L == 2) {
        idx <- torus_mirrx(idx, ycell)
      } else if (i/L == 1) {
        idx <- torus_rotate(idx, ycell)
      }
    } else if (i%%ycell == 0L) {
      idx <- torus_sftx(torus_sfty(idx, ycell), ycell) ## back to former start
      #idx = torus_sftx(idx, ycell) ## then shift x+1
    } else {
      idx <- torus_sfty(idx, ycell)
    }
    out[,(i+1)] <- idx
  }
  return (out)
}

#' Sum of each individual's coverage within one quadrats
#' @param data A data table includes columns for index {e.g., transect or tag or others}, value {e.g., height}, and additive variables {e.g., coverage,...}
#' @param idvar A character vector to specify the column name of variables used as index in 'data', usually species, subplot, and etc.
#' @param measvar A character vector to specify column names of measured variables in 'data', which mean value would be returned after data "gridding" to each quadrat.
#' @param covar A character vector to specify the column name of additive variable in 'data', usually coverage, which its sum would be returned.
#' @param adjMax A boolean value indicates if sum of coverage weighted by its maximum to 0.5*(sum() + max()) or just sum()
#' @return A datatable with \code{idvar}, \code{measvar} and (adjusted or not) sum of \code{covar}.
#' @examples
#' quadDT_cov(data, "transect","height","coverage",adjMax=TRUE)
#' @rdname quadDT_cov
#' @export
quadDT_cov <- function(data, idvar, measvar, covar, adjMax=FALSE) {
  MR1<- data.table::melt(data, id = idvar, measure = covar)
  #P1 <- do.call("dcast", args = list(data = MR1, formula = paste(paste0(idvar,collapse='+'), "~ variable"), fun = quote(fcov), fill=0))
  P1 <- data.table::dcast(MR1, as.formula(paste(paste0(idvar,collapse='+'), "~ variable")),
              fun = function (..., adjMax) {
                if (adjMax) {
                  return(0.5*(sum(...,na.rm=TRUE) + max(...,na.rm=TRUE)))
                } else {
                  return(sum(...,na.rm=TRUE))
                }
              }, adjMax=adjMax, fill=0)

  MR1<- data.table::melt(data, id = idvar, measure = measvar)
  #P2<- do.call("dcast", args = list(data = MR1, formula = paste(paste0(idvar,collapse='+'), "~ variable"), fun = "mean", fill=0))
  P2 <- data.table::dcast(MR1, as.formula(paste(paste0(idvar,collapse='+'), "~ variable")), fun = mean, fill=0)
  #P2= cast(MR2, id ~ variable, mean, fill=0)

  return (P2[P1])
}

#' Weighted sum of occpied area (usually tree BA) in a circle with given radius from individual's location
#' @param loc A numeric vector indicates location (x,y) of given individual, or a given samplimg site
#' @param rng A numeric number indicates searching radius from location of given individual
#' @param biasx A numeric number indicates shifts/bias in x direction from location, usually used in shift to center of a sampling site
#' @param biasy A numeric number indicates shifts/bias in y direction from location, usually used in shift to center of a sampling site
#' @param data A data table of tree demography includes columns {x,y,spcode,DBH,sprout_ba,layer}
#'   \describe{
#'     \item{'x,y'}{Points of locations}
#'     \item{'spcode'}{Identification, usually species name}
#'     \item{'DBH'}{Diameter of the surveyed tree, will be transfered to basal area (BA) in codes by (pi*(DBH/200)^2}
#'     \item{'sprout_ba'}{BA includes BA of sprouts of the surveyed trees which are in shub_layer (layer=="S"); Regardless of sprouts just given 0}
#'     \item{'layer'}{Layer structure/Vertical stratification. C: canopy, T2: subcanopy, S: shurb layer}
#'   }
#' @param tolr A numeric number indicates tolerance in searching, working only for canopy or subcanopy trees
#' @param weighted A boolean value indicates if sum of BA weighted by reciprocal of distance from given location, or just sum()
#' @param stratum A character vector to specify which stratum of trees will be included in evaluation.
#'   \describe{
#'     \item{'all'}{Includes all layers: C, T2, S}
#'     \item{'over'}{Includes only overstory: C, T2}
#'     \item{'shrub'}{Includes only shrub layer: S}
#'     Specify 'C', 'T2', or 'S' to evaluate only one or multiple layers
#'   }
#' @param mode A character strin to specify special mode to evaluate tree BA. Default is "", normal mode.
#'   \describe{
#'     \item{'quadrat'}{Exactly evaluate tree BA in one sampling site, no weights by distance, appends columns: density}
#'   }
#' @return A numeric vector with (qx, qy, wBA): query of x, y, and sum of occpuied area in searching radius.
#' @examples
#' apply(loc,MARGIN=1,quadArea_weight,rng=7.5, biasx=1,biasy=1,data,stratum=='all')]
#' @rdname quadArea_weight
#' @export
quadArea_weight <- function(loc, rng=5, biasx=0, biasy=0, data, tolr=0.5, weighted=TRUE, stratum="all", mode="") {
  xp <- loc[[1]]
  yp <- loc[[2]]
  dt <- data[round(x-DBH/200,1)<=(xp+rng+biasx) & round(x+DBH/200,1)>=(xp-rng+biasx) &
             round(y-DBH/200,1)<=(yp+rng+biasy) & round(y+DBH/200,1)>=(yp-rng+biasy),]

  out <- dt[,dstr:=apply(dt[,.(x,y)], MARGIN=1, function(x1,x2) {sqrt((x1[1]-x2[1])^2+(x1[2]-x2[2])^2)}, x2=c(xp,yp))] %>%
    .[,c("sel","weight"):=list(
      ifelse(tolr>0 & (layer=="C"|layer=="T2"), dstr<=(rng+tolr+DBH/200), dstr<=(rng+DBH/200)),
      ifelse(weighted & dstr>1, 1/sqrt(dstr), 1)
    )]

  if (tolower(mode)=='quadrat') {
    out %<>% .[sel==TRUE, {.(
        qx = xp,
        qy = yp,
        overBA= sum(ifelse(layer=="C"|layer=="T2",pi*(DBH/200)^2, 0), na.rm=TRUE),
        shrubBA=sum(ifelse(layer=="S",pi*(DBH/200)^2 + sprout_ba/10000, 0), na.rm=TRUE),
        den = .N/(pi*(rng^2))
      )}]

    if (nrow(out)==0) {
      return(c(qx=xp, qy=yp, overBA=0, shrubBA=0, den=0))
    } else {
      return(unlist(out))
    }
  }

  if (stratum[1]=="over") {
    out %<>%  .[sel==TRUE & (layer=="C"|layer=="T2"), {.(
      qx = xp,
      qy = yp,
      wBA= sum(weight*pi*(DBH/200)^2, na.rm=TRUE)
    )}]
  } else if (stratum[1]=="shrub") {
    out %<>%  .[sel==TRUE & layer=="S", {.(
      qx = xp,
      qy = yp,
      wBA=sum(weight*(pi*(DBH/200)^2 + sprout_ba/10000), na.rm=TRUE)
    )}]
  } else if (stratum[1]=="all") {
    out %<>%  .[sel==TRUE, {.(
      qx = xp,
      qy = yp,
      wBA=sum(ifelse(layer=="S", weight*(pi*(DBH/200)^2 + sprout_ba/10000),
                     weight*pi*(DBH/200)^2), na.rm=TRUE)
    )}]
  } else {
    out %<>%  .[sel==TRUE & (layer %in% stratum), {.(
      qx = xp,
      qy = yp,
      wBA=sum(ifelse(layer=="S", weight*(pi*(DBH/200)^2 + sprout_ba/10000),
                     weight*pi*(DBH/200)^2), na.rm=TRUE)
    )}]
  }

  if (nrow(out)==0) {
    return(c(qx=xp, qy=yp, wBA=0))
  } else {
    return(unlist(out))
  }
}

#' Query Weighted sum of tree BA in Nanhsi plot, Taiwan by using function quadArea_weight
#' @param site A data.table indicates location (x,y) of sampling sites
#' @param taxon A character vector to specify which taxon/taxon groups to be included in evaluation of tree BA.
#' @param taxon_rank A character string to specify which taxonmic rank to be evaluated.
#'   \describe{
#'     \item{'spcode'}{species level, but in terms of species code, composed by 4-bit genus, and 2-bit specific epithet}
#'     \item{'spcies'}{species level, used scientific name}
#'     \item{'genus'}{genus level, only match 4-bit genus name}
#'     \item{'family'}{family level, will match any scientific name up to its family level}
#'     \item{'all'}{Including all species in Nanhsi plot}
#'   }
#' @param sppMatch A boolean value indicates whether spcode match 4-bit genus and 2-bit 'sp', such as 'machsp' means machilus spp.
#' @param data A data.frame to indicate survey data (must have columns: spcode, DBH), default (no assigning) use tree survey 2006 in Nanhsi plot
#' @param rng A numeric number indicates searching radius from given location
#' @param biasx A numeric number indicates shifts/bias in x direction from location, default NA means using internally value 1L
#' @param biasy A numeric number indicates shifts/bias in y direction from location, default NA means using internally value 1L
#' @param stratum A character vector to specify which stratum of trees will be included in evaluation.
#'   \describe{
#'     \item{'all'}{Includes all layers: C, T2, S}
#'     \item{'over'}{Includes only overstory: C, T2}
#'     \item{'shrub'}{Includes only shrub layer: S}
#'     Specify 'C', 'T2', or 'S' to evaluate only one or multiple layers
#'     Without given any strings, means using internally setup to evaluate overstory BA (C+T2, but for Pentaphylacaceae and Adoxaceae spp. also includes shrub layer)
#'   }
#' @param mode A character strin to specify special mode to evaluate tree BA. Default is "", normal mode.
#'   \describe{
#'     \item{'quadrat'}{Exactly evaluate tree BA in one sampling site, no weights by distance, appends columns: density}
#'   }
#' @param ... Parameters used in function quadArea_weight, but data is fixed to tree demography in Nanhsi, 2006
#' @return A numeric matix with weighted BA (rows in order of site, and columns in order of taxon).
#' @examples
#' pt_NanhsiBA(site, taxon=c("Litsea acuminata","machsp","Fagaceae"), taxon_rank="family", rng=7.5)
#' @rdname pt_NanhsiBA
#' @export
pt_NanhsiBA <- function(site, taxon, taxon_rank="spcode", sppMatch=TRUE, data=data.frame(),
                        rng=10, biasx=NA_real_, biasy=NA_real_, stratum=c(), mode="", ...) {
  data(spdt)
  if (nrow(data)==0) {
    xtree <- compo_tree_sp06[,.(x,y,spcode,species,main_cir,sprout_ba,layer)] %>%
      merge(spdt[,.(spcode, family)],by="spcode",all.x=TRUE) %>%
      .[,DBH:= main_cir/pi]
  } else {
    if (!is.data.table(data)) {
      setDT(data)
    }
    xtree <- merge(data, spdt[,.(spcode, family)],by="spcode",all.x=TRUE)
  }

  taxon_rank <- tolower(taxon_rank)
  if (taxon_rank=="all" | tolower(mode)=="quadrat") {
    tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,quadArea_weight,rng=rng,
                                      biasx=ifelse(is.na(biasx),1L,biasx),
                                      biasy=ifelse(is.na(biasy),1L,biasy),
                                      data=xtree[,.(x,y,spcode,family,DBH,sprout_ba,layer)],
                                      stratum=ifelse(length(stratum)==0,'over',stratum),
                                      mode=mode, ...)] %>% t()
    if (tolower(mode)!="quadrat") {
      tt1 <- matrix(tt1[,3])
      colnames(tt1)[1] <- ifelse(length(stratum)==0,'overBA',paste0(paste(stratum,collapse="_"),'BA'))
    } else {
      tt1 <- tt1[,3:dim(tt1)[2]]
    }
    return(tt1)
  }

  sapply(taxon,
         function(taxon, site, data, taxon_rank, rng) {
           if (taxon_rank=="genus") {
             tsel <- tolower(substr(taxon,1,4))
             if (tsel %in% c("eury","vibu")) { ## the four species basically in shrub-form, rarely reach T2 or C (oversotry-)layer
               tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,quadArea_weight,rng=rng,
                                                 biasx=ifelse(is.na(biasx),1L,biasx),
                                                 biasy=ifelse(is.na(biasy),1L,biasy),
                                                 data=data[substr(spcode,1,4) == tsel,],
                                                 stratum=ifelse(length(stratum)==0,'all',stratum), ...)] %>% t()
             } else {
               tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,quadArea_weight,rng=rng,
                                                 biasx=ifelse(is.na(biasx),1L,biasx),
                                                 biasy=ifelse(is.na(biasy),1L,biasy),
                                                 data=data[substr(spcode,1,4) == tsel,],
                                                 stratum=ifelse(length(stratum)==0,'over',stratum), ...)] %>% t()
             }
           } else if (taxon_rank=="family") {
               tsel <- unique(c(xtree[substr(spcode,1,4) == tolower(substr(taxon,1,4)),]$family,
                                xtree[spcode == tolower(taxon),]$family,
                                xtree[tolower(species)== tolower(taxon),]$family,
                                xtree[tolower(family) == tolower(taxon),]$family
                       ))[1L]

               if (tsel %in% c("Pentaphylacaceae","Adoxaceae")) { ## the four species basically in shrub-form, rarely reach T2 or C (oversotry-)layer
                 tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,quadArea_weight,rng=rng,
                                                   biasx=ifelse(is.na(biasx),1L,biasx),
                                                   biasy=ifelse(is.na(biasy),1L,biasy),
                                                   data=data[family == tsel,],
                                                   stratum=ifelse(length(stratum)==0,'all',stratum), ...)] %>% t()
               } else {
                 tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,FUN=quadArea_weight,rng=rng,
                                                   biasx=ifelse(is.na(biasx),1L,biasx),
                                                   biasy=ifelse(is.na(biasy),1L,biasy),
                                                   data=data[family == tsel,],
                                                   stratum=ifelse(length(stratum)==0,'over',stratum), ...)] %>% t()
               }

           } else {
               if (taxon_rank=="spcode") {
                 if (sppMatch & substr(taxon,5,6)=='sp') {
                   tsel <- unique(xtree[substr(spcode,1,4) == tolower(substr(taxon,1,4)),]$spcode)
                 } else {
                   tsel <- unique(xtree[spcode == tolower(taxon),]$spcode)
                 }
               } else {
                 tsel <- unique(xtree[species == tolower(taxon),]$spcode)
               }
               # "euryle","eurylo","vibuta","vibulu" the four species basically in shrub-form, rarely reach T2 or C (oversotry-)layer
               if (unique(substr(tsel,1,4))[1] %in% c("eury","vibu")) {
                 tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,quadArea_weight,rng=rng,
                                                   biasx=ifelse(is.na(biasx),1L,biasx),
                                                   biasy=ifelse(is.na(biasy),1L,biasy),
                                                   data=data[spcode %in% tsel,],
                                                   stratum=ifelse(length(stratum)==0,'all',stratum), ...)] %>% t()
               } else {
                 tt1 <- site[,.(x,y)] %>% .[,apply(.,MARGIN=1,quadArea_weight,rng=rng,
                                                   biasx=ifelse(is.na(biasx),1L,biasx),
                                                   biasy=ifelse(is.na(biasy),1L,biasy),
                                                   data=data[spcode %in% tsel,],
                                                   stratum=ifelse(length(stratum)==0,'over',stratum), ...)] %>% t()
               }
           }

           names(tt1)[3] <- taxon

           invisible(tt1[,3])

         }, site = site,
         data=xtree[,.(x,y,spcode,family,DBH,sprout_ba,layer)],
         taxon_rank=taxon_rank, rng=rng
        )
}

#' Query ppp, toroidal-shift, randomized patterns of bio-data (default, tree survey 2006 in Nanhsi plot, Taiwan)
#' @param txrng A numeric vector to indicate x range of survey plot
#' @param tyrng A numeric vector to indicate y range of survey plot
#' @param data A data.frame to indicate survey data, default (no assigning) use tree survey 2006 in Nanhsi plot
#' @param seed An integer to fix random seed fro permutation for reproducible results
#' @param B An integer to specify times of permutation
#' @param perm A character string to specify permutation, no assigning return ppp pattern of original data
#'   \describe{
#'     \item{'torus'}{toroidal-shift pattern}
#'     \item{'random'}{complete randomized pattern}
#'     \item{'all'}{including ppp and the two permutated patterns, or you can specify c("torus","random")(default value)}
#'   }
#' @param mark_cols A character string to specify which columns of data would be the "marks" in ppp pattern.
#' @return A list with elements ppp, torus, and random, depends on the argument of "perm".
#' @examples
#' ppp_NanhsiTree(perm=("all"))
#' @rdname ppp_NanhsiTree
#' @export
ppp_NanhsiTree <- function(txrng=c(0,351), tyrng=c(250,501), data=data.frame(),
                           seed=123L, B=200L, perm=c("torus","random"),
                           mark_cols=c("spcode","DBH","sprout_ba","layer")) {
  if (nrow(data)==0) {
    xtree <- copy(compo_tree_sp06) %>% .[,DBH:= main_cir/pi] %>% .[,c("x","y",mark_cols),with=FALSE]
  } else {
    if (!is.data.table(data)) {
      xtree <- data[,c("x","y",mark_cols)]
    } else {
      xtree <- data[,c("x","y",mark_cols), with=FALSE]
    }
  }
  tr.ppp <- ppp(x=xtree$x,y=xtree$y,window=owin(txrng,tyrng),marks=xtree[,.(spcode,DBH,sprout_ba,layer)])

  if (length(perm)==0) { ## no permutation needed
    retrun(list(ppp=tr.ppp))
  }

  set.seed(seed)
  torus.out<- vector("list", B)
  rand.out <- vector("list", B)

  if ("torus" %in% tolower(perm) | "all" %in% tolower(perm)) {
    torus.out[[1]] <- tr.ppp
    for(i in 2: B){
      torus.out[[i]] <- rshift(tr.ppp, edge="torus") # torus permutation
    }
  }

  if ("random" %in% tolower(perm) | "all" %in% tolower(perm)) {
    for(i in 1:B){ # start loop to generate simulations
      rand.out[[i]] <- rlabel(tr.ppp, labels=marks(tr.ppp), permute=TRUE) # complete randomization
    }
  }

  if ("all" %in% tolower(perm)) {
    return(list(ppp=tr.ppp, torus=torus.out, random=rand.out))
  } else if (all(c("torus","random") %in% tolower(perm))) {
    return(list(torus=torus.out, random=rand.out))
  } else if ("torus" %in% tolower(perm)) {
    return(list(torus=torus.out))
  } else {
    return(list(random=rand.out))
  }
}

## Permutation function for testing each component pattern for the associated variance it contributes
## x: times of permutation used in sapply; V: Moran's Eigenvector Maps, MEM
permf <- function (x, Y, V, w) {
  pcor<- cor(V, Y[sample(1:nrow(Y)),])^2
  return (max(pcor %*% w))
}

#' Permutation test each component pattern (MEM, or like PCNM variable) for the associated variance it contributes
#' @param Y A data.frame of site-species composition data, multivariate N*P response, N: site numbers; P: species numbers
#' @param w A numeric vector to specify weights of species (length P), usually it's normalized variance in Y. If not specify, using interally evaluation from Y and return its value.
#' @param MEM A data.frame of Moran's Eigenvector Maps, MEM, N*U
#' @param B An interger indicates times of permutation
#' @return A list indicates: with sig: ; obs: .
#'   \describe{
#'     \item{sig}{significant index of MEM}
#'     \item{w}{used species weights, either by arguments or by internally evaluation from Y}
#'     \item{obs}{observed associated variance of each component pattern contributed}
#'     \item{perms}{permutation mean and 0.95 confidenct level,i.e., quantile in c(0.5,0.95)}
#'   }
#' @examples
#' testMEM(Y, MEM=V, B=999)
#' @rdname testMEM
#' @export
testMEM <- function(Y, w=c(), MEM, B=999)
{
  if (length(w)==0) {
    w <- apply(Y,2,var)
    w <- w/sum(w)
  }

  obs <- cor(MEM, Y)^2
  obsa<- obs %*% w

  pt <- sapply(1:B, permf, Y=Y, V=MEM, w=w)

  return(list(sig=c(1:ncol(MEM))[obsa > quantile(pt, 0.95)], w=w,
              obs=obsa, perms=quantile(pt, c(0.5,0.95))))
}

#' Permutation test to find significant MEM in model: Y ~ MEM + Tx by using function testMEM
#' @param Y A data.frame of site-species composition data, multivariate N*P response, N: site numbers; P: species numbers
#' @param w A numeric vector to specify weights of species (length P), usually it's normalized variance in Y. If not specify, using interally evaluation from Y and return its value.
#' @param MEM A data.frame of Moran's Eigenvector Maps, MEM, N*U
#' @param Tx A data.frame of covarying environmental data, multivariate N*E variates/factors
#' @param B An interger indicates times of permutation
#' @param iterLimit An interger indicates times of iteration to test residuals of Y ~ MEM + Tx
#' @return A list includes elements:
#'   \describe{
#'     \item{sig}{significant index of MEM}
#'     \item{w}{used species weights, either by arguments or by internally evaluation from Y}
#'     \item{obs}{observed associated variance of each component pattern contributed}
#'     \item{stats}{permutation 0.95 confidenct level of each component patttern (for plotting significant threshold)}
#'     \item{perms}{permutation mean and 0.95 confidenct level,i.e., quantile in c(0.5,0.95), take mean() and min(), respectively, for each iteration}
#'   }
#'
#' \describe{
#'     Reference, and also cited in my paper: (Jombart et al. 2009, Wagner 2013). Permuted residuals of Y 1,000 times as the null expectation to verify if associated variance of each PCNM variable contributed had significant one-tail p-value < 0.05, and partialling out covarying Topographic factors (Tx). Modified codes from Wagner (2013)
#'     \enumerate{
#'     \item Jombart T, Dray S, Dufour AB (2009) Finding essential scales of spatial variation in ecological data: A multivariate approach. Ecography 32:161-168.
#'     \item Wagner HH (2013) Rethinking the linear regression model for spatial ecological data. Ecology 94:2381-2391.
#'     }
#' }
#' @examples
#' testResid(Y, MEM=V, Tx, B=999)
#' @rdname testResid
#' @export
testResid <- function(Y, w=c(), MEM, Tx, B=999, iterLimit=10) {

  print("Start testMEM run 0..")
  mdl0 <- testMEM(Y=Y, w=w, MEM=MEM, B=B)
  if (length(w)==0) {
    w <- mdl0$w
  }
  tst_mdlk <- mdl0$sig
  print(tst_mdlk)
  permu<- mdl0$perms[1]
  perci<- mdl0$perms[2]
  obs  <- mdl0$obs
  perx <- rep(perci,length(obs))
  tstn <- 1

  while (length(tst_mdlk)>0 | tstn>iterLimit) {
    tstn <- tstn+1
    print(tstn)

    mdlt <- testMEM(Y=residuals(lm(data.matrix(Y) ~ data.matrix(MEM[,tst_mdlk]) + data.matrix(Tx))),
                    w=w, MEM=MEM, B=B)
    idx <- mdlt$sig
    print(idx)

    if (length(idx)>0) {
      tst_mdlk <- sort(unique(c(tst_mdlk, idx)))
      outidx <- tst_mdlk
      obs[idx] <- mdlt$obs[idx]
      perx[idx]<- mdlt$perms[2]
    } else {
      outidx <- tst_mdlk
      tst_mdlk <- idx
    }
    permu <-mean(c(permu,mdlt$perms[1]))
    perci <- min(c(perci,mdlt$perms[2]))
  }
  return (list(sig=outidx,
               w=w,
               obs=obs, stats=perx,
               res=mdlt$obs, perms=c(permu,perci)))
}

