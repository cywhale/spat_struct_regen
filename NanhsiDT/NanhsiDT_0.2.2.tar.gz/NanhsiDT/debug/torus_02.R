#################### 20160314 modified from test_compostion _utype_diff_permute01.R
#################### to redo and redraw Torus plot
setwd('D:/R/01paper_ssn/NanhsiDT/')
library(NanhsiDT)
library(magrittr)
library(foreach)
library(doParallel)

# source('debug/init_env_sp_cover01.R')
# ecov <- load_us_spcov()

#################### Functions
dtcomb <- function(...) {
  rbindlist(list(...))
}

## compute number and area of each cluster
## Nq = total sites, AREA = area of one quadrat (m2), return (ha)
clusterDT_size <- function (cluster,AREA=4) {

  return(data.table(cluster) %>% .[,.N, by=cluster] %>% .[,area:=AREA*N] %>% ## Modified: not converted to ha, only m^2 (/10000.0)
    setnames(2,"num"))
}

#DT_rsum <- function (dt) {
#  rs <- rowSums(dt, na.rm = T)
#  for (j in names(dt)) set(dt,j=j,value=dt[[j]]/rs)
#  return (dt)
#}

###################### Global Variables ###############################
xblk<- 10L  ########## 10 blocks/transects in x-axis
ycell<-100L ########## 200 m /2m grid = 100 cells/subplots/grids
L   <- xblk*ycell    # total numbers of subplots, could be serially indexed
B   <- 4*L  # 4 toridal-shift types
sdlH<- 30   ########## seedling height < sdlH is new seedlings (recruits), otherwise older seedlings

randidx <- matrix(0,nrow=L,ncol=B*2) ## 4000 times toridal-shift, then 4000 times randomization maps

randidx[1:L,1:B] <- torusM_idx(xblk=10L, ycell=100L)
randidx[1:L,(B+1):(B*2)] <-shuffleM_idx(c(1:L), B, seed = 123, keep_origin = FALSE, index_only = FALSE)
### because original index keep in randidx[,1] in torusM_idx(), so would not keep twice in shuffleM_idx()

## compare to old version
## index= Torus.cy.01(xlim = 10, ylim = 100)
## all.equal(index,torusidx)
## [1] TRUE

### for null quadrat #####################
data(us_env00)      # in NanhsiDT dataset for basic env
data(compo_us_sp00) # in NanhsiDT dataset for understory composition

env0 <- rbindlist(list(us_env00[,.(transect,x,y)],
                      data.table(transect=c("06_044","09_019","09_022","12_001","18_042","30_034"),
                                 x=c(60,  90, 90,120,180,300),
                                 y=c(346,296,302,260,342,326)))) %>% setkey(transect) %>% setorder(x,y)
#check old version
#all.equal(env0, envt %>% data.table())

usx <- merge(compo_us_sp00,env0,by="transect",all.x=TRUE)
#all.equal(usx, all0 %>% data.table())

clusT <- env$cluster
envclus <- us_env00 %>% .[,cluster:=clusT] %>% .[,.(transect,cluster)]

# Nqv=cluster_size.cy.01 (dim(env)[1],env$cluster,AREA=4)
Nqv <- clusterDT_size(clusT,AREA=4)
nlvl<- length(unique(clusT))

## store value ##
ntreat = 3*2 + 1 ## '+1' means herb taken as a whole and only do HillN1,  but sdl split into three class and evaluate density and HillN1 (3*2)

print("Torus start..")
tt <- Sys.time()
print(format(tt, "%Y%m%d %H:%M:%S"))

######################################## Parallel version

(Maxcores <- detectCores())
#[1] 8
mcores   <- Maxcores #### NOTE: for this case, length(randidx)/mcores must be integer

stopifnot(B %% mcores ==0)

split_sz <- as.integer(B*2/mcores)
#split_sz<- as.integer(dim(randidx)[2]/mcores)+as.integer(ifelse(dim(randidx)[2]%%mcores>0,1,0))

registerDoParallel(cores=mcores)

#cat.debug.command.02(msg="Parallel workers in subdivde data mode: ",
#                     argv=c(
cat("Parallel workers: ",getDoParWorkers())
#                       ),fo=debugf)

dxp = foreach(m=1:mcores, .packages=c("data.table", "NanhsiDT", "magrittr"), .combine="dtcomb",
              .inorder=T, .multicombine=T, .verbose=T) %dopar% {

        tstidx <- ((m-1)*split_sz+1):min(m*split_sz,dim(randidx)[2])
        dx = matrix(0,nrow=length(tstidx)*nlvl*ntreat,ncol=5)

        for (i in 1:length(tstidx)) {
          envt <- copy(env0) %>% .[,transect:=transect[randidx[,tstidx[i]]]]

          allt <- merge(usx[,-1,with=F],envt,by=c("x","y"),all.x=TRUE) ##Notice: only shuffle "transect"_index, but "x","y" remain the same!!
          allt %<>% .[!(transect %in% c("06_044","09_019","09_022","12_001","18_042","30_034")),] %>%
            merge(envclus, by="transect")

          #sdl <- allt[substr(tag,1,1)=="t",]
          #recruit <- sdl[height<sdlH,]
          #herb <- allt[substr(tag,1,1)!="t" & !(substr(tag,1,1)=="u" & lifeform=="T"), ]

          ## seedling density
          dx[((i-1)*nlvl*ntreat+1):((i-1)*nlvl*ntreat+18),] <- as.matrix(rbindlist(list(
            allt[substr(tag,1,1)=="t",] %>% .[,.N,by=cluster] %>% setkey(cluster) %>% .[Nqv] %>% .[,val:=N/area] %>% .[,.(cluster,val)] %>% .[,labt:=1][,class:=1][pat:=ifelse(tstidx[i]==1, 0L, ifelse(tstidx[i]>B, 2L, 1L))], ################### density of seedling(sdl)
            allt[substr(tag,1,1)=="t" & height<sdlH,]  %>% .[,.N,by=cluster] %>% setkey(cluster) %>% .[Nqv] %>% .[,val:=N/area] %>% .[,.(cluster,val)] %>% .[,labt:=1][,class:=2][pat:=ifelse(tstidx[i]==1, 0L, ifelse(tstidx[i]>B, 2L, 1L))], #### density of recruit, sdl height< 30cm
            allt[substr(tag,1,1)=="t" & height>=sdlH,] %>% .[,.N,by=cluster] %>% setkey(cluster) %>% .[Nqv] %>% .[,val:=N/area] %>% .[,.(cluster,val)] %>% .[,labt:=1][,class:=3][pat:=ifelse(tstidx[i]==1, 0L, ifelse(tstidx[i]>B, 2L, 1L))]  #### density of older sdl, height>= 30cm
          )))

          dx[((i-1)*nlvl*ntreat+19):((i-1)*nlvl*ntreat+36),] <- as.matrix(
            rbindlist(list(allt[substr(tag,1,1)=="t",] %>% .[,.N, by=.(cluster,spcode)] %>% setkey(cluster) %>% .[Nqv] %>% .[,val:=N/area][class:=1] %>% .[,.(cluster,spcode,val,class)],
                           allt[substr(tag,1,1)=="t" & height<sdlH,]  %>% .[,.N, by=.(cluster,spcode)] %>% setkey(cluster) %>% .[Nqv] %>% .[,val:=N/area][class:=2] %>% .[,.(cluster,spcode,val,class)],
                           allt[substr(tag,1,1)=="t" & height>=sdlH,] %>% .[,.N, by=.(cluster,spcode)] %>% setkey(cluster) %>% .[Nqv] %>% .[,val:=N/area][class:=3] %>% .[,.(cluster,spcode,val,class)])) %>%
              dcast(class + cluster ~ spcode, fill = 0, value.var = "val", sep="") %>%
              .[,val:=vsp_dividx(.[,-c(1:2),with=F],index="HillN1")][,labt:=2][pat:=ifelse(tstidx[i]==1, 0L, ifelse(tstidx[i]>B, 2L, 1L))] %>%
              .[,.(cluster,val,labt,class,pat)]
          )

          dx[((i-1)*nlvl*ntreat+37):((i-1)*nlvl*ntreat+42),] <- as.matrix(
            allt[substr(tag,1,1)!="t" & !(substr(tag,1,1)=="u" & lifeform=="T"), ] %>% .[,.(transect,spcode,coverage)] %>%
              .[,.(spcov=sum(coverage)),by=.(transect,spcode)] %>%
              dcast(transect ~ spcode, fill = 0, value.var = 'spcov') %>%
              .[,c(names(.)[2:ncol(.)]):=lapply(1:(ncol(.)-1), function(i) sweepM_rsum(as.matrix(.[,-1,with=FALSE]))[,i])] %>%
              merge(envclus, by="transect") %>% setkey(cluster) %>%
              .[, lapply(.SD, sum), by=cluster, .SDcols=c(2:(ncol(.)-1))] %>%
              .[Nqv, lapply(.SD, `/`,area), by=.EACHI, .SDcols=c(2:ncol(.))] %>%
              .[,val:=vsp_dividx(.[,-1,with=F],index="HillN1")][,labt:=3][,class:=4][pat:=ifelse(tstidx[i]==1, 0L, ifelse(tstidx[i]>B, 2L, 1L))] %>%
              .[,.(cluster,val,labt,class,pat)]
          )
        }

        dx %<>% data.table() %>% setnames(1:5,c("cluster","value","labt","class","pat"))

        dx
      }


#stopImplicitCluster()

print("Torus End..")
tt1 <- Sys.time()
print(format(tt1, "%Y%m%d %H:%M:%S"))
print(tt1-tt)

########################################## on win 8, 16G one-core 4000 index: Time difference of 2.608028 hours ################
########################################## on win 7, odb one core 4000 index: Time difference of 5.254826 hours ################
########################################## on win 8, 16G 8-core 8000 index:   Time difference of 1.38808 hours  ################

save(dxp, file="D:/R/01paper_ssn/NanhsiDT/debug/ssn_us_torus01.RData")

####################### plot

library(ggplot2)

#dx <- data.table(dx) %>% setnames(1:5,c("cluster","value","labt","class","origin"))

#clabt <- c("Seedling density","Seedling diversity","Understory diversity")
#nvars=length(labt)#
#dsrc1=c("d","n1","hn1")
#dsrc2=c("a","r","o")
#classlabt <- c("All","seedling","Older seedling")
#require(reshape)

#quan_y05 <- function(x) {quantile(x,0.05)}
#quan_y95 <- function(x) {quantile(x,0.95)}

quanfun <- function(x) {
  res <- quantile(x,probs=c(0.05,0.5,0.95))
  names(res)<-c("ymin","y","ymax")
  res}

g2x <- ggplot(dxp[pat==1,],#facets=~ factor(labt),
              aes(x=factor(cluster), y=value), color=factor(class), fill=factor(class)) +
  #theme_bw()+
  #geom_boxplot(aes(lower= quantile(value, 0.05), upper= quantile(value, 0.995),
  #                 ymin = quantile(value, 0.05), ymax = quantile(value, 0.995)   ),
  #  width=0.35,outlier.shape = NA) +
  stat_summary(fun.data = quanfun, #fun.y = median, fun.ymin = quan_y05, fun.ymax = quan_y95,
               size=0.1,
               aes(color=factor(class),
                   x=ifelse(class==2, cluster,
                     ifelse(class==1, cluster-0.125, cluster+0.125)))) +
  labs(x="Spatial structure groups (SSG)") +
  facet_wrap(~ labt,scales="free_y") +
  scale_shape_manual(values=c(6,4,3,2)) +
  scale_fill_grey(start = 0.4, end = 0.8) +
  #  geom_crossbar(aes(ymin=q005, ymax=q95, y=pred)))
  #  stat_summary(fun.y=q95, colour="grey", geom="crossbar", width = 0.3, ymin=value, ymax=value) +#, xmin=group, ymax=group) +
  #  stat_summary(fun.y=q005,colour="grey", geom="crossbar", width = 0.3, ymin=value, ymax=value)#, xmin=group, ymax=group)
  #  theme_bw() +
  #  scale_fill_manual(values=fill_values) +
  #  scale_colour_manual(values=colour_values) +
   #facet_wrap(~ labt,ncol=3)
#+ #opts(title = "",
#     panel.grid.major = theme_blank(),
#     panel.grid.minor = theme_blank(),
#    legend.key = theme_blank()
#    ) +
#  geom_boxplot(data=dxp[pat==2,], ########### Randomization results
#    aes(lower= quantile(value, 0.05), upper= quantile(value, 0.995),
#        ymin = quantile(value, 0.05), ymax = quantile(value, 0.995)   ),
#        width=0.05,col="grey", outlier.color="grey",outlier.shape = NA) +
  geom_violin(data=dxp[pat==2,],
    aes(group=factor(class),
        x=ifelse(class==2, cluster,
                 ifelse(class==1, cluster-0.125, cluster+0.125))),
    draw_quantiles = c(0.05, 0.95), size=0.05) +
  #stat_summary(data=dxp[pat==2,],
  #             fun.data = quanfun, #fun.y = median, fun.ymin = quan_y05, fun.ymax = quan_y95,
  #             size=0.05, geom = "crossbar",
  #             aes(color=factor(class),
  #               x=ifelse(class==2, cluster,
  #                 ifelse(class==1, cluster-0.125, cluster+0.125)))) +
  geom_point(data=dxp[pat==0,],
             aes(x=ifelse(class==2, cluster,
                   ifelse(class==1, cluster-0.125, cluster+0.125)), y=value,
                 size=0.35,fill=factor(class),shape=factor(class)), #ifelse(class=="Understory",4,
             #ifelse(class=="Sapling",3,
             #ifelse(class=="Seedling",2,1)))),
             colour="black")



g2x











