WD0=c("D:/","/media/cywhale/data/") # working in win or ubuntu
wi =1

##dir1="d:/ecology/paper/2012_transect_2009/"
#dir1="d:/ecology/Dropbox/R/01paper_transect2009/"
#dir2="d:/ecology/Dropbox/Nanhsi_survey/2012_transect2009/"
#rdir = "D:/ecology/Dropbox/R/"

rdir = paste0(WD0[wi],"R/")

#rdir = "k:/chiyu/Dropbox/R/"
###dir1="K:/chiyu/Dropbox/Nanhsi_survey/2012_transect2009/"
#dir1="k:/chiyu/Dropbox/R/01paper_transect2009/"
#dir2="K:/chiyu/Dropbox/Nanhsi_survey/2012_transect2009/"
dir1=paste0(rdir,"01paper_transect2009/")
dir2=paste0(WD0[wi],"backup/bak_paper/2012_transect_2009/")

raw_d  = paste(dir2,"raw_data/",sep="")
#raw_d  = paste(dir1,"raw_data/",sep="")
out_d  = paste(dir1,"analysis/",sep="")
#xt = paste(out_d,"92_cluster_constrain.rda",sep="") # 201309 for file uenvt - 08
#xt = paste(out_d,"92_cluster_constrain_t10.rda",sep="") # 201309 for file uenvt -t10
#xt = paste(out_d,"92_cluster_constrain_t11.rda",sep="") # 201309 for file uenvt - t11
#xt = paste(out_d,"92_cluster_constrain_t12.rda",sep="") # 201310 for file uenvt - t12
#xt = paste(out_d,"92_cluster_constrain_tmp.rda",sep="") # 201310 only uRDAe1, uRDAe2, not good
xt = paste(out_d,"92_cluster_constrain_t13.rda",sep="") # 201310 for file uenvt - t13,only uRDA1 (final)
#
#save.image(xt)
load(xt)
################# modified 2014/02 but need to improve...
#xt = "K:/chiyu/ecology/temp/92_cluster_constrain_t04.rda"    #201402 modify
#save.image(xt)
#load(xt)

rdir = paste0(WD0[wi],"R/")

#rdir = "k:/chiyu/Dropbox/R/"
###dir1="K:/chiyu/Dropbox/Nanhsi_survey/2012_transect2009/"
#dir1="k:/chiyu/Dropbox/R/01paper_transect2009/"
#dir2="K:/chiyu/Dropbox/Nanhsi_survey/2012_transect2009/"
dir1=paste0(rdir,"01paper_transect2009/")
dir2=paste0(WD0[wi],"backup/bak_paper/2012_transect_2009/")

raw_d  = paste(dir2,"raw_data/",sep="")
#raw_d  = paste(dir1,"raw_data/",sep="")
out_d  = paste(dir1,"analysis/",sep="")

#xt = paste(out_d,"00_Final_transect2009_env04_convex.csv",sep="")
xt = paste(out_d,"00_Final_transect2009_env05_liw.csv",sep="")
#write.table(uenv4, xt, sep=",", col.names=T, row.names=F, na="")
uenv4= read.table(xt,header=T,na.string="",sep=",")
#================================================================ modified 201307
#xt = paste(out_d,"00_Final_transect2009_env06_newtHI.csv",sep="")
xt = paste(out_d,"00_Final_transect2009_env07_trssh.csv",sep="") #modified 201308
uenv6 = read.table(xt,header=T,na.string="",sep=",")

uenvc1 = uenv6[,-1]
rownames(uenvc1)=uenv6[,1]

### Constrained clustering R 2.12
require (const.clust)

simpleRDA2 = function (Y, X, SS.Y, ...)
{
  Q <- qr(X, tol = 1e-06)
  Yfit.X <- qr.fitted(Q, Y)
  SS <- sum(Yfit.X^2)
  if (missing(SS.Y))
    SS.Y <- sum(Y^2)
  Rsquare <- SS/SS.Y
  list(Rsquare = Rsquare, m = Q$rank)
}

xt = paste(out_d,"11_us05_MEM_axes12.csv",sep="")
tt = read.table(xt,header=T,na.string="",sep=",")
uat= tt[,2:3]; rownames(uat)=tt[,1]
uenvt = uat

############################# check which not covary with env ## 201604
xt = paste(out_d,"90_PCNM__obj201202_03.rda",sep="")     #201307 divide adult,juvenile
load(xt)

cor.test(ua.axes[,1],uat[,1]) ##no cor relation
cor.test(ua.axes[,1],uenv6$uRDA1)  ### exact identical, not covary-with-env
cor.test(ua.axes[,1],uenv4$uRDA1)  ### not equal, uenv4$uRDA1 is orignal PCNM output, still have co-varing-with-env parts
cor.test(ua.axes[,1],uenvc1$uRDA1) ### exact identical, not covary-with-env
cor.test(ua.axes[,1],uenvt[,1])    ### exact identical, not covary-with-env

#library(NanhsiDT)

################################ if use uenvc1. not uenva : standarlization
#uenvc = subset(uenvc1,select=c("altitude","tHI",
#                              "tcvex","tslope","slope",
#                              "tspos1","tspos2","tspos3","tspos4",
#                              "den","all_BA"))
##                              "c_BA",#"t2_BA",
##                              "s_BA","den",#all_BA,
##                              "tRDA1","tRDA2","tLCBD"))

uenvt = subset(uenvc1,select=c(#"altitude",#"tHI", #### t8
  #"tcvex","tslope","slope",
  #"tspos1",
  #"tspos2","tspos3","tspos4",
  #"c_BA","t2_BA",
  #"s_BA","den",#all_BA,
  #"tRDA1","tRDA2","tLCBD",
  #"aRDA1",
  "uRDA1"))

uenvt = scale(uenvt)
################################################################


#==============================

coord.uenv= uenv4[,6:7]
coords = coordinates(coord.uenv)
require(spdep)
nbg = graph2nb(relativeneigh(coords,nnmult=4),sym=T) #gabrielneigh(coords,nnmult=4)
plot(nbg,coords)

# 1. Compute a Delaunay triangulation using tri2nb() of spdep
### ttw <- nb2listw(tri2nb(coord.uenv), style="B") # 201310 try
ttw <- nb2listw(nbg, style="B")
# Construct matrix links.mat
links.mat.dat <- listw2mat(ttw)


## Plot the connections
#
par(mfrow=c(1,1),mar=c(0,0,1,0))
###plot(data,border="grey")
plot(ttw,coords=coords,pch=19, cex=0.1, col="blue")

# 2. Constrained clustering using default Ward method, for new uenvt=uRDA1, new nb, 2013.10
D.uenv <- dist(uenvt)
clus.uenv <- constrained.clust(D.uenv, links.mat.dat)

plot(clus.uenv, hang=-1)

cross.clus <- cross(uenvt, clus.uenv,k1=3,k2=20)
summary(cross.clus)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uenv, coord.uenv,k1=3,k2=11,cex=0.9,pos=4)

xt = paste(out_d,"01_env_hetero_clust_RN_relativeneigh.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus$AIC),cross.clus$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust_RN_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")


#=============================== for uRDAe1,e2 (with env)
D2.uenve <- dist(uenvte)
clus.uenve <- constrained.clust(D2.uenve, links.mat.dat)

plot(clus.uenve, hang=-1)

cross.clus.tre <- cross(uenvte, clus.uenve,k1=3,k2=15)
summary(cross.clus.tre)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uenve, coord.uenv,k1=3,k2=15,cex=0.9,pos=4)

xt = paste(out_d,"01_env_hetero_RNe_relativeneigh.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus.tre$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus.tre$AIC),cross.clus.tre$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust_RNe_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")


#=============================== split factors of env and tree-community

D2.uenv <- dist(uenvt)
clus.uent <- constrained.clust(D2.uenv, links.mat.dat)

plot(clus.uent, hang=-1)

cross.clus.tr <- cross(uenvt, clus.uent,k1=3,k2=15)
summary(cross.clus.tr)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uent, coord.uenv,k1=3,k2=15,cex=0.9,pos=4)

#xt = paste(out_d,"01_env_hetero_clust03t12.csv",sep="") # modify 201402
xt = paste(out_d,"01_env_hetero_clust04tt.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus.tr$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus.tr$AIC),cross.clus.tr$AIC)
colnames(t2)[1]="group"
#xt = paste(out_d,"01_env_hetero_clust03t12_AIC.csv",sep="") # modify 201402
xt = paste(out_d,"01_env_hetero_clust04tt_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")


#=============================== split factors for adult tree

D2a.uenv <- dist(uenvt)
clus.uenta <- constrained.clust(D2a.uenv, links.mat.dat)

plot(clus.uenta, hang=-1)

cross.clus.tra <- cross(uenvt, clus.uenta,k1=3,k2=15)
summary(cross.clus.tra)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uenta, coord.uenv,k1=3,k2=15,cex=0.9,pos=4)


# ========================= save classification by adult
xt = paste(out_d,"01_env_hetero_clust03tmp.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus.tra$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus.tra$AIC),cross.clus.tra$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust03tmp_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

#=============================== split factors for only juveile
# D2j.uenv <- dist(uenvtj)
# clus.uentj <- constrained.clust(D2j.uenv, links.mat.dat)
#
# plot(clus.uentj, hang=-1)
#
# cross.clus.trj <- cross(uenvtj, clus.uentj,k1=3,k2=15)
# summary(cross.clus.trj)
#
# # 4. Plot maps of constrained clustering steps from 2 to 8 groups
# map.hclust(clus.uentj, coord.uenv,k1=3,k2=15,cex=0.9,pos=4)
#
#
# # ========================= save classification by juvenile
# xt = paste(out_d,"01_env_hetero_clust03tj.csv",sep="")
# tt=data.frame(uenv4[,3],cross.clus.trj$out)
# colnames(tt)[1]="transect"
# write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")
#
# t2 = data.frame(rownames(cross.clus.trj$AIC),cross.clus.trj$AIC)
# colnames(t2)[1]="group"
# xt = paste(out_d,"01_env_hetero_clust03tj_AIC.csv",sep="")
# write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

#### another trial

D3.uenv <- dist(uenvk)
clus.uenk <- constrained.clust(D3.uenv, links.mat.dat)

plot(clus.uenk, hang=-1)

cross.clus.uk <- cross(uenvk, clus.uenk,k1=3,k2=20)
summary(cross.clus.uk)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uenk, coord.uenv,k1=3,k2=11,cex=0.9,pos=4)

xt = paste(out_d,"01_env_hetero_clust04.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus.uk$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus.uk$AIC),cross.clus.uk$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust04_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")


#### another trial, only topography

D4.uenv <- dist(uento)
clus.uento <- constrained.clust(D4.uenv, links.mat.dat)

plot(clus.uento, hang=-1)

cross.clus.to <- cross(uento, clus.uento,k1=3,k2=11)
summary(cross.clus.to)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uento, coord.uenv,k1=3,k2=11,cex=0.9,pos=4)

xt = paste(out_d,"01_env_hetero_clust053.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus.to$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus.to$AIC),cross.clus.to$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust052_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

#### another trial

D5.uenv <- dist(uenvk2)
clus.uenk2 <- constrained.clust(D5.uenv, links.mat.dat)

plot(clus.uenk2, hang=-1)

cross.clus.uk2 <- cross(uenvk2, clus.uenk2,k1=3,k2=20)
summary(cross.clus.uk2)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.uenk2, coord.uenv,k1=3,k2=11,cex=0.9,pos=4)

xt = paste(out_d,"01_env_hetero_clust06.csv",sep="")
tt=data.frame(uenv4[,3],cross.clus.uk2$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.clus.uk2$AIC),cross.clus.uk2$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust06_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

#================== try re-classify to combine multiple groups

D6.uenv <- dist(ueclus0)
clus.ueclus <- constrained.clust(D6.uenv, links.mat.dat)

plot(clus.ueclus, hang=-1)

cross.ueclus <- cross(ueclus0, clus.ueclus,k1=3,k2=10)
summary(cross.ueclus)

# 4. Plot maps of constrained clustering steps from 2 to 8 groups
map.hclust(clus.ueclus, coord.uenv,k1=3,k2=10,cex=0.9,pos=4)

xt = paste(out_d,"01_env_hetero_clust06re.csv",sep="")
tt=data.frame(uenv4[,3],cross.ueclus$out)
colnames(tt)[1]="transect"
write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

t2 = data.frame(rownames(cross.ueclus$AIC),cross.ueclus$AIC)
colnames(t2)[1]="group"
xt = paste(out_d,"01_env_hetero_clust06re_AIC.csv",sep="")
write.table(t2,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

xt = paste(out_d,"01_env_hetero_clust_RN_relativeneigh.csv",sep="")
cluster = read.table(xt,header=T,sep=",")
clust   = cluster$Gr.6

tt1= uenv6$uRDA1[which(clust==1)]
tt2= uenv6$uRDA1[which(clust==2)]
tt3= uenv6$uRDA1[which(clust==3)]
tt4= uenv6$uRDA1[which(clust==4)]
tt5= uenv6$uRDA1[which(clust==5)]
tt6= uenv6$uRDA1[which(clust==6)]

par(mfcol=c(3,2))
hist(tt1,30)
hist(tt2,30)
hist(tt3,30)
hist(tt4,30)
hist(tt5,30)
hist(tt6,30)



