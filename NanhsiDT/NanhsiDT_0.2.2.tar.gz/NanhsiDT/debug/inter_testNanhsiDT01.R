library(Rcpp)
library(RcppArmadillo)
sourceCpp('D:/R/01paper_ssn/NanhsiDT/src/torusr.cpp')
sourceCpp('D:/R/01paper_ssn/NanhsiDT/src/torusr.cpp')

library(microbenchmark)
####################################### Test Species diversity index

xrt = read.table("D:/R/01paper_ssn/analysis/02_sdl_eclus_density01.csv",header=T, na.string="", sep=",")
sz   = dim(xrt)[2]
xva  = t(xrt[,2:sz])
colnames(xva)=paste(xrt[,1])

sourceCpp('D:/R/01paper_ssn/NanhsiDT/src/compor.cpp')
sourceCpp('D:/R/01paper_ssn/NanhsiDT/src/compor.cpp')

library(vegan)
dv1= diversity(xva, "shannon")
dv2= vsp_dividx(xva, "shannon", use_names=row.names(xva))
all.equal(dv1,dv2)

dv1= diversity(xva, "simpson")
dv2= vsp_dividx(xva, "simpson", use_names=row.names(xva))
all.equal(dv1,dv2)

dv1= diversity(xva, "invsimpson")
dv2= vsp_dividx(xva, "invsimpson", use_names=row.names(xva))
all.equal(dv1,dv2)

dv1= specnumber(xva)
dv2= vsp_dividx(xva, "spnum", use_names=row.names(xva))
all.equal(dv1,dv2)


microbenchmark(
  "vegan" = diversity(xva, "shannon"),
  "CPPdv" = vsp_dividx(xva, "shannon", use_names=row.names(xva))
)

#Unit: microseconds
#expr     min       lq     mean  median       uq      max neval
#vegan 697.028 734.3235 762.5123 760.034 776.5630 1014.038   100
#CPPdv 123.471 129.4045 138.1572 134.490 145.7915  198.627   100

w <- matrix(runif(2e6,0,100), 1e5) %>% data.table() %>%
  setnames(1:20,sample(LETTERS,20)) %>% .[,SP:=seq_len(nrow(.))]

t <- sample(1:100000,10000)
w$I[t] <- NA ## notice, not surely w would have column 'I' because randomly select

x <- drop(as.matrix(w[,1:20,with=F]))
w1 <- copy(w[,1:20,with=F])
# for (j in names(dt1)) set(dt1,j=j,value=dt1[[j]]/rs1)

microbenchmark(
  "vegan" = diversity(mat_nafillC(x),"simpson"),
  "CPPmt" = vsp_dividx(x, "simpson", use_names=row.names(w1)),
  "CPPdt" = vsp_dividx(w1,"simpson", use_names=row.names(w1)),
  times = 10
)
#Unit: milliseconds
#expr       min        lq     mean    median        uq       max neval
#vegan 740.27157 845.90751 877.0579 875.83279 886.06104 1082.4416    10
#CPPmt  83.58931  84.76949  90.4273  86.36146  92.86173  112.0547    10
#CPPdt  96.23922  96.80967 103.2943 103.41998 106.36829  120.3122    10

#if use_names keep null
#Unit: milliseconds
#expr       min        lq      mean    median        uq       max
#vegan 661.05824 691.67517 749.91730 729.60793 838.12833 859.10216
#CPPmt  45.99589  46.40190  48.46942  47.78762  49.67175  55.07985
#CPPdt  57.61933  58.80939  62.56212  60.24017  61.85913  82.44418

test_fillna <- function (x) {
  x[is.na(x)] <- 0
  return (x)
}

##################################### quite the same, so cancel mat_nafillC
#all.equal(test_fillna(x),mat_nafillC(x)) # TRUE

#microbenchmark(
#  "base" = test_fillna(x),
#  "Cppm" = mat_nafillC(x),
#  times = 10
#)

#Unit: milliseconds
#expr      min       lq     mean   median       uq      max neval
#base 33.34288 37.76803 43.40830 38.42875 41.56538 70.17119    10
#Cppm 38.47693 38.80270 42.15504 39.97015 41.27605 61.30676    10



all.equal(diversity(mat_nafillC(x),"simpson"), vsp_dividx(x, "simpson")) ### TRUE
all.equal(diversity(mat_nafillC(x),"simpson"), vsp_dividx(w1, "simpson")) ## TRUE

####################################### Test Torus

source("D:/R/function_cy/Torus_01.R")

x = seq(1:1e5)
ylim = 100

all.equal(shift_x.cy.01(x,ylim),torus_sftx(x,ylim))

microbenchmark(
  "sft_R" = shift_x.cy.01(x,ylim),
  "sft_cpp" = torus_sftx(x,ylim)
)

#Unit: microseconds
#expr       min       lq        mean     median         uq       max neval
#sft_R 17186.944 18368.61 29493.60781 18925.1850 50740.4275 55876.995   100
#sft_cpp    57.826    58.73    67.57826    66.4095    68.9695   118.965   100

x = seq(1:1e5)
all.equal(shift_y.cy.01(x,ylim),torus_sfty(x,ylim))

microbenchmark(
  "sft_R" = shift_y.cy.01(x,ylim),
  "sft_cpp" = torus_sfty(x,ylim)
)

#Unit: microseconds
#expr       min         lq       mean     median        uq       max neval
#sft_R 17453.184 19562.6255 28839.6841 20064.6865 48782.629 51108.466   100
#sft_cpp   156.612   188.3865   273.1011   194.7105   210.372  1855.549   100

x=seq(1:8000)
all.equal(mirror_x.cy.01(x,ylim),torus_mirrx(x,ylim))

x=seq(1:1e5)
all.equal(mirror_x.cy.01(x,ylim),torus_mirrx(x,ylim))

x=seq(1:1e5)
microbenchmark(
  "sft_R" = mirror_x.cy.01(x,ylim),
  "sft_cpp" = torus_mirrx(x,ylim)
)

#Unit: microseconds
#expr       min         lq       mean     median        uq       max neval
#sft_R 19019.906 20540.5455 29890.8657 21299.6615 22646.975 62504.085   100
#sft_cpp   156.311   189.7415   284.1845   199.6805   205.553  2280.811   100

x = seq(1:48)
ylim = 4
tt = torus_rotate(x,ylim)
mt = matrix(tt,4,12)


x = seq(1:1e3)
ylim = 100
##torus_rotate(x,ylim)
all.equal(rotate_x.cy.01(x,ylim),torus_rotate(x,ylim)) ## rotate.cy.01 have bugs, cannot handl L/ylim > ylim cases

x = seq(1:1e3)
ylim = 10
tt = torus_rotate(x,ylim)
mt = matrix(tt,10,100)
##all.equal(rotate_x.cy.01(x,ylim),torus_rotate(x,ylim))


x=seq(1:1e5)
microbenchmark(
  "sft_R" = rotate_x.cy.01(x,ylim),
  "sft_cpp" = torus_rotate(x,ylim)
)

#on win7
#Unit: milliseconds
#expr      min        lq      mean    median        uq      max neval
#sft_R   14.13199 14.453240 15.910023 14.584761 14.926773 36.39826   100
#sft_cpp  1.79553  1.908122  2.421271  1.986244  2.100671 24.26212   100


#on win8
#Unit: microseconds
#expr      min       lq     mean   median       uq       max neval
#sft_R 6533.123 7611.486 8970.142 8465.924 8971.900 45568.322   100
#sft_cpp  749.327  824.471 1087.787  892.236  991.925  2798.232   100

gc(T)

ind1= Torus.cy.01(xlim = 10, ylim = 100)
gc(T)

ind2= torusM_idx(10, 100)
gc(T)

all.equal(ind2,ind1)

rm(ind2,ind1)
gc(T)


microbenchmark(
  "sft_oldR" = Torus.cy.01(xlim = 10, ylim = 100),
  "sft_cppR" = torusM_idx(xblk = 10, ycell = 100), times = 10
  #"sft_cpp" = torus_index(xlim = 10, ylim = 100), times = 10 ## cpp crash for indexing problem??
)
#on win8
#Unit: milliseconds
#expr      min       lq     mean   median       uq      max neval
#sft_oldR 726.7482 734.8492 759.4029 748.9737 781.9948 801.3102    10
#sft_cppR 101.6589 104.8646 125.3484 111.8383 153.4221 156.8395    10

#on win 7
#Unit: milliseconds
#expr       min        lq      mean    median        uq       max neval
#sft_R 1183.3198 1188.8005 1199.9796 1198.6438 1204.7342 1224.3997     5
#sft_cpp  218.1378  220.8587  245.9915  251.9384  252.6301  286.3925     5
