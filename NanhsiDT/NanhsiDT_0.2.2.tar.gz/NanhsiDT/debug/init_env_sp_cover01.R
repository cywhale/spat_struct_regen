########## 20160311 modified from init_head_env01.R: Load enviromental factors for understory analysis
## evaluate understory species coverage in each quadrat
## data is composition data
load_us_spcov <- function(usHigh = 30, reDef=FALSE) {
  require(NanhsiDT)

  if (!reDef) {
    data("quad_us_cov")
    return(quad_us_cov)
  } else {
    data("compo_us_sp00")
    data("us_env00")

    xres  <- compo_us_sp00[substr(tag,1,1)!="t",] # resident species
    #xgndl = xres[xres$height<=usHigh,] #understory lower species <=30cm, lower ground layer
    #xgndh = xres[xres$height>usHigh,]   #higher ground layer
    #xush  = xres[xres$height>70,]

    c_gndl <- quadDT_cov(xres[height<=usHigh,],"transect","height","coverage",adjMax=TRUE)
    c_gndh <- quadDT_cov(xres[height>usHigh,], "transect","height","coverage",adjMax=TRUE)

    out <- ladd_merge(list(us_env00 %>% .[,c("h_gndl","c_gndl","h_gndh","c_gndh"):=list(0,0,0,0)] %>% .[,.(transect,h_gndl,c_gndl,h_gndh,c_gndh)],
                           c_gndl %>% setnames(2:3,c("h_gndl","c_gndl")),
                           c_gndh %>% setnames(2:3,c("h_gndh","c_gndh"))),by="transect")

    return (out)
  }
}

