# 維管束植物名錄

本名錄中共有 73 科、226 種，科名後括弧內為該科之物種總數。"#" 代表特有種，"*" 代表歸化種，"†" 代表栽培種。中名後面括號內的縮寫代表依照「臺灣維管束植物紅皮書初評名錄」中依照 IUCN 瀕危物種所評估等級， EX: 滅絕、EW: 野外滅絕、RE: 區域性滅絕、CR: 嚴重瀕臨滅絕、 EN: 瀕臨滅絕、VU: 易受害、NT: 接近威脅、DD: 資料不足。若未註記者代表安全(Least concern)


###苔蘚地衣類植物 Mosses and Lichens


1. **Aspleniaceae 鐵角蕨科** (8)
    1. *Asplenium antiquum* Makino 山蘇花 
    2. *Asplenium ensiforme* Wall. ex Hook. & Grev. 劍葉鐵角蕨 
    3. *Asplenium normale* D. Don 生芽鐵角蕨 
    4. *Asplenium planicaule* Wall. ex E.J. Lowe 斜葉鐵角蕨 
    5. *Asplenium tenuicaule* Hayata 小葉鐵角蕨 
    6. *Asplenium tenuifolium* D. Don 薄葉鐵角蕨 
    7. *Asplenium tripteropus* Nakai 三翅鐵角蕨 
    8. *Asplenium wilfordii* Mett. ex Kuhn 威氏鐵角蕨 

2. **Athyriaceae 蹄蓋蕨科** (7)
    9. *Cornopteris decurrenti-alata* (Hook.) Nakai 貞蕨 
    10. *Deparia petersenii* (Kunze) M. Kato 假蹄蓋蕨 
    11. *Diplazium amamianum* Tagawa 奄美雙蓋蕨 
    12. *Diplazium dilatatum* Blume 廣葉鋸齒雙蓋蕨 
    13. *Diplazium kawakamii* Hayata 川上氏雙蓋蕨 
    14. *Diplazium pseudodoederleinii* Hayata 擬德氏雙蓋蕨 
    15. *Diplazium squamigerum* (Mett.) C. Hope 長苞雙蓋蕨 

3. **Cyatheaceae 桫欏科** (1)
    16. *Cyathea spinulosa* Wall. ex Hook. 臺灣桫欏 

4. **Davalliaceae 骨碎補科** (3)
    17. *Araiostegia parvipinnula* (Hayata) Copel. 臺灣小膜蓋蕨 
    18. *Davallia mariesii* T. Moore ex Baker 海州骨碎補 
    19. *Nephrolepis auriculata* (L.) Trimen 腎蕨 

5. **Dennstaedtiaceae 碗蕨科** (3)
    20. *Histiopteris incisa* (Thunb.) J. Sm. 栗蕨 
    21. *Microlepia strigosa* (Thunb.) C. Presl 粗毛鱗蓋蕨 
    22. *Microlepia trichocarpa* Hayata 毛果鱗蓋蕨 # (NT)

6. **Dryopteridaceae 鱗毛蕨科** (21)
    23. *Acrophorus stipellatus* T. Moore 魚鱗蕨 
    24. *Arachniodes aristata* (G. Forst.) Tindale 細葉複葉耳蕨 
    25. *Arachniodes pseudoaristata* (Tagawa) Ohwi 小葉複葉耳蕨 
    26. *Arachniodes rhomboidea* var. *yakusimensis* (H. Itô) W.C. Shieh 屋久複葉耳蕨 
    27. *Cyrtomium caryotideum* (Wall. ex Hook. & Grev.) C. Presl 細齒貫眾蕨 
    28. *Cyrtomium hookerianum* (C. Presl) C. Chr. 狹葉貫眾蕨 
    29. *Cyrtomium taiwanianum* Tagawa 臺灣貫眾蕨  (VU)
    30. *Dryopteris atrata* (Wall. ex Kunze) Ching 桫欏鱗毛蕨 
    31. *Dryopteris formosana* (Christ) C. Chr. 臺灣鱗毛蕨 
    32. *Dryopteris lepidopoda* Hayata 厚葉鱗毛蕨 
    33. *Dryopteris scottii* (Bedd.) Ching 史氏鱗毛蕨 
    34. *Dryopteris sparsa* (D. Don) Kuntze 長葉鱗毛蕨 
    35. *Dryopteris toyamae* Tagawa 外山氏鱗毛蕨  (EN)
    36. *Polystichum acutidens* Christ 臺東耳蕨 
    37. *Polystichum deltodon* (Baker) Diels 對生耳蕨 
    38. *Polystichum hancockii* (Hance) Diels 韓氏耳蕨 
    39. *Polystichum lepidocaulon* (Hook.) J. Sm. 鞭葉耳蕨 
    40. *Polystichum nepalense* (Spreng.) C. Chr. 軟骨耳蕨 
    41. *Polystichum parvipinnulum* Tagawa 尖葉耳蕨 
    42. *Polystichum piceopaleaceum* Tagawa 黑鱗耳蕨 
    43. *Polystichum prionolepis* Hayata 鋸葉耳蕨 

7. **Equisetaceae 木賊科** (1)
    44. *Equisetum ramosissimum* Desf. 木賊 

8. **Hymenophyllaceae 膜蕨科** (2)
    45. *Crepidomanes latealatum* (Bosch) Copel. 翅柄假脈蕨 
    46. *Crepidomanes palmifolium* (Hayata) De Vol 變葉假脈蕨 # (DD)

9. **Plagiogyriaceae 瘤足蕨科** (1)
    47. *Plagiogyria euphlebia* (Kunze) Mett. 華中瘤足蕨 

10. **Polypodiaceae 水龍骨科** (14)
    48. *Lemmaphyllum diversum* (Rosenst.) Tagawa 骨牌蕨 
    49. *Lemmaphyllum microphyllum* C. Presl 伏石蕨 
    50. *Lepisorus monilisorus* (Hayata) Tagawa 擬笈瓦葦 
    51. *Loxogramme formosana* Nakai 臺灣劍蕨 
    52. *Loxogramme grammitoides* (Baker) C. Chr. 小葉劍蕨  (NT)
    53. *Loxogramme remotefrondigera* Hayata 長柄劍蕨 
    54. *Microsorum buergerianum* (Miq.) Ching 波氏星蕨 
    55. *Neocheiropteris ensata* (Thunb.) Ching 扇蕨 
    56. *Polypodium amoenum* Wall. ex Mett. 阿里山水龍骨 
    57. *Polypodium argutum* Wall. ex Hook. 箭葉水龍骨 
    58. *Pyrrosia gralla* (Giesenh.) Ching 中國石葦  (DD)
    59. *Pyrrosia linearifolia* (Hook.) Ching 絨毛石葦 
    60. *Pyrrosia lingua* (Thunb.) Farw. 石葦 
    61. *Pyrrosia sheareri* (Baker) Ching 盧山石葦 

11. **Pteridaceae 鳳尾蕨科** (14)
    62. *Adiantum capillus-veneris* L. 鐵線蕨 
    63. *Adiantum edgeworthii* Hook. 愛氏鐵線蕨 
    64. *Anogramma leptophylla* (L.) Link 翠蕨  (NT)
    65. *Antrophyum formosanum* Hieron. 臺灣車前蕨 
    66. *Coniogramme intermedia* Hieron. 華鳳ㄚ蕨 
    67. *Onychium contiguum* Wall. ex C. Hope 高山金粉蕨 
    68. *Pteris cretica* L. 大葉鳳尾蕨 
    69. *Pteris excelsa* Blume 溪鳳尾蕨 
    70. *Pteris scabristipes* Tagawa 紅柄鳳尾蕨 
    71. *Pteris setulosocostulata* Hayata 有刺鳳尾蕨 
    72. *Pteris wallichiana* J. Agardh 瓦氏鳳尾蕨 
    73. *Vittaria anguste-elongata* Hayata 姬書帶蕨 
    74. *Vittaria flexuosa* Fée 書帶蕨 
    75. *Vittaria taeniophylla* Copel. 廣葉書帶蕨 

12. **Selaginellaceae 卷柏科** (1)
    76. *Selaginella involvens* (Sw.) Spring 密葉卷柏 

13. **Thelypteridaceae 金星蕨科** (3)
    77. *Cyclosorus acuminatus* (Houtt.) Nakai 毛蕨 
    78. *Thelypteris esquirolii* (Christ) Ching 斜葉金星蕨 
    79. *Thelypteris omeiensis* (Baker) Ching 擬茯蕨 

14. **Woodsiaceae 岩蕨科** (5)
    80. *Athyrium anisopterum* Christ 宿蹄蓋蕨 
    81. *Athyrium arisanense* (Hayata) Tagawa 阿里山蹄蓋蕨 
    82. *Athyrium delavayi* Christ 溪谷蹄蓋蕨 
    83. *Athyrium leiopodum* (Hayata) Tagawa 小葉蹄蓋蕨 
    84. *Athyrium subrigescens* (Hayata) Hayata ex H. Itô 姬蹄蓋蕨 


###蕨類植物 Ferns and Lycophytes


15. **Aspleniaceae 鐵角蕨科** (8)
    85. *Asplenium antiquum* Makino 山蘇花 
    86. *Asplenium ensiforme* Wall. ex Hook. & Grev. 劍葉鐵角蕨 
    87. *Asplenium normale* D. Don 生芽鐵角蕨 
    88. *Asplenium planicaule* Wall. ex E.J. Lowe 斜葉鐵角蕨 
    89. *Asplenium tenuicaule* Hayata 小葉鐵角蕨 
    90. *Asplenium tenuifolium* D. Don 薄葉鐵角蕨 
    91. *Asplenium tripteropus* Nakai 三翅鐵角蕨 
    92. *Asplenium wilfordii* Mett. ex Kuhn 威氏鐵角蕨 

16. **Athyriaceae 蹄蓋蕨科** (7)
    93. *Cornopteris decurrenti-alata* (Hook.) Nakai 貞蕨 
    94. *Deparia petersenii* (Kunze) M. Kato 假蹄蓋蕨 
    95. *Diplazium amamianum* Tagawa 奄美雙蓋蕨 
    96. *Diplazium dilatatum* Blume 廣葉鋸齒雙蓋蕨 
    97. *Diplazium kawakamii* Hayata 川上氏雙蓋蕨 
    98. *Diplazium pseudodoederleinii* Hayata 擬德氏雙蓋蕨 
    99. *Diplazium squamigerum* (Mett.) C. Hope 長苞雙蓋蕨 

17. **Cyatheaceae 桫欏科** (1)
    100. *Cyathea spinulosa* Wall. ex Hook. 臺灣桫欏 

18. **Davalliaceae 骨碎補科** (3)
    101. *Araiostegia parvipinnula* (Hayata) Copel. 臺灣小膜蓋蕨 
    102. *Davallia mariesii* T. Moore ex Baker 海州骨碎補 
    103. *Nephrolepis auriculata* (L.) Trimen 腎蕨 

19. **Dennstaedtiaceae 碗蕨科** (3)
    104. *Histiopteris incisa* (Thunb.) J. Sm. 栗蕨 
    105. *Microlepia strigosa* (Thunb.) C. Presl 粗毛鱗蓋蕨 
    106. *Microlepia trichocarpa* Hayata 毛果鱗蓋蕨 # (NT)

20. **Dryopteridaceae 鱗毛蕨科** (21)
    107. *Acrophorus stipellatus* T. Moore 魚鱗蕨 
    108. *Arachniodes aristata* (G. Forst.) Tindale 細葉複葉耳蕨 
    109. *Arachniodes pseudoaristata* (Tagawa) Ohwi 小葉複葉耳蕨 
    110. *Arachniodes rhomboidea* var. *yakusimensis* (H. Itô) W.C. Shieh 屋久複葉耳蕨 
    111. *Cyrtomium caryotideum* (Wall. ex Hook. & Grev.) C. Presl 細齒貫眾蕨 
    112. *Cyrtomium hookerianum* (C. Presl) C. Chr. 狹葉貫眾蕨 
    113. *Cyrtomium taiwanianum* Tagawa 臺灣貫眾蕨  (VU)
    114. *Dryopteris atrata* (Wall. ex Kunze) Ching 桫欏鱗毛蕨 
    115. *Dryopteris formosana* (Christ) C. Chr. 臺灣鱗毛蕨 
    116. *Dryopteris lepidopoda* Hayata 厚葉鱗毛蕨 
    117. *Dryopteris scottii* (Bedd.) Ching 史氏鱗毛蕨 
    118. *Dryopteris sparsa* (D. Don) Kuntze 長葉鱗毛蕨 
    119. *Dryopteris toyamae* Tagawa 外山氏鱗毛蕨  (EN)
    120. *Polystichum acutidens* Christ 臺東耳蕨 
    121. *Polystichum deltodon* (Baker) Diels 對生耳蕨 
    122. *Polystichum hancockii* (Hance) Diels 韓氏耳蕨 
    123. *Polystichum lepidocaulon* (Hook.) J. Sm. 鞭葉耳蕨 
    124. *Polystichum nepalense* (Spreng.) C. Chr. 軟骨耳蕨 
    125. *Polystichum parvipinnulum* Tagawa 尖葉耳蕨 
    126. *Polystichum piceopaleaceum* Tagawa 黑鱗耳蕨 
    127. *Polystichum prionolepis* Hayata 鋸葉耳蕨 

21. **Equisetaceae 木賊科** (1)
    128. *Equisetum ramosissimum* Desf. 木賊 

22. **Hymenophyllaceae 膜蕨科** (2)
    129. *Crepidomanes latealatum* (Bosch) Copel. 翅柄假脈蕨 
    130. *Crepidomanes palmifolium* (Hayata) De Vol 變葉假脈蕨 # (DD)

23. **Plagiogyriaceae 瘤足蕨科** (1)
    131. *Plagiogyria euphlebia* (Kunze) Mett. 華中瘤足蕨 

24. **Polypodiaceae 水龍骨科** (14)
    132. *Lemmaphyllum diversum* (Rosenst.) Tagawa 骨牌蕨 
    133. *Lemmaphyllum microphyllum* C. Presl 伏石蕨 
    134. *Lepisorus monilisorus* (Hayata) Tagawa 擬笈瓦葦 
    135. *Loxogramme formosana* Nakai 臺灣劍蕨 
    136. *Loxogramme grammitoides* (Baker) C. Chr. 小葉劍蕨  (NT)
    137. *Loxogramme remotefrondigera* Hayata 長柄劍蕨 
    138. *Microsorum buergerianum* (Miq.) Ching 波氏星蕨 
    139. *Neocheiropteris ensata* (Thunb.) Ching 扇蕨 
    140. *Polypodium amoenum* Wall. ex Mett. 阿里山水龍骨 
    141. *Polypodium argutum* Wall. ex Hook. 箭葉水龍骨 
    142. *Pyrrosia gralla* (Giesenh.) Ching 中國石葦  (DD)
    143. *Pyrrosia linearifolia* (Hook.) Ching 絨毛石葦 
    144. *Pyrrosia lingua* (Thunb.) Farw. 石葦 
    145. *Pyrrosia sheareri* (Baker) Ching 盧山石葦 

25. **Pteridaceae 鳳尾蕨科** (14)
    146. *Adiantum capillus-veneris* L. 鐵線蕨 
    147. *Adiantum edgeworthii* Hook. 愛氏鐵線蕨 
    148. *Anogramma leptophylla* (L.) Link 翠蕨  (NT)
    149. *Antrophyum formosanum* Hieron. 臺灣車前蕨 
    150. *Coniogramme intermedia* Hieron. 華鳳ㄚ蕨 
    151. *Onychium contiguum* Wall. ex C. Hope 高山金粉蕨 
    152. *Pteris cretica* L. 大葉鳳尾蕨 
    153. *Pteris excelsa* Blume 溪鳳尾蕨 
    154. *Pteris scabristipes* Tagawa 紅柄鳳尾蕨 
    155. *Pteris setulosocostulata* Hayata 有刺鳳尾蕨 
    156. *Pteris wallichiana* J. Agardh 瓦氏鳳尾蕨 
    157. *Vittaria anguste-elongata* Hayata 姬書帶蕨 
    158. *Vittaria flexuosa* Fée 書帶蕨 
    159. *Vittaria taeniophylla* Copel. 廣葉書帶蕨 

26. **Selaginellaceae 卷柏科** (1)
    160. *Selaginella involvens* (Sw.) Spring 密葉卷柏 

27. **Thelypteridaceae 金星蕨科** (3)
    161. *Cyclosorus acuminatus* (Houtt.) Nakai 毛蕨 
    162. *Thelypteris esquirolii* (Christ) Ching 斜葉金星蕨 
    163. *Thelypteris omeiensis* (Baker) Ching 擬茯蕨 

28. **Woodsiaceae 岩蕨科** (5)
    164. *Athyrium anisopterum* Christ 宿蹄蓋蕨 
    165. *Athyrium arisanense* (Hayata) Tagawa 阿里山蹄蓋蕨 
    166. *Athyrium delavayi* Christ 溪谷蹄蓋蕨 
    167. *Athyrium leiopodum* (Hayata) Tagawa 小葉蹄蓋蕨 
    168. *Athyrium subrigescens* (Hayata) Hayata ex H. Itô 姬蹄蓋蕨 


###裸子植物 Gymnosperms


29. **Taxaceae 紅豆杉科** (1)
    169. *Cephalotaxus wilsoniana* Hayata 臺灣粗榧 # (VU)


###雙子葉植物 'Dicotyledons'


30. **Acanthaceae 爵床科** (1)
    170. *Strobilanthes wallichii* Nees 翅柄馬藍 

31. **Actinidiaceae 獼猴桃科** (1)
    171. *Actinidia latifolia* (Gardner & Champ.) Merr. 闊葉獼猴桃  (NT)

32. **Adoxaceae 五福花科** (2)
    172. *Viburnum luzonicum* Rolfe 呂宋莢迷 
    173. *Viburnum taitoense* Hayata 臺東莢迷 

33. **Apocynaceae 夾竹桃科** (3)
    174. *Marsdenia formosana* Masam. 臺灣牛彌菜 
    175. *Trachelospermum formosanum* Y.C. Liu & Ou 臺灣絡石 #
    176. *Tylophora oshimae* Hayata 疏花鷗蔓 #

34. **Araliaceae 五加科** (5)
    177. *Aralia decaisneana* Hance 鵲不踏 
    178. *Eleutherococcus trifoliatus* (L.) S.Y. Hu 三葉五加 
    179. *Hedera rhombea* var. *formosana* (Nakai) H.L. Li 臺灣常春藤 #
    180. *Hydrocotyle setulosa* Hayata 阿里山天胡荽 #
    181. *Sinopanax formosanus* (Hayata) H.L. Li 華參 #

35. **Aristolochiaceae 馬兜鈴科** (1)
    182. *Aristolochia kaempferi* Willd. 大葉馬兜鈴 

36. **Asteraceae 菊科** (5)
    183. *Ainsliaea macroclinidioides* Hayata 阿里山鬼督郵 
    184. *Blumea aromatica* DC. 薄葉艾納香 
    185. *Crassocephalum crepidioides* (Benth.) S. Moore 昭和草 *
    186. *Gynura japonica* (Thunb.) Juel 黃花三七草 
    187. *Senecio scandens* Buch.-Ham. ex D. Don 蔓黃菀 

37. **Berberidaceae 小檗科** (1)
    188. *Mahonia oiwakensis* Hayata 阿里山十大功勞 # (VU)

38. **Boraginaceae 紫草科** (1)
    189. *Cynoglossum furcatum* Wall. 琉璃草 

39. **Brassicaceae 十字花科** (1)
    190. *Cardamine flexuosa* With. 蔊菜 *

40. **Campanulaceae 桔梗科** (2)
    191. *Lobelia nummularia* Lam. 普剌特草 
    192. *Peracarpa carnosa* (Wall.) Hook. f. & Thomson 山桔梗 

41. **Caprifoliaceae 忍冬科** (1)
    193. *Lonicera acuminata* Wall. 阿里山忍冬 

42. **Caryophyllaceae 石竹科** (1)
    194. *Stellaria arisanensis* (Hayata) Hayata 阿里山繁縷 

43. **Celastraceae 衛矛科** (2)
    195. *Celastrus kusanoi* Hayata 大葉南蛇藤 
    196. *Euonymus spraguei* Hayata 刺果衛矛 #

44. **Cucurbitaceae 葫蘆科** (2)
    197. *Gynostemma pentaphyllum* (Thunb.) Makino 絞股藍 
    198. *Zehneria mucronata* Endl. 黑果馬㼎兒 

45. **Elaeagnaceae 胡頹子科** (1)
    199. *Elaeagnus glabra* Thunb. 藤胡頹子 

46. **Elaeocarpaceae 杜英科** (1)
    200. *Elaeocarpus sylvestris* (Lour.) Poir. 杜英 

47. **Ericaceae 杜鵑花科** (4)
    201. *Lyonia ovalifolia* (Wall.) Drude 南燭 
    202. *Rhododendron leptosanthum* Hayata 西施花 
    203. *Rhododendron oldhamii* Maxim. 金毛杜鵑 #
    204. *Vaccinium randaiense* Hayata 巒大越橘 #

48. **Euphorbiaceae 大戟科** (1)
    205. *Mercurialis leiocarpa* Siebold & Zucc. 山靛 

49. **Fabaceae 豆科** (2)
    206. *Dumasia villosa* subsp. *bicolor* (Hayata) H. Ohashi & Tateishi 臺灣山黑扁豆 #
    207. *Hylodesmum laterale* (Schindl.) H. Ohashi & R.R. Mill 琉球山螞蝗 

50. **Fagaceae 殼斗科** (4)
    208. *Castanopsis cuspidata* var. *carlesii* (Hemsl.) T. Yamaz. 長尾尖葉櫧 
    209. *Lithocarpus kawakamii* (Hayata) Hayata 大葉石櫟 #
    210. *Quercus stenophylloides* Hayata 狹葉櫟 #
    211. *Quercus tatakaensis* Tomiya 銳葉高山櫟 #

51. **Gesneriaceae 苦苣苔科** (2)
    212. *Hemiboea bicornuta* (Hayata) Ohwi 臺灣半蒴苣苔 
    213. *Lysionotus pauciflorus* Maxim. 石吊蘭 

52. **Hydrangeaceae 八仙花科** (3)
    214. *Deutzia pulchra* S. Vidal 大葉溲疏 
    215. *Deutzia taiwanensis* Hayata 臺灣溲疏 #
    216. *Hydrangea integrifolia* Hayata 大枝掛繡球 

53. **Lamiaceae 唇形科** (5)
    217. *Callicarpa formosana* Rolfe 杜虹花 
    218. *Clerodendrum trichotomum* Thunb. 海州常山 
    219. *Perilla frutescens* (L.) Britton 紫蘇 *
    220. *Salvia arisanensis* Hayata 阿里山紫花鼠尾草 #
    221. *Teucrium bidentatum* Hemsl. 二齒香科科 

54. **Lardizabalaceae 木通科** (1)
    222. *Stauntonia obovatifoliola* Hayata 石月 

55. **Lauraceae 樟科** (6)
    223. *Beilschmiedia erythrophloia* Hayata 瓊楠 
    224. *Cinnamomum insularimontanum* Hayata 臺灣肉桂 #
    225. *Litsea acuminata* (Blume) Kurata 長葉木薑子 
    226. *Litsea akoensis* Hayata 屏東木薑子 #
    227. *Machilus japonica* Siebold & Zucc. 假長葉楠 
    228. *Neolitsea aciculata* var. *variabillima* J.C. Liao 變葉新木薑子 #

56. **Magnoliaceae 木蘭科** (1)
    229. *Michelia compressa* (Maxim.) Sarg. 烏心石 

57. **Mazaceae 通泉草科** (1)
    230. *Mazus delavayi* Bonati 阿里山通泉草 

58. **Moraceae 桑科** (2)
    231. *Ficus pumila* var. *awkeotsang* (Makino) Corner 愛玉子 #
    232. *Ficus sarmentosa* var. *henryi* (King ex Oliv.) Corner 阿里山珍珠蓮 

59. **Oleaceae 木犀科** (3)
    233. *Jasminum urophyllum* Hemsl. 川素馨 
    234. *Ligustrum sinense* Lour. 小實女貞 
    235. *Osmanthus matsumuranus* Hayata 大葉木犀 

60. **Onagraceae 柳葉菜科** (1)
    236. *Circaea alpina* subsp. *imaicola* (Asch. & Magn.) Kitam. 高山露珠草 

61. **Pentaphylacaceae 五列木科** (3)
    237. *Eurya chinensis* R. Br. 米碎柃木 
    238. *Eurya leptophylla* Hayata 薄葉柃木 #
    239. *Eurya loquaiana* Dunn 細枝柃木 

62. **Piperaceae 胡椒科** (2)
    240. *Peperomia reflexa* Kunth 小椒草 
    241. *Piper kadsura* (Choisy) Ohwi 風藤 

63. **Pittosporaceae 海桐科** (1)
    242. *Pittosporum illicioides* Makino 疏果海桐 

64. **Plantaginaceae 車前科** (2)
    243. *Digitalis purpurea* L. 毛地黃 *
    244. *Ellisiophyllum pinnatum* (Wall. ex Benth.) Makino 海螺菊 

65. **Polygonaceae 蓼科** (2)
    245. *Polygonum chinense* L. 火炭母草 
    246. *Polygonum multiflorum* var. *hypoleucum* (Nakai ex Ohwi) T.S. Liu, S.S. Ying & M.J. Lai 臺灣何首烏 #

66. **Primulaceae 報春花科** (5)
    247. *Ardisia cornudentata* subsp. *morrisonensis* (Hayata) Y.P. Yang 玉山紫金牛 #
    248. *Embelia laeta* (L.) Mez 藤木槲 
    249. *Embelia lenticellata* Hayata 賽山椒 #
    250. *Lysimachia ardisioides* Masam. 臺灣排香 #
    251. *Lysimachia congestiflora* Hemsl. 叢生花珍珠菜 

67. **Ranunculaceae 毛茛科** (2)
    252. *Clematis grata* Wall. 串鼻龍 
    253. *Clematis henryi* Oliv. 亨利氏鐵線蓮 

68. **Rhamnaceae 鼠李科** (2)
    254. *Berchemia formosana* C.K. Schneid. 臺灣黃鱔藤 
    255. *Sageretia thea* (Osbeck) M.C. Johnst. 雀梅藤 

69. **Rosaceae 薔薇科** (7)
    256. *Malus doumeri* (Bois) A. Chev. 臺灣蘋果 
    257. *Pourthiaea beauverdiana* var. *notabilis* (C.K. Schneid.) Hatus. 臺灣老葉兒樹 
    258. *Rubus croceacanthus* H. Lév. 虎婆刺 
    259. *Rubus formosensis* Kuntze 臺灣懸鉤子 
    260. *Rubus kawakamii* Hayata 桑葉懸鉤子 #
    261. *Rubus pectinellus* Maxim. 刺萼寒莓 
    262. *Rubus sumatranus* Miq. 紅腺懸鉤子  (EN)

70. **Rubiaceae 茜草科** (5)
    263. *Damnacanthus indicus* C.F. Gaertn. 伏牛花 
    264. *Galium echinocarpum* Hayata 刺果豬殃殃 #
    265. *Ophiorrhiza japonica* Blume 蛇根草 
    266. *Psychotria serpens* L. 拎壁龍 
    267. *Rubia lanceolata* Hayata 金劍草 #

71. **Rutaceae 芸香科** (3)
    268. *Boenninghausenia albiflora* (Hook.) Rchb. ex Meisn. 臭節草 
    269. *Toddalia asiatica* (L.) Lam. 飛龍掌血 
    270. *Zanthoxylum scandens* Blume 藤花椒 

72. **Salicaceae 楊柳科** (1)
    271. *Xylosma congesta* (Lour.) Merr. 柞木 

73. **Sapindaceae 無患子科** (2)
    272. *Acer albopurpurascens* Hayata 樟葉槭 #
    273. *Acer kawakamii* Koidz. 尖葉槭 

74. **Saxifragaceae 虎耳草科** (1)
    274. *Mitella formosana* (Hayata) Masam. 臺灣嗩吶草 #

75. **Schisandraceae 五味子科** (2)
    275. *Kadsura japonica* (L.) Dunal 南五味子 
    276. *Schisandra arisanensis* Hayata 阿里山五味子 #

76. **Solanaceae 茄科** (1)
    277. *Lycianthes lysimachioides* (Wall.) Bitter 蔓茄 

77. **Symplocaceae 灰木科** (1)
    278. *Symplocos theophrastifolia* Siebold & Zucc. 山豬肝 

78. **Theaceae 茶科** (2)
    279. *Gordonia axillaris* Endl. 大頭茶 
    280. *Schima superba* Gardner & Champ. 木荷 

79. **Urticaceae 蕁麻科** (9)
    281. *Boehmeria pilushanensis* Liu & Lu 畢祿山苧麻 # (VU)
    282. *Debregeasia orientalis* C.J. Chen 水麻 
    283. *Elatostema parvum* (Blume) Miq. 絨莖樓梯草 
    284. *Girardinia diversifolia* (Link) Friis 蠍子草 
    285. *Nanocnide japonica* Blume 花點草 
    286. *Pilea matsudai* Yamam. 細尾冷水麻 #
    287. *Pilea plataniflora* C.H. Wright 西南冷水麻 
    288. *Pilea swinglei* Merr. 三角葉冷水麻  (DD)
    289. *Urtica thunbergiana* Siebold & Zucc. 蕁麻 

80. **Violaceae 堇菜科** (1)
    290. *Viola adenothrix* Hayata 喜岩堇菜 

81. **Vitaceae 葡萄科** (2)
    291. *Ampelopsis brevipedunculata* var. *ciliata* (Nakai) F.Y. Lu 毛山葡萄 
    292. *Tetrastigma umbellatum* (Hemsl.) Nakai 臺灣崖爬藤 #


###單子葉植物 Monocotyledons


82. **Araceae 天南星科** (1)
    293. *Arisaema formosanum* (Hayata) Hayata 臺灣天南星 #

83. **Asparagaceae 天門冬科** (1)
    294. *Ophiopogon intermedius* D. Don 間型沿階草 

84. **Orchidaceae 蘭科** (7)
    295. *Anoectochilus formosanus* Hayata 臺灣金線蓮  (NT)
    296. *Ascocentrum pumilum* (Hayata) Schltr. 鹿角蘭 # (NT)
    297. *Cephalanthera alpicola* Fukuy. 高山頭蕊蘭 
    298. *Gastrochilus formosanus* (Hayata) Hayata 臺灣松蘭 
    299. *Goodyera biflora* (Lindl.) Hook. f. 大花斑葉蘭  (EN)
    300. *Goodyera velutina* Maxim. ex Regel 鳥嘴蓮 
    301. *Nervilia plicata* (Andrews) Schltr. 紫花脈葉蘭  (VU)

85. **Poaceae 禾本科** (4)
    302. *Microstegium fauriei* (Hayata) Honda 法利莠竹 #
    303. *Miscanthus floridulus* (Labill.) Warb. ex K. Schum. & Lauterb. 五節芒 
    304. *Oplismenus hirtellus* (L.) P. Beauv. 求米草 
    305. *Yushania niitakayamensis* (Hayata) Keng f. 玉山箭竹 

86. **Smilacaceae 菝葜科** (4)
    306. *Smilax arisanensis* Hayata 阿里山菝葜 
    307. *Smilax bracteata* C. Presl 假菝葜 
    308. *Smilax china* L. 菝葜 
    309. *Smilax lanceifolia* Roxb. 臺灣土茯苓 

87. **Zingiberaceae 薑科** (1)
    310. *Alpinia shimadae* Hayata 島田氏月桃 #
