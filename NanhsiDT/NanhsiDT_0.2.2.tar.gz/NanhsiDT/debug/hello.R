#' NanhsiDT: A package includes only raw dataset in Nanhsi Forest Dynamics Plot in Taiwan
#'
#' The NanhsiDT package provides datasets including tree, seedling, and understory species assemblages
#' Temporarily, this is only a trial-version
#'
#' @section NanhsiDT functions:
#'
#' @docType package
#' @name NanhsiDT
NULL

load("D:/R/01paper_ssn/data/ssn_us01.RData")
devtools::use_data(compo_us_sp00,us_env00,quad_us_cov)
