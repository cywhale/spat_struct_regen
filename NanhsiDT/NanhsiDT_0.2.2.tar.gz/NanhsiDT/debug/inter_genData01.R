
library(data.table)
library(magrittr)

compo_us_sp00 <-  fread("D:/R/01paper_ssn/raw/00_Final_all_us_sp_composition.csv",na.string="",sep=",")
#setkeyv(compo_us_sp00,c("tag","transect","spcode"))


us_env00 <- fread("D:/R/01paper_ssn/raw/00_Final_transect2009_env03_new_terran.csv",na.string="",sep=",") %>%
  .[,c(1:5,15:27),with=FALSE] %>% setkey(transect)


save(quad_us_cov,compo_us_sp00, us_env00, file="D:/R/01paper_ssn/NanhsiDT/debug/ssn_us01.RData")

source('init_env_sp_cover01.R')
dt <- load_us_spcov()

#############################  tree data
xtree <-  fread("D:/R/01paper_ssn/NanhsiDT/debug/origin/00_Final_xtree.csv",na.string="",sep=",")

xtree[,DBH:= main_cir/pi]
xtree[,BA := pi*(DBH/200)^2 + sprout_ba/10000]

xtree[,strata:=ifelse(layer=="S" & DBH<5, "juven", "adult")]

txy <-  fread("D:/R/01paper_ssn/NanhsiDT/debug/origin/adult_tree_census01_xy00.csv",na.string="")

td0 <- merge(xtree, txy[,2:4,with=F] %>% setnames(1:3,c("tag","x","y")), by="tag", all=T)

which(is.na(td0$x)) #none

tt <- which(td0$x<=(td0$subx-10) | td0$x>(td0$subx+10) )
td0[tt,]

tt1 <- which(td0$y<=(td0$suby-10) | td0$y>(td0$suby+10) )
td0[unique(union(tt,tt1)),]

#qt <- td0[unique(union(tt,tt1)),] %>% .[,c("spcode","DBH", "BA", "strata":=list(NULL))]
#write.table(qt,"D:/R/01paper_ssn/NanhsiDT/debug/tmp/tree_loc_debug01.csv",row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

############## function used in function_cy/eval_func_01.R

cir2ba.01.cy = function(x) sum((na.omit(x)/2/pi)^2)

tree1 <-  fread("D:/R/01paper_ssn/NanhsiDT/debug/origin/Nansi_2011.csv",na.string="",sep=",")

main01 <- tree1[B==0,]
sprout01 <- tree1[B!=0,]
################################# 2011 data needed to be handled further!! wait..

td1 <- merge(td0, main01[,.(species,layer,px,py,Q,S_Q,x_2011,y_2011,tag,DBH_2006,DBH_2011,Area_m2,status,status_death)] %>%
                     setnames(1:4,c("sp_2011","lay_2011","px_2011","py_2011")), by="tag",all.x=TRUE)

tt <- which(td1$x<=(td1$subx-10) | td1$x>(td1$subx+10) )
#td0[tt,]

tt1 <- which(td1$y<=(td1$suby-10) | td1$y>(td1$suby+10) )
qt  <- td1[unique(union(tt,tt1)),]

which(qt$species!=qt$sp_2011)

######################################
library(Rcpp)
sourceCpp("D:/R/example/test_utils01.cpp")
############################################# Final version
subplot2xy <- function(subplot, px, py, grd_sz=10, need_mul_gridsz = TRUE) {

  if (need_mul_gridsz) {
    basex <- px*grd_sz
    basey <- py*grd_sz
  } else {
    basex <- px
    basey <- py
  }
  hsz <- 0.5*grd_sz

  x <- rep(NA_real_,length(subplot))
  y <- rep(NA_real_,length(subplot))
  tt1 <- which(subplot=="1,1" | subplot=="1,2")
  tt2 <- which(subplot=="2,2" | subplot=="2,1")
  x[tt1] <- basex[tt1]
  x[tt2] <- basex[tt2]+hsz

  tt1 <- which(subplot=="2,2" | subplot=="1,2")
  tt2 <- which(subplot=="1,1" | subplot=="2,1")
  y[tt1] <- basey[tt1]+hsz
  y[tt2] <- basey[tt2]

  list(x=x, y=y)
}

############ only Trial
subplot2xy_v2 <- function(subplot, px, py, grd_sz=10, need_mul_gridsz = TRUE) {

  if (need_mul_gridsz) {
    basex <- px*grd_sz
    basey <- py*grd_sz
  } else {
    basex <- px
    basey <- py
  }
  hsz <- 0.5*grd_sz

  x <- ifelse(subplot=="1,1" | subplot=="1,2", basex,
              ifelse(subplot=="2,2" | subplot=="2,1", basex+hsz, NA))
  y <- ifelse(subplot=="2,2" | subplot=="1,2", basey+hsz,
              ifelse(subplot=="1,1" | subplot=="2,1", basey, NA))

  list(x=x, y=y)
}

# cannot work
#subplot2xy_vc <- function(subplot, px, py, grd_sz=10, need_mul_gridsz = TRUE) {
#
#  if (need_mul_gridsz) {
#    basex <- px*grd_sz
#    basey <- py*grd_sz
#  } else {
#    basex <- px
#    basey <- py
#  }
#  hsz <- 0.5*grd_sz

#  vt <- vcondif(subplot=="1,1", c(x=basex, y=basey),
#        vcondif(subplot=="1,2", c(x=basex, y=basey+hsz),
#        vcondif(subplot=="2,2", c(x=basex+hsz, y=basey+hsz),
#        vcondif(subplot=="2,1", c(x=basex+hsz, y=basey), c(x=NA, y=NA)))))

#  as.list(x=vt[1], y=vt[2])
#}

#### very slow ############################################################
subplot2xy_v3 <- function(subplot, px, py, grd_sz=10, need_mul_gridsz = TRUE) {

  if (need_mul_gridsz) {
    basex <- px*grd_sz
    basey <- py*grd_sz
  } else {
    basex <- px
    basey <- py
  }
  hsz <- 0.5*grd_sz

  f <- function(x, hsz) {
    vcondif(x$subplot=="1,1", c(x=x$basex, y=x$basey),
    vcondif(x$subplot=="1,2", c(x=x$basex, y=x$basey+hsz),
    vcondif(x$subplot=="2,2", c(x=x$basex+hsz, y=x$basey+hsz),
    vcondif(x$subplot=="2,1", c(x=x$basex+hsz, y=x$basey), c(x=NA, y=NA)))))
  }
#  f <- function(x, hsz) {
#           ifelse(rep(x$subplot=="1,1",2), list(x$basex, x$basey),
#           ifelse(rep(x$subplot=="1,2",2), list(x$basex, x$basey+hsz),
#           ifelse(rep(x$subplot=="2,2",2), list(x$basex+hsz, x$basey+hsz),
#           ifelse(rep(x$subplot=="2,1",2), list(x$basex+hsz, x$basey), list(NA, NA)))))
#  }

  dt <- data.table::data.table(subplot=subplot, basex=basex, basey=basey)

  purrr::transpose(lapply(1:nrow(dt), function(x,hsz) {
    f(dt[x,],hsz)
  }, hsz=hsz))
}
#### very slow ############################################################

library(microbenchmark)
dt1 <- td1[,.(tag, S_Q, px_2011, py_2011)]
dt2 <- copy(dt1)

microbenchmark(
  "method_repl" = dt1[,c("subx_2011","suby_2011"):=subplot2xy(S_Q, px_2011, py_2011, 10)],
  "method_ifel" = dt2[,c("subx_2011","suby_2011"):=subplot2xy_v2(S_Q, px_2011, py_2011, 10)]
)

#Unit: milliseconds
#expr      min       lq     mean   median       uq      max neval
#method_repl 2.787090 2.915843 4.124739 2.983908 4.537980 68.29784   100
#method_ifel 6.102744 7.731658 9.911051 7.852580 8.014162 75.97092   100

all.equal(dt1[,c("subx_2011","suby_2011"):=subplot2xy(S_Q, px_2011, py_2011, 10)],
          dt2[,c("subx_2011","suby_2011"):=subplot2xy_v2(S_Q, px_2011, py_2011, 10)])
#[1] TRUE

td1[,c("subx_2011","suby_2011"):=subplot2xy(S_Q, px_2011, py_2011, 10)]

#tt <- which(td1$x<=(td1$subx-10) | td1$x>(td1$subx+10) )
#tt1<- which(td1$y<=(td1$suby-10) | td1$y>(td1$suby+10) )

setnames(td1,c(3:7,16:17),c("sp_2006","px_2006","py_2006","subx_2006","suby_2006","x_2006","y_2006"))
td1[,c("species","px","py","subx","suby","x","y"):=list(
  ifelse(is.na(sp_2006) | sp_2006=="" | (!is.na(sp_2011) & sp_2011!="" & sp_2006!=sp_2011), sp_2011, sp_2006),
  ifelse(is.na(px_2006) | (!is.na(px_2011) & px_2006!=px_2011 & 
                           (is.na(status_death) | tolower(substr(status_death,1,1))!="d" | x_2006<=(subx_2006-10) | x_2006>(subx_2006+10))), px_2011, px_2006),
  ifelse(is.na(py_2006) | (!is.na(py_2011) & py_2006!=py_2011 & 
                           (is.na(status_death) | tolower(substr(status_death,1,1))!="d" | y_2006<=(suby_2006-10) | y_2006>(suby_2006+10))), py_2011, py_2006),
  ifelse(is.na(subx_2006) | (!is.na(subx_2011) & subx_2006!=subx_2011 & 
                             (is.na(status_death) | tolower(substr(status_death,1,1))!="d" | x_2006<=(subx_2006-10) | x_2006>(subx_2006+10))), subx_2011, subx_2006),
  ifelse(is.na(suby_2006) | (!is.na(suby_2011) & suby_2006!=suby_2011 & 
                             (is.na(status_death) | tolower(substr(status_death,1,1))!="d" | y_2006<=(suby_2006-10) | y_2006>(suby_2006+10))), suby_2011, suby_2006),
  ifelse(is.na(x_2006) | (!is.na(x_2011) & x_2006!=x_2011 & 
                          (is.na(status_death) | tolower(substr(status_death,1,1))!="d" | x_2006<=(subx_2006-10) | x_2006>(subx_2006+10))), x_2011, x_2006),
  ifelse(is.na(y_2006) | (!is.na(y_2011) & y_2006!=y_2011 & 
                          (is.na(status_death) | tolower(substr(status_death,1,1))!="d" | y_2006<=(suby_2006-10) | y_2006>(suby_2006+10))), y_2011, y_2006)
)]

# update columns/variables to 2011 version (original 2006 version)
td1[,c("upt_sp_06_11","upt_plot_06_11","upt_subp_06_11","upt_loc_06_11"):=list(
  ifelse(!is.na(species) & species !="" & species!=sp_2006 & species==sp_2011, 1, 0),
  ifelse((!is.na(px) & px!=px_2006 & px==px_2011) |
         (!is.na(py) & py!=py_2006 & py==py_2011), 1, 0),
  ifelse((!is.na(subx) & subx!=subx_2006 & subx==subx_2011) |
         (!is.na(suby) & suby!=suby_2006 & suby==suby_2011), 1, 0),
  ifelse((!is.na(x) & x!=x_2006 & x==subx_2011) |
         (!is.na(y) & y!=y_2006 & y==suby_2011), 1, 0)
)]

td1[,tplot:=ifelse(upt_plot_06_11==1,paste("q",px,py,sep="_"),tplot)]

tsp_lst <- fread("D:/backup/bak_paper/2012_transect_2009/raw_data/00_tree_species_allist.csv")
tsp_lst[species=="臺灣楜樗",]$species <- "臺灣糊樗"
setnames(tsp_lst,11,"spcode")

compo_tree_sp00 <- copy(td1) %>% .[,.(tag,tplot,species,main_cir, sprout_n, sprout_ba,
                                      layer, DBH, BA, strata,
                                      lay_2011, DBH_2011, Area_m2,
                                      x, y, px, py, subx, suby,
                                      upt_sp_06_11, upt_plot_06_11, upt_subp_06_11)] %>%
  setnames(c(7:10,13),c("lay_2006","DBH_2006","BA_2006","strata_2006","BA_2011")) %>%
  merge(tsp_lst[,.(species,family_latin,spcode)], by="species", all.x=TRUE) %>%
  setnames(23,"family") %>%
  .[,strata_2011:=ifelse(lay_2011=="S" & DBH_2011<5, "juven", "adult")] %>%
  .[,.(tag,tplot,spcode, species, family,
       main_cir, sprout_n, sprout_ba,
       lay_2006, DBH_2006, BA_2006, strata_2006,
       lay_2011, DBH_2011, BA_2011, strata_2011,
       x, y, px, py, subx, suby,
       upt_sp_06_11, upt_plot_06_11, upt_subp_06_11)]

setkey(compo_tree_sp00,tag)
compo_tree_sp00 <- unique(compo_tree_sp00)

compo_tree_sp00 <- compo_tree_sp00[-which(is.na(species)),]

tt <- which(is.na(match(compo_tree_sp00$tag,xtree$tag)))
compo_tree_sp00[tt[1:5],]


compo_tree_sp06 <- compo_tree_sp00[,.(tag,tplot,spcode, species, family,
                                      main_cir, sprout_n, sprout_ba,
                                      lay_2006, DBH_2006, BA_2006, strata_2006,
                                      x, y, px, py, subx, suby)] %>%
  setnames(9:12,c("layer","DBH","BA","strata")) %>% setkey(tag)

compo_tree_sp06 <- unique(compo_tree_sp06)

which(duplicated(compo_tree_sp06$tag))
#integer(0)

which(is.na(match(xtree$tag,compo_tree_sp06$tag)))
#integer(0)

compo_tree_sp06 <- compo_tree_sp06[-which(is.na(main_cir)),]

which(is.na(match(compo_tree_sp06$tag,xtree$tag)))
#integer(0)

compo_tree_sp06[,strata:=NULL]
compo_tree_sp06[,BA:=NULL]
#compo_tree_sp06[,species:=NULL]
compo_tree_sp06[,family:=NULL]

which(!compo_tree_sp06$tag %in% xtree$tag)
#integer(0)
which(!xtree$tag %in% compo_tree_sp06$tag)
#integer(0)

which(duplicated(xtree$tag))
##[1]  1186  4222  7827  7829  8510 11217 13082 14670 16889 17067 18748
##

td2 <- copy(compo_tree_sp06)

tt <- which(td2$x<=(td2$subx-10) | td2$x>(td2$subx+10) )
#td0[tt,]

tt1 <- which(td2$y<=(td2$suby-10) | td2$y>(td2$suby+10) )
qt2 <- td2[unique(union(tt,tt1)),]

### We cannot exactly match 
qt2
#tag   tplot spcode    species main_cir sprout_n sprout_ba layer      DBH        x        y px py subx suby
#1: 6120 q_24_38 litsac 長葉木薑子      3.5        0 0.0000000     S 1.114085 265.9869 335.4958 24 38  240  380
#2: 8786 q_20_33 rhodla     西施花      7.5        1 0.4468264     S 2.387324 213.4936 369.5888 20 33  200  335
tree1[match(qt2$tag,tree1$tag),]
#remark_confirm remark_retag remark_small_DBH remark_question_btw_survey12 remark_stem2006
#1:             NA           NA               NA                           NA               v
#2:             NA           NA               NA                           NA               v
#remark_status_exist_2011 remark_use_data_2011 px py     Q S_Q   x_2011   y_2011  tag B    species
#1:                       NA                   NA 24 38 24,38 1,1 265.9869 335.4958 6120 0 長葉木薑子
#2:                       NA                   NA 20 33 20,33 1,2 213.4936 369.5888 8786 0     西施花
#DBH_2006 status DBH_2011 Area_m2 Plant community Code-C Code-I Code-P Code-R status_death status_animal
#1: 1.114084602     -1        0       0              A4     NA     NA     NA     NA           NA            NA
#2: 2.387324146     -1        0       0              A2     NA     NA     NA     NA           NA            NA
#status_animal_direction status_animal_range status_vine status_vine_direction status_vine_abund layer
#1:                      NA                  NA          NA                    NA                NA     S
#2:                      NA                  NA          NA                    NA                NA     S
#Note2011 Note2006 remark_check remark_data_2006
#1:       NA       NA           NA               NA
#2:       NA      MS_            3            21,36         NA            NA                      NA                  NA          NA

compo_tree_sp06 <- compo_tree_sp06[-which(tag==6120),]
compo_tree_sp06 <- compo_tree_sp06[-which(tag==8786),]

nrow(xtree)
#[1] 18766
nrow(compo_tree_sp06)
#[1] 18753

tt <- compo_tree_sp06[which(is.na(x)),]
#tag   tplot spcode      species main_cir sprout_n sprout_ba layer      DBH  x  y px py subx suby
#1:  7153 q_22_37 castca       長尾栲     23.4        0         0    T2 7.448451 NA NA 22 37  225  370
#2:  8281 q_24_37 pourbe 臺灣老葉兒樹      4.1        0         0     S 1.305071 NA NA 24 37  240  370
#3: 18104 q_26_27 machsp     假長葉楠      9.2        0         0     S 2.928451 NA NA 26 27  265  270
#4: 18762 q_11_32 machsp       青葉楠      7.7        0         0     S 2.450986 NA NA 11 32  115  320
tree1[tag %in% tt$tag,]
#x_2011 y_2011   tag B      species    DBH_2006 status DBH_2011 Area_m2
#1:     NA     NA 18104 0     假長葉楠 2.928450953     -1        0       0
#2:     NA     NA 18762 0       青葉楠 2.450986124      0        0       0
#3:     NA     NA  7153 0       長尾栲         7.4     -1        0       0
#4:     NA     NA  8281 0 臺灣老葉兒樹 1.305070533      0        0       0
#Plant community Code-C Code-I Code-P Code-R status_death status_animal
#1:              NA     NA     NA     NA     NA           Dm            NA
#2:              A4     NA     NA     NA     NA           Db            NA
#3:              NA     NA     NA     NA     NA           NA            NA
#4:              A4     NA     NA     NA     NA           Ds




td1[match(tt$tag,td1$tag),]

######################################

sp06 <- unique(compo_tree_sp06$species)

tree_chk_not_accept <- c(
"長尾栲",
"樟葉楓",
"尖葉楓",
"松田氏女貞",
"通草")

tree_chk_accept <- c(
"長尾尖葉櫧",
"樟葉槭",
"尖葉槭",
"小實女貞",
"通脫木")

write.table(data.frame(sp=sp06),file="D:/R/01paper_ssn/NanhsiDT/debug/output/list_tree_sp06.csv",
            quote=FALSE, sep=",",na="",row.names=FALSE,col.names=FALSE,fileEncoding="UTF-8")

library(odbapi)

# old.localle <- Sys.getlocale()
#Sys.setlocale(locale="C")

splst2dat <- function (filename) {
  conn <- file(filename,open="r")
  linn <- readLines(conn, encoding="UTF-8")
  spdt <- data.table(sciname=character(),sp_tw=character(),family=character(),family_tw=character(), spcode=character())
  Encoding(spdt$sp_tw) <- "UTF-8"
  Encoding(spdt$family_tw) <- "UTF-8"
  
  family <- NA_character_
  family_tw <- NA_character_
  for (i in 1:length(linn)){
    wl1 <- regexpr("[a-zA-Z]",linn[i])
    wl2 <- regexpr("[\u4e00-\u9fff]+",linn[i])
    if (wl1[1]==-1 | wl2[1]<=2) next
    
    scin<- gsub("\\s+$","",substr(linn[i],wl1[1],wl2[1]-1))
    hann<- gsub("\\s+$","",substr(linn[i],wl2[1],wl2[1]+attributes(wl2)$match.length))
    
    if (substr(hann,attributes(wl2)$match.length,attributes(wl2)$match.length)=="科") {
      family <-  scin
      family_tw <- hann
      next
    }
    
    wl3 <- regexpr("\\s",scin)[1]
    spc <- tolower(paste0(substr(scin,1,4),substr(scin,wl3+1,wl3+2)))
    spdt<- rbindlist(list(spdt,data.table(sciname=scin, sp_tw=hann, family=family, family_tw=family_tw, spcode=spc)))
  }
  close(conn)

  require(odbapi)  
  spdt[,spname:=odbapi::sciname_simplify(sciname, trim.var_sp = TRUE, simplify_two= TRUE)]
  
  return(spdt)
}

filet <- "D:/R/01paper_ssn/NanhsiDT/debug/output/list_tree_sp06_sciname.txt"
filet <- "/media/cywhale/data/R/01paper_ssn/NanhsiDT/debug/output/list_tree_sp06_sciname.txt"

spdt <- splst2dat(filet)

which(duplicated(spdt$spcode))

data(compo_us_sp00)

spus <- unique(compo_us_sp00$species)

write.table(data.frame(sp=spus),file="D:/R/01paper_ssn/NanhsiDT/debug/output/list_us_sp09.csv",
            quote=FALSE, sep=",",na="",row.names=FALSE,col.names=FALSE,fileEncoding="UTF-8")

us_chk_not_accept <- c("平柄蹄蓋蕨",
  "臺灣珍珠菜",
  "南蛇藤屬",
  "薄瓣懸鉤子",
  "臺灣石吊蘭",
  "臺灣土伏苓",
  "楨楠屬",
  "北五味子",
  "長尾栲",
  "咬人貓",
  "松田氏女貞",
  "翅柄馬蘭",
  "假菝契",
  "擬水龍骨",
  "華鳳了蕨",
  "狹基鉤毛蕨",
  "阿里山鼠尾草",
  "菝契",
  "喜岩菫菜",
  "刺蔥",
  "阿里山菝契",
  "黑果馬皎兒",
  "腺萼懸鉤子",
  "小膜蓋蕨",
  "毛苞鱗蓋蕨",
  "假毛蕨",
  "脈葉蘭屬",
  "尾葉山素英",
  "鉤毛蕨屬",
  "臺灣牛嬭菜",
  "樟葉楓",
  "小鹿角蘭",
  "角桐草"
  )

us_chk_accept <- c("小葉蹄蓋蕨",
  "叢生花珍珠菜",
  "大葉南蛇藤", ###暫代
  "虎婆刺",
  "石吊蘭",
  "臺灣土茯苓",
  "假長葉楠", ###暫代
  "阿里山五味子",
  "長尾尖葉櫧",
  "蕁麻",
  "小實女貞",
  "翅柄馬藍",
  "假菝葜",
  "箭葉水龍骨",
  "華鳳ㄚ蕨",
  "擬茯蕨",
  "阿里山紫花鼠尾草",
  "菝葜",
  "喜岩堇菜",
  "鵲不踏",
  "阿里山菝葜",
  "黑果馬㼎兒",
  "紅腺懸鉤子",
  "臺灣小膜蓋蕨",
  "毛果鱗蓋蕨",
  "斜葉金星蕨",
  "紫花脈葉蘭", ###暫代
  "川素馨",
  "毛蕨",        ###暫代 毛蕨屬 <-- 鉤毛蕨屬
  "臺灣牛彌菜",
  "樟葉槭",
  "鹿角蘭",
  "臺灣半蒴苣苔"
)

filet <- "D:/R/01paper_ssn/NanhsiDT/debug/output/list_us_sp09_sciname.txt"
dirt  <- "D:/R/01paper_ssn/NanhsiDT/debug/output/"
filet <- "/media/cywhale/data/R/01paper_ssn/NanhsiDT/debug/output/list_us_sp09_sciname.txt"
dirt  <- "/media/cywhale/data/R/01paper_ssn/NanhsiDT/debug/output/"

spdu <- splst2dat(filet) %>% unique()

which(duplicated(spdu$spcode))
#[1]  6 60

spdu$spcode[6] <- "asplt2" #asplte
spdu$spcode[60]<- "pyrrl2" #pyrrli

spdt[,ori_tw:=sp_tw]
tt <- spdt$ori_tw[which(spdt$sp_tw %in% tree_chk_accept)] 
spdt$ori_tw[which(spdt$sp_tw %in% tree_chk_accept)] <- tree_chk_not_accept[match(tt,tree_chk_accept)]

spdu[,ori_tw:=sp_tw]
tt <- spdu$ori_tw[which(spdu$sp_tw %in% us_chk_accept)] 
spdu$ori_tw[which(spdu$sp_tw %in% us_chk_accept)] <- us_chk_not_accept[match(tt,us_chk_accept)]

us_replace_genus <- c("大葉南蛇藤", ###暫代
  "假長葉楠", ###暫代
  "紫花脈葉蘭", ###暫代
  "毛蕨")        ###暫代 毛蕨屬 <-- 鉤毛蕨屬)

spdu[spdu$sp_tw %in% us_replace_genus, spname:=paste0(substr(spname,1,regexpr("\\s",spname)-1)," spp.")]
spdu[spdu$sp_tw %in% us_replace_genus, sciname:=spname]
spdu[spdu$sp_tw %in% us_replace_genus, spcode:=paste0(substr(spcode,1,4),"sp")]

tt <-which(spdu$sp_tw %in% us_replace_genus)
spdu[tt, sp_tw:=ori_tw]
spdu[tt,]

write.table(spdu,file=paste0(dirt,"dat_us_sp09.csv"),
            quote=FALSE, sep=",",na="",row.names=FALSE,col.names=TRUE,fileEncoding="UTF-8")

write.table(spdt,file=paste0(dirt,"dat_tree_sp06.csv"),
            quote=FALSE, sep=",",na="",row.names=FALSE,col.names=TRUE,fileEncoding="UTF-8")

#==============================

sp_tree <- copy(tsp_lst)
sp_tree[,code0:=NULL]
sp_tree[,sp_code:=NULL]
setnames(sp_tree,1:2,c("family","family_tw"))

save(compo_tree_sp06, sp_tree, file="D:/R/01paper_ssn/NanhsiDT/debug/ssn_tree2006.RData")

## rewrite NanhsiDT dataset

devtools::use_data(compo_us_sp00, overwrite=TRUE)
devtools::use_data(quad_us_cov, overwrite=TRUE)
devtools::use_data(us_env00, overwrite=TRUE)
devtools::use_data(compo_tree_sp06, overwrite=TRUE)
devtools::use_data(sp_tree, overwrite=TRUE)

