

library(data.table)

#require(XLConnect)
#df1 <- try(XLConnect::readWorksheet(loadWorkbook(xt$datapath), sheet = "1", header = TRUE), silent=T)
spl0 <- try(readxl::read_excel("D:/backup/bak_prj/understory_prj/raw_data/understory_10_species.xls", sheet = 1), silent = TRUE)
setDT(spl0)

spl0[,spcode:=tolower(Sp_code)]

library(NanhsiDT)
data(compo_us_sp00)

dt <- compo_us_sp00[,.(spcode,family)] %>% unique() %>%
      merge(spl0[,.(spcode,scientific_name)], by="spcode")



trim.01 <- function (x) gsub("^\\s+|\\s+$", "", as.character(x))
## Trim leading or trailing non-alphabet/number characters
trim.02 <- function (x) gsub("^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$", "", x)
trim.02n<- function (x) gsub("^[^a-zA-Z]+|[^a-zA-Z]+$", "", x)

trim.01a <- function (x) ifelse(is.na(x),"",gsub("^\\s+|\\s+$|NA+$", "", as.character(x)))

first_word.01 <- function (x) {
  trimx <- trim.02(trim.01(x))
  wl <- regexpr("^[a-zA-Z-]+",trimx)
  return(substr(trimx,wl,attributes(wl)$match.length))
}

preword_bracket.01 <- function (x) {
  trimx <- trim.02n(trim.01(x))
  wl <- regexpr("\\(",paste0(trimx,"("))
  wl2<- regexpr("\\)",paste0(trimx,")"))
  return(trim.02n(trim.01(substr(trimx,1,pmin(wl,wl2)-1))))
}

############ test gsub regex in R
#gsub("\\b((sp\\.)+$)|\\b((spp\\.)+$)|((\\w{0,})\\.+$)","\\2\\4\\6",c("aaa sp.", "aaa sp.bb", "aaasp.bb de","aaa w2sp.", "aaa www spp. ", "spp.","bb.", "XXX sp. ", "YYY spp.", "ZZZZ.."), perl=T)
#[1] "aaa sp."       "aaa sp.bb"     "aaasp.bb de"   "aaa w2sp"
#[5] "aaa www spp. " "spp."          "bb"            "XXX sp. "
#[9] "YYY spp."      "ZZZZ"

#gsub("^[^a-zA-Z]+|(?!\\.)[^a-zA-Z]+$|\\b((sp\\.)+$)|\\b((spp\\.)+$)|((\\w{0,})\\.+$)","\\2\\4\\6",
#     c("33aaa sp.", "aaa sp.bb33", "aaasp.bb 33 de","aaa w2sp.", "aaa www spp. ", "spp.","bb.", "XXX sp. ", "YYY spp.()", "ZZZZ.."), perl=T)
#[1] "aaa sp."        "aaa sp.bb"      "aaasp.bb 33 de" "aaa w2sp"       "aaa www spp."
#[6] "spp."           "bb"             "XXX sp."        "YYY spp."       "ZZZZ"

############ modified from word_pre_bracket, delete xxx; so that the scientific name can be more accurate
############ change 'v' to 'var'
############ sympplify_tw : take first two words
sciname_simplify <- function (x, trim.dummy_num = TRUE,
                              trim.spp_abbrev= FALSE,
                              trim.auther_year_in_bracket = TRUE,
                              trim.var_sp = FALSE, pattern.var_sp = "var.",
                              simplify_two = FALSE) {
  if (length(x)==0) return(c())
  if (all(is.na(x))) return(rep(NA_character_, length(x)))

  trimx <- gsub("^\\s+|\\s+$", "", gsub("\\s{1,}", " ", as.character(x)))

  if (trim.dummy_num) {
    #trimx<- gsub("^[^a-zA-Z]+|[^a-zA-Z]+$", "", trimx)
    trimx <- gsub("^[^a-zA-Z]+|(?!\\.)[^a-zA-Z]+$","", trimx, perl=TRUE)
  } else {
    #trimx<- gsub("^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$", "", trimx)
    trimx <- gsub("^[^a-zA-Z0-9]+|(?!\\.)[^a-zA-Z0-9]+$", "", trimx, perl=TRUE)

  }
  if (trim.spp_abbrev) {
    trimx <- gsub("\\b(sp\\.)|\\b(spp\\.)","",trimx)
  } else {
    trimx <- gsub("\\b((sp\\.)+$)|\\b((spp\\.)+$)|((\\w{0,})\\.+$)","\\2\\4\\6", trimx, perl=TRUE)
  }

  if (simplify_two) {
    #wlx <- nchar(trimx)+1
    wl1 <- attributes(regexpr("^[a-zA-Z0-9\\.]+",trimx))$match.length
    wl2 <- regexpr("\\s\\b[a-zA-Z0-9\\-\\.]+(?:\\s|$)",trimx, perl=T)
    wl2[wl2>0] <- wl2[wl2>0]+attributes(wl2)$match.length[wl2>0]-1
    #wl2[wl2<0] <- nchar(trimx[which(wl2<0)])+1
    wlx <- pmax(wl1,wl2)
    if (trim.dummy_num) {
      #trimx<- gsub("^[^a-zA-Z]+|[^a-zA-Z]+$", "", trimx)
      return(gsub("^[^a-zA-Z]+|(?!\\.)[^a-zA-Z]+$","", substr(trimx,1,wlx), perl=TRUE))
    } else {
      return(substr(trimx,1,wlx))
    }
  }

  trimx <- gsub("\\sv{1}(?:\\.{0,}|ar{0,1}\\.{0,})\\s", paste0(" ",pattern.var_sp," "), trimx)

  wlx <- nchar(trimx)+1
  if (trim.auther_year_in_bracket) {
    wl  <- regexpr("\\(",paste0(trimx,"("))
    wl1 <- regexpr("(?:\\s|\\spage\\s)[a-zA-Z0-9]+(?:;|\\))",trimx)  ### ex: "Phalacroma rotundatum Lachmann) Kofoid And Michener ]- "
    wl1[wl1<0] <- nchar(trimx[which(wl1<0)])+1
    wl2 <- regexpr("\\s\\)",paste0(trimx," )"))
    wl3 <- regexpr(paste0("\\s",pattern.var_sp, "(?:\\s{1}[a-zA-Z]+\\s{0,1})"),trimx)   ## ex: "Ceratium vultur var sumatranum Steeman Nielsen; 1934)"
    wl3[wl3>0] <- wl3[wl3>0]+attributes(wl3)$match.length[wl3>0]
    wl3[wl3<0] <- nchar(trimx[which(wl3<0)])+1
    wlx <- pmin(wl,wl1,wl2,wl3)
  }
  if (trim.var_sp) {
    wl4 <- regexpr(paste0("\\s",pattern.var_sp, "(?:\\s{1}[a-zA-Z]+\\s{0,1})"),trimx)
    wl4[wl4<0] <- nchar(trimx[which(wl4<0)])+1
    wlx <- pmin(wlx,wl4)
  }

  return(gsub("\\s+$", "", substr(trimx,1,wlx-1)))
}


dt[,sciname := sciname_simplify(scientific_name, simplify_two = TRUE)]

taxaname <- unique(dt$sciname)



