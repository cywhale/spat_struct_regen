#20160825 modified for new NanhsiDT
library(NanhsiDT)

data(us_env00)      # in NanhsiDT dataset for basic env
data(compo_us_sp00)

## for only one transect using PCNM
## modified 2013/06, for the issue of min distance required for min spanning tree in PCNM

#dir1="d:/ecology/Dropbox/R/01paper_transect2009/"
#dir2="d:/ecology/Dropbox/Nanhsi_survey/2012_transect2009/"
#rdir = "D:/ecology/Dropbox/R/"

#raw_d  = paste(dir2,"raw_data/",sep="")
#out_d  = paste(dir1,"analysis/",sep="")


#setwd("D:/ecology/R/function_book/applied_spatial_statistics/")
#source ("D:/ecology/R/function_book/applied_spatial_statistics/spatial_backup_run.R")
library(ape)
library(packfor)  # https://r-forge.r-project.org/R/?group_id=195
library(spacemakeR)  # https://r-forge.r-project.org/R/?group_id=195
library(ade4)
library(spdep)
library(vegan)
library(AEM)  # https://r-forge.r-project.org/R/?group_id=195
library(PCNM)  # https://r-forge.r-project.org/R/?group_id=195
#source(paste(rdir,"function_book/numerical_ecology/func/plot.links.R",sep=""))  # Function must be in working directory
#source(paste(rdir,"function_book/numerical_ecology/func/sr.value.R",sep=""))    # Function must be in working directory
#source(paste(rdir,"function_cy/plot_01.R",sep=""))
#source(paste(rdir,"function_cy/eval_func_01.R",sep=""))
#source(paste(rdir,"function_cy/string_01.R",sep="")) ## dummy variable:helmert_code.cy.01
### source("d:/ecology/Dropbox/R/function_cy/quadrat_analysis_01.R")
#### source("d:/ecology/R/01paper_transect2009/ana_nmds_ivi_01.R")
### source("d:/ecology/Dropbox/R/function_cy/spatial_analysis_01.R")

## Create matrix of polygon centroids
#source("d:/ecology/Dropbox/R/01paper_transect2009/init_sdl_sp_sub01.R")

# 201402 try quickPCNM to see result different?
# xt = "K:/chiyu/ecology/temp/90_PCNM__us02try_quickPCNM.rda"

#xt = paste(out_d,"90_PCNM__obj201202_03.rda",sep="")     #201307 divide adult,juvenile
#####save.image(xt)
#load(xt)

#xt = paste(raw_d,"00_Final_all_us_sp_composition.csv",sep="")
#xall = read.table(xt,header=T,na.string="",sep=",")
## write.table(xall, xt, sep=",", col.names=T, row.names=F, na="")

#t = which(substr(xall$tag,1,1)=="t")
#pt= which(substr(xall$tag,1,1)=="u" & xall$lifeform=="T")

#xsdl  = xall[t,] ## 201309 modified
#t=union(t,pt)
#xres  = xall[-t,]
#xus0 = t(Pc)

xsdl <- compo_us_sp00[substr(tag,1,1)=="t",]; nrow(xsdl)
xres <- compo_us_sp00[!(substr(tag,1,1)=="t" | (substr(tag,1,1)=="u" & lifeform=="T")),]; nrow(xres)

xt <- quadDT_cov(xres[,.(transect,spcode,coverage,height)], idvar= c("transect","spcode"), measvar= "height", covar= "coverage", adjMax=FALSE)
xus0 <- dcast(xt, transect ~ spcode, value.var = "coverage", fill=0)

transect <- xus0$transect
xus0 <- data.table(xus0[,-1,with=F], keep.rownames = TRUE)
row.names(xus0) <- transect
dim(xus0)

###################### del rare species, but do it when extract each line transect
###################### modified 2013/07
tt=apply(xus0,2,function(x) {length(which((!is.na(x))&(x!=0)))})
st=apply(xus0,2,sum, na.rm=T)
par(mfcol=c(1,2))
hist(tt,50)
hist(st,50)
deluc.idx = which(tt<2 & st<=1) ###### del species, please check it
us.new = xus0[,-deluc.idx,with=F]

# but now check whic site has no species after del rare species
tt1=apply(xus0,1,function(x) {length(which((!is.na(x))&(x!=0)))}); length(which(tt1==0))
tt2=apply(us.new,1,function(x) {length(which((!is.na(x))&(x!=0)))}); length(which(tt2==0))
hist(tt1,50)
hist(tt2,50)
tt1=apply(xus0,2,function(x) {length(which((!is.na(x))&(x!=0)))}); length(which(tt1==0))
tt2=apply(us.new,2,function(x) {length(which((!is.na(x))&(x!=0)))}); length(which(tt2==0))

#=================================================================

#xres.h <- decostand (t(Pc), "hellinger")
## 2013/05 modified , del rare sp
xres.h <- decostand (us.new, "hellinger", na.rm=T)

# modified 201608
data(us_env00)

#=============================================================== Old

### modified 2013/4 #################################################
#xt = paste(out_d,"00_Final_transect2009_env05_liw.csv",sep="")
#uenv4= read.table(xt,header=T,na.string="",sep=",")
###xt = paste(out_d,"00_Final_transect2009_env07_trssh.csv",sep="")  # 2013/08 modified
#xt = paste(out_d,"00_Final_transect2009_env07_newall.csv",sep="")

#write.table(uenv4, xt, sep=",", col.names=T, row.names=F, na="")
#uenv5= read.table(xt,header=T,na.string="",sep=",")

#xt = paste(out_d,"00_Final_transect2009_env07_trssh.csv",sep="") #modified 201308
#uenv6 = read.table(xt,header=T,na.string="",sep=",")

#u.env1 = subset(env, select=c("transect","HI",
#                              "slope","cnpy_cov","moss",
#                              "litter","root","log","rock",
#                              "soil_stone","slope_pos","soil_water",
#                              "tRDA1","tRDA2","altitude",
#                              "tslope_pos","tslope",
#                              "c_BA","t2_BA","s_BA","all_BA",
#                              "den"))
#u.env1 = subset(uenv4, select=c("transect","HI","convex",
#                              "slope","cnpy_cov","moss",
#                              "litter","root","log","rock",
#                              "soil_stone","slope_pos","soil_water",
#                              "tRDA1","tRDA2","altitude",
#                              "tslope_pos","tslope","tHI","tcvex","liw1","tLCBD",
#                              "c_BA","t2_BA","s_BA","all_BA",
#                              "den"))

#idx.del = which(is.na(u.env1$soil_water))
#u.env = u.env1[-idx.del,]
#u.env = u.env[,-1]

##################### 看看保留所有樣區的效果
#u.env2 = subset(u.env1, select=c("transect",
#                                 "HI","convex","slope",
##                              "aspect","cnpy_cov","moss",
##                              "litter","root","log","rock",
##                              "soil_stone","slope_pos","soil_water",
#                              "tRDA1","tRDA2","altitude",
#                              "tslope_pos","tslope","tHI","tcvex",#"liw1","tLCBD",
#                              "c_BA","t2_BA","s_BA","all_BA",
#                              "den"))
#u.env2 = uenv5[,-c(1,13:16)] ## for one-line-transect:因每條線有個tslope_pos不同，level數不同
#u.env2 = data.frame(u.env2, uenv4$tslope_pos)
#colnames(u.env2)[dim(u.env2)[2]]="tslope_pos"

u.env2 = uenv5[,-1] ## for all transects

## us.env = terran[,c(4:7)]
u.xy  = uenv4[,c(6:7)]

# Spatial correlogram (based on Moran's I)
# ****************************************
# Search for neighbours of all points within a radius of 0.7 m
# and multiples (i.e., 0 to 0.7m, 0.7 to 1.4m and so on). The points do not
# form a connected graph at 0.7 m.
# windows(title="Linkage map")

plot.links(u.xy, thresh=2.1)
unb <- dnearneigh(as.matrix(u.xy), 0, 2.1)
idw <- nb2listw(unb) ########################## modify 2014/02
summary(unb)

par(mfcol=c(1,1))
plot(unb,u.xy,col="red",pch=20)
u.eigen=scores.listw(idw, echo=TRUE)
#vector number 5 corresponding to null eigenvalue is removed
barplot(u.eigen$values,main="Eigenvalues of spatial weighting matrix")

par(mfrow=c(3,3))
for(i in 1:9) # dim(u.eigen$vectors)[2])
s.value(u.xy,u.eigen$vectors[,i],addaxes=F, sub=paste("Eigenvector",i,"(",round(u.eigen$values[i],3),")") ,cleg=0,csub=2,neig=neig(list=unb))
uxy.moranI<-test.scores(u.eigen,idw,99)

#source(paste(rdir,"function_cy/mulvariate_01.R",sep=""))
# umem = create_MEM.01(idw, nrepet=99) ######### The same as following code
umem = u.eigen
colnames(u.eigen$vectors) <- paste("MEM", 1:ncol(u.eigen$vectors))
umem$vectors <- u.eigen$vectors[, uxy.moranI[,2]<0.05]

utst.rda <- rda(u.h.det, umem$vectors)
ut.rda.R2a<- RsquareAdj(utst.rda)$adj.r.squared
ut.rda.fw <- forward.sel(u.h.det,umem$vectors, adjR2thresh = ut.rda.R2a)

umemsel = sel_MEM.01 (umem, ut.rda.fw)

ut.varpart <- varpart(u.h.det, u.env.red, umemsel$broad, umemsel$fine)

showvarparts(2)
plot(ut.varpart)


# Correlogram of substrate density
#tden = t.env[,4]
#tden.cor = sp.correlogram(tnb, tden, order=10, method="I",
#                          zero.policy=TRUE)
#print(tden.cor, p.adj.method="holm")
# windows(title="Correlogram of tree density")
#plot(tden.cor, main="Correlogram of tree density")

# Mantel correlogram of the oribatid mite data
# ********************************************

# The species data are first detrended; see Section 7.3
# tc.h.det <- resid(lm(as.matrix(tc.h) ~ ., data=t.xy))
# tc.h.D1 <- dist(tc.h.det)
# (tc.corm <- mantel.correlog(tc.h.D1, XY=t.xy, nperm=99))
# summary(tc.corm)
# windows(title="Mantel correlogram of mite data")
# plot(tc.corm, main="Mantel correlogram of tree density")

# Number of classes
# tc.corm$n.class # or: mite.correlog[2]
# Break points
# tc.corm$break.pts # or: mite.correlog[3]


# PCNM analysis
# *************

# Detrending the mite data
# ************************
anova(rda(xres.h, u.xy))  # Result: significant trend
# Computation of linearly detrended mite data
#u.h.det <- resid(lm(as.matrix(xres.h) ~ ., data=u.xy))
u.h.det <- resid(lm(as.matrix(xres.h) ~ x, data=u.xy))

require(boot)
u.PCNM.quick <- quickPCNM(xres.h, u.xy)
# Constructing PCNM variables step by step
# ****************************************
# PCNM analysis of the oribatid mite data
# ***************************************

# 1a. Construct the matrix of PCNM variables step by step...
# ----------------------------------------------------------
uxy.d1 <- dist(u.xy)
uspan<- spantree(uxy.d1)
(udmin<- max(uspan$dist))
# Truncate the distance matrix
uxy.d1[uxy.d1 > udmin] <- 4*udmin
# PCoA of truncated distance matrix
#txy.PCoA <- cmdscale(txy.d1, k=nrow(t.xy)-1, eig=TRUE)
# Count the positive eigenvalues (PCNM with positive AND negative spatial
# correlation)
#(tnb.ev <- length(which(txy.PCoA$eig > 0.0000001)))
# Construct a data frame containing the PCNM variables
#tc.PCNM <- as.data.frame(txy.PCoA$points[1:nrow(t.xy), 1:tnb.ev])

# 1b. ... or construct the PCNM variables automatically
# -----------------------------------------------------

# library(PCNM) # If not already loaded
# windows(title="PCNM Moran's I")
# txy.d <- dist(t.xy)
par(mfcol=c(1,1))
u.PCNM.auto <- PCNM(uxy.d1)
summary(u.PCNM.auto)
# Plot the minimum spaning tree used to find the truncation distance
#windows(title="Minimum spanning tree")
# plot.spantree(mite.PCNM.auto$spanning, mite.xy)
plot(u.PCNM.auto$spanning,u.xy)
(udmin <- u.PCNM.auto$thresh) # Truncation distance
(unb.ev <- length(u.PCNM.auto$values)) # Number of eigenvalues

# Moran's I of the PCNM variables (in the first distance class,
# 0 to truncation threshold); also see figure generated by the PCNM() function
# (not reproduced here).

u.PCNM.auto$expected_Moran # Expected value of I, no spatial correlation
u.PCNM.auto$Moran_I

# Eigenfunctions with positive spatial correlation
(selu <- which(u.PCNM.auto$Moran_I$Positive == TRUE))
length(selu)  # Number of PCNM with I > E(I)
u.PCNM.pos <- as.data.frame(u.PCNM.auto$vectors)[,selu]

# 1c. ... or use vegan's function pcnm()
# --------------------------------------

### PUT AS COMMENTARY: PCNM produced above are used below ###
# mite.PCNM.vegan <- pcnm(dist(mite.xy))
# mite.PCNM <- as.data.frame(mite.PCNM.vegan$vectors)
# dmin <- mite.PCNM.vegan$threshold
# mite.PCNM <- as.data.frame(mite.PCNM.vegan$vectors)
# nb.ev <- length(which(mite.PCNM.vegan$values > 0.0000001))
# The eigenvectors obtained by this function are divided by the square root
# of their eigenvalue. This is not important for their use as spatial
# variables.
# Contrary to function PCNM(), vegan's pcnm() does not provide Moran's I,
# which must be computed separately if one chooses to retain only the
# eigenfunctions with positive spatial correlation.
### END PUT AS COMMENTARY

# 2. Run the global PCNM analysis on the *detrended* mite data
# ------------------------------------------------------------

u.PCNM.rda <- rda(u.h.det, u.PCNM.pos)
anova.cca(u.PCNM.rda)

# 3. Since the analysis is significant, compute the adjusted R2
#    and run a forward selection of the PCNM variables

(u.R2a <- RsquareAdj(u.PCNM.rda)$adj.r.squared)
(u.PCNM.fwd <- forward.sel(u.h.det, as.matrix(u.PCNM.pos),
                            adjR2thresh=u.R2a))
# According to the R2a criterion, if we retain PCNM 5 we get a model with
# a R2adj slightly higher than that of the complete model. This slight
# excess is not too serious, however.
(unb.sig.PCNM <- nrow(u.PCNM.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(u.PCNM.sign <- sort(u.PCNM.fwd[,2]))
# Write the significant PCNMs to a new object
u.PCNM.red <- u.PCNM.pos[,c(u.PCNM.sign)]

# 4. New PCNM analysis with 10 significant PCNM variables
#    Adjusted R-square after forward selection: R2adj=0.2713

u.PCNM.rda2<- rda(u.h.det ~ ., data=u.PCNM.red)
(u.fwd.R2a <- RsquareAdj(u.PCNM.rda2)$adj.r.squared)
anova.cca(u.PCNM.rda2)
u.ax.test <- anova.cca(u.PCNM.rda2, by="axis")
(unb.ax <- length(which(u.ax.test[,5] <= 0.05))) # Number of significant axes

#require(mvpart)
#us.part= mvpart(data.matrix(u.h.det) ~ ., u.PCNM.red, minauto = TRUE,
#                xv = "pick", size=6, xval = nrow(u.PCNM.red), xvmult = 100,
#                rsq = T, big.pts = T, pca = T, wgt.ave.pca = T)

# 5. Plot the two significant canonical axes
# mite.PCNM.axes <- scores.cca(mite.PCNM.rda2, choices=c(1,2), display="lc",
#   scaling=1)
u.PCNM.axes <- scores(u.PCNM.rda2, choices=c(1,2), display="lc",
                       scaling=1)
tt = data.frame(env$transect,u.PCNM.axes)
colnames(tt)=c("transect","uRDA1","uRDA2")
#xt = paste(out_d,"91_us_PCNM_RDA01.csv",sep="")
#write.table(tt,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")


#linex = data.frame(usel1$x,usel1$y,usel1$embele)
#colnames(linex)=c("x","y","z")

#coordinates(linex) = c("x", "y")
#coords = coordinates(linex)

#   if (dimn>5) {
#qnb = quadrat_neighbor.01.cy(coords)
#idw = inverse_dist_weight.01.cy(qnb,coords)

#idmat = listw2mat(idw)
#head(idmat,,digits=3)
## W_cont_el <- poly2nb(data, queen=T)
## W_cont_el_mat <- nb2listw(W_cont_el, style="W", zero.policy=TRUE)

#par(mfcol=c(1,1))
#bubble(linex,zcol="z",main=paste(usp[k],"coverage distribution"))

#windows(title="PCNM analysis of mite data")
par(mfrow=c(1,2),cex=0.9,cex.axis=0.75,cex.lab=0.75)
s.value(u.xy, u.PCNM.axes[,1],
         csub=0.45, csize=0.45,
         origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
s.value(u.xy, u.PCNM.axes[,2],
         csub=0.45, csize=0.45,
         origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

par(mfrow=c(2,2))
s.value(u.xy, scale(apply(xres.h,1,sum),center=T,scale=F),
        csub=0.65, csize=0.65,addaxes=T
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
s.value(u.xy, apply(u.h.det,1,sum),
        csub=0.65, csize=0.65,addaxes=T,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
s.value(u.xy, u.PCNM.axes[,1],
        csub=0.45, csize=0.45,add.plot=T,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
s.value(u.xy, u.PCNM.axes[,2],
        csub=0.45, csize=0.45,add.plot=T,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

# Interpreting the spatial variation: regression of the two significant
# canonical axes on the environmental variables

u.env2 =uenvc #2013.05 modified
shapiro.test(resid(lm(u.PCNM.axes[,1] ~ ., data=u.env2))) # Normality test
ux.PCNM.axis1.env <- lm(u.PCNM.axes[,1]~., data=u.env2)
summary(ux.PCNM.axis1.env)

shapiro.test(resid(lm(u.PCNM.axes[,2] ~ ., data=u.env2))) # Normality test
ux.PCNM.axis2.env <- lm(u.PCNM.axes[,2] ~ ., data=u.env2)
summary(ux.PCNM.axis2.env)

#ux.PCNM.axt = u.PCNM.axes[-idx.del,]

#shapiro.test(resid(lm(ux.PCNM.axt[,1] ~ ., data=u.env))) # Normality test
#ux.PCNM.axt1.env <- lm(ux.PCNM.axt[,1]~., data=u.env)
#summary(ux.PCNM.axt1.env)

#shapiro.test(resid(lm(ux.PCNM.axt[,2] ~ ., data=u.env))) # Normality test
#ux.PCNM.axt2.env <- lm(ux.PCNM.axt[,2] ~ ., data=u.env)
#summary(ux.PCNM.axt2.env)

u.PCNM.sp <- scores(u.PCNM.rda2, choices=c(1,2), display="species",
                     scaling=1)
#tc.PCNM.site <- scores(tc.PCNM.rda2, choices=c(1,2), display="sites",
#                     scaling=1)
t1 = which(rank(abs(u.PCNM.sp[,1]))>(nrow(u.PCNM.sp)-8))
t2 = which(rank(abs(u.PCNM.sp[,2]))>(nrow(u.PCNM.sp)-8))
tt = union(t1,t2)

# if you load (Xt) from spatial_PCNM_tree.R, the u.env1 is old
# please re-run env = load_env.01.cy(facV=F)
par(mfcol=c(1,1),mar=c(4,4,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
ordiplot.cy.01(u.PCNM.axes,env$upart,xlab="uRDA1",ylab="uRDA2")

#u.rda.env = envfit(u.PCNM.rda2,u.env1[,-c(1,4:12,21)])
u.rda.env = envfit(u.PCNM.rda2,u.env2)
#u.rda.env = envfit(u.PCNM.rda2,u.env1[,-c(1:13)])
arrows(0, 0, 0.021*(u.PCNM.sp[tt,1]), 0.021*(u.PCNM.sp[tt,2]), length=0, lty=1, col="black")
plot(u.rda.env,col="red",cex=0.7,adj=1,pos=2)
text(0.021*(u.PCNM.sp[tt,]),labels=rownames(u.PCNM.sp[tt,]),cex=0.65,adj=1,font=2)


require (stats)
## library(indicspecies)
## data(wetland) ## Loads species data
us.rda = data.frame(u.PCNM.axes)
rownames(us.rda)=env$transect

us.kmeans = kmeans(us.rda, centers=4)

par(mfcol=c(2,1),mar=c(2.2,1.8,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
ordiplot.cy.01(u.PCNM.axes,env$gap)
arrows(0, 0, 0.021*(u.PCNM.sp[tt,1]), 0.021*(u.PCNM.sp[tt,2]), length=0, lty=1, col="black")
text(0.021*(u.PCNM.sp[tt,]),labels=rownames(u.PCNM.sp[tt,]),cex=0.65)

ordiplot.cy.01(u.PCNM.axes,env$eclus)
arrows(0, 0, 0.021*(u.PCNM.sp[tt,1]), 0.021*(u.PCNM.sp[tt,2]), length=0, lty=1, col="black")
text(0.021*(u.PCNM.sp[tt,]),labels=rownames(u.PCNM.sp[tt,]),cex=0.65)

uaxes1 = ifelse(u.PCNM.axes[,1]>=0,1,0)
uaxes2 = ifelse(u.PCNM.axes[,2]>=0,1,0)

uclus = data.frame(env$transect,uaxes1,uaxes2,us.kmeans$cluster)
colnames(uclus)=c("transect","uaxes1","uaxes2","uclus")

#xt = paste(out_d,"91_PCNM_us_spatial_hetero_clus01.csv",sep="")
#write.table(uclus, xt, sep=",", col.names=T, row.names=F, na="")

######################### 畫圖
par(mfrow=c(2,2),mar=c(2.2,1.8,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
s.value(u.xy, u.PCNM.axes[,1],
        csub=0.45, csize=0.45,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
s.value(u.xy, u.PCNM.axes[,2],
        csub=0.45, csize=0.45,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

plot (u.xy$x, u.xy$y, type="p", col=env[,46],  pch=env[,46],
#        csub=0.35, csize=0.35,
      xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
plot (u.xy$x, u.xy$y, type="p", col=us.kmeans$cluster, pch=us.kmeans$cluster,
#        csub=0.35, csize=0.35,
      xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value


# Maps of the 10 significant PCNM variables
# ******************************************

#windows(title="10 PCNM variables - mites")
par(mfrow=c(3,5),mar=c(2.2,1.8,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
for(i in 1:ncol(u.PCNM.red)){
  sr.value(u.xy, u.PCNM.red[,i], sub=u.PCNM.sign[i],
           csub=0.65, csize=0.65,
           origin = c(60, 250), xlim=c(60,330),ylim=c(250,460))
}


# PCNM analysis of the mite data - broad scale
# ********************************************

u.PCNM.broad <- rda(u.h.det ~ ., data=u.PCNM.red[,c(1:19)]) #previos 1:18
anova.cca(u.PCNM.broad)
u.ax.broad <- anova.cca(u.PCNM.broad, by="axis")
unb.ax.broad <- length(which(u.ax.broad[,5] <= 0.05))
unb.ax.broad                        # Number of significant axes

# Plot of the two significant canonical axes
u.PCNMbroad.axes <- scores(u.PCNM.broad, choices=c(1,2),
                               display="lc", scaling=1)
# windows(title="PCNM analysis of mite data - broad scale")
par(mfrow=c(1,2))
s.value(u.xy, u.PCNMbroad.axes[,1],
        csub=0.7, csize=0.7,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460))
s.value(u.xy, u.PCNMbroad.axes[,2],
        csub=0.7, csize=0.7,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460))

# Interpreting spatial variation: regression of the two
# significant spatial canonical axes on the environmental variables

#u.PCNMbroad.ax1.env <- lm(u.PCNMbroad.axes[-idx.del,1] ~ ., data=u.env)
#summary(u.PCNMbroad.ax1.env)

#u.PCNMbroad.ax2.env <- lm(u.PCNMbroad.axes[-idx.del,2] ~ ., data=u.env)
#summary(u.PCNMbroad.ax2.env)

u.PCNMbroad.ax1.env <- lm(u.PCNMbroad.axes[,1] ~ ., data=u.env)
summary(u.PCNMbroad.ax1.env)

u.PCNMbroad.ax2.env <- lm(u.PCNMbroad.axes[,2] ~ ., data=u.env)
summary(u.PCNMbroad.ax2.env)


# PCNM analysis of the mite data - medium scale
# *********************************************

u.PCNM.med <- rda(u.h.det ~ ., data=u.PCNM.red[,c(20:43)]) #previous 19:37
anova.cca(u.PCNM.med)
u.ax.med <- anova.cca(u.PCNM.med, by="axis")
(unb.ax.med <- length(which(u.ax.med[,5] <= 0.05)))  # Number of significant axes

# Plot of the significant canonical axes (the second axis is
# marginally significant)
u.PCNMmed.axes <- scores(u.PCNM.med, choices=c(1,2), display="lc",
                         scaling=1)
#windows(title="PCNM analysis of mite data - medium scale")
par(mfrow=c(1,2))
s.value(u.xy, u.PCNMmed.axes[,1],
        csub=0.7, csize=0.7,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460))
s.value(u.xy, u.PCNMmed.axes[,2],
        csub=0.7, csize=0.7,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460))


# Interpreting spatial variation: regression of the significant
# spatial canonical axes on the environmental variables

#u.PCNMmed.ax1.env <- lm(u.PCNMmed.axes[-idx.del,1] ~ ., data=u.env)
#summary(u.PCNMmed.ax1.env)
#u.PCNMmed.ax2.env <- lm(u.PCNMmed.axes[-idx.del,2] ~ ., data=u.env)
#summary(u.PCNMmed.ax2.env)

u.PCNMmed.ax1.env <- lm(u.PCNMmed.axes[,1] ~ ., data=u.env)
summary(u.PCNMmed.ax1.env)
u.PCNMmed.ax2.env <- lm(u.PCNMmed.axes[,2] ~ ., data=u.env)
summary(u.PCNMmed.ax2.env)

# PCNM analysis of the mite data - fine scale
# *******************************************

u.PCNM.fine <- rda(u.h.det ~ ., data=u.PCNM.red[,c(44:56)]) #previous 38:56
anova.cca(u.PCNM.fine)
u.ax.fine <- anova.cca(u.PCNM.fine, by="axis")
(unb.ax.fine <- length(which(u.ax.fine[,5] <= 0.05))) # Number of significant axes

# Plot of the significant canonical axis
u.PCNMfine.axes <- scores(u.PCNM.fine, choices=c(1,2), display="lc", scaling=1)
#windows(title="PCNM analysis of mite data - fine scale")
#par(mfrow=c(1,2))
s.value(u.xy, u.PCNMfine.axes[,1],
        csub=0.7, csize=0.7,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460))
s.value(u.xy, u.PCNMfine.axes[,2],
        csub=0.7, csize=0.7,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460))


# Interpreting spatial variation: regression of the significant
# spatial canonical axis on the environmental variables

#u.PCNMfine.ax1.env <- lm(u.PCNMfine.axes[-idx.del,1] ~ ., data=u.env)
#summary(u.PCNMfine.ax1.env)

#u.PCNMfine.ax2.env <- lm(u.PCNMfine.axes[-idx.del,2] ~ ., data=u.env)
#summary(u.PCNMfine.ax2.env)

u.PCNMfine.ax1.env <- lm(u.PCNMfine.axes[,1] ~ ., data=u.env)
summary(u.PCNMfine.ax1.env)

u.PCNMfine.ax2.env <- lm(u.PCNMfine.axes[,2] ~ ., data=u.env)
summary(u.PCNMfine.ax2.env)

# Single-step PCNM analysis using function quickPCNM()
# ****************************************************

windows(title="One-step PCNM analysis of mite data")
mite.PCNM.quick <- quickPCNM(mite.h, mite.xy)
summary(mite.PCNM.quick)
mite.PCNM.quick[[2]]   # Eigenvalues
mite.PCNM.quick[[3]]   # Results of forward selection

# Extract and plot RDA results from a quickPCNM output (scaling 2)
# ****************************************************************

windows(title="Biplot of PCNM analysis result - scaling 2")
plot(mite.PCNM.quick$RDA, scaling=2)
sp.scores2 <- scores(mite.PCNM.quick$RDA,  choices=1:2, scaling=2, display="sp")
arrows(0, 0, sp.scores1[,1], sp.scores1[,2], length=0, lty=1, col="red")


# Mite - trend - environment - PCNM variation partitioning
# ********************************************************


# 2. Test and forward selection of environmental variables
# --------------------------------------------------------

# Recode environmental variables 3 to 5 into dummy binary variables
# substrate <- model.matrix(~mite.env[,3])[,-1]
# shrubs <- model.matrix(~mite.env[,4])[,-1]
# topo <- model.matrix(~mite.env[,5])[,-1]
# mite.env2 <- cbind(mite.env[,1:2], substrate, shrubs, topo)


# Forward selection of the environmental variables
# u.env.rda <- rda(xres.h[-idx.del,], u.env) ##### 201305 del rare sp

u.env = u.env2[,1:15] ## only topology # 201307
#u.env = u.env2
#u.env = uenvc
#u.env.rda <- rda(xres.h, u.env)
u.env.rda <- rda(u.h.det, u.env)
env.anova = anova.cca(u.env.rda)
(u.env.R2a <- RsquareAdj(u.env.rda)$adj.r.squared)
#u.env.fwd <- forward.sel(xres.h, u.env, adjR2thresh=u.env.R2a)
u.env.fwd <- forward.sel(u.h.det, u.env, adjR2thresh=u.env.R2a)
#,nperm=999)
u.env.sign <- sort(u.env.fwd$order)
u.env.red <- u.env[,c(u.env.sign)]
colnames(u.env.red)

#xt = paste(out_d,"01_u_env_fwdsel01.csv",sep="")
#write.table(u.env.fwd,xt,row.names=F, col.names=TRUE, na="", quote=FALSE, sep=",")

##########################
u.trx = u.env2[,c(16:25,28:36)] ## only tree factor # 201307 # skip tRDA1,2
#u.env = u.env2
#u.env = uenvc
#u.trx.rda <- rda(xres.h, u.trx)
u.trx.rda <- rda(u.h.det, u.trx)
trx.anova = anova.cca(u.trx.rda)
(u.trx.R2a <- RsquareAdj(u.trx.rda)$adj.r.squared)
u.trx.fwd <- forward.sel(u.h.det, u.trx, adjR2thresh=u.trx.R2a)

#require(vegan)
#u.step.trx <- ordistep(rda(u.h.det ~ 1, u.trx), scope=formula(rda(u.h.det ~ ., u.trx)),direction="forward",perm.max = 1000)


#u.trx.fwd <- forward.sel(xres.h, u.trx, adjR2thresh=u.trx.R2a)
#,nperm=999)
u.trx.sign <- sort(u.trx.fwd$order)
u.trx.red <- u.trx[,c(u.trx.sign)]
colnames(u.trx.red)

# 1. Test trend. If significant, forward selection of coordinates
# ---------------------------------------------------------------
# u.h.det <- resid(lm(as.matrix(xres.h) ~ ., data=u.xy))
u.XY.rda <- rda(xres.h, u.xy)
anova.cca(u.XY.rda)
(u.XY.R2a <- RsquareAdj(u.XY.rda)$adj.r.squared)
(u.XY.fwd <- forward.sel(xres.h, as.matrix(u.xy),
                         adjR2thresh=u.XY.R2a))
u.XY.sign <- sort(u.XY.fwd$order)
# Write the significant coordinates to a new object
#u.XY.red <- u.xy[-idx.del,c(u.XY.sign)]
u.XY.red <- u.xy[,c(u.XY.sign)]
##################### 看看保留所有樣區的效果
# u.XY2.red <- u.xy[,c(u.XY.sign)]

# 3. Test and forward selection of PCNM variables
# -----------------------------------------------

# Run the global PCNM analysis on the *undetrended* mite data
#u.undet.PCNM.rda <- rda(xres.h, u.PCNM.pos)
u.undet.PCNM.rda <- rda(u.h.det, u.PCNM.pos)
anova.cca(u.undet.PCNM.rda)
# Since the analysis is significant, compute the adjusted R2
#    and run a forward selection of the PCNM variables
(u.undet.PCNM.R2a <- RsquareAdj(u.undet.PCNM.rda)$adj.r.squared)
(u.undet.PCNM.fwd <- forward.sel(xres.h, as.matrix(u.PCNM.pos),
                                    adjR2thresh=u.undet.PCNM.R2a))
(unb.undet.sig.PCNM <- nrow(u.undet.PCNM.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(u.undet.PCNM.sign <- sort(u.undet.PCNM.fwd$order))
# Write the significant PCNMs to a new object
#u.undet.PCNM.red <- u.PCNM.pos[-idx.del,c(u.undet.PCNM.sign)]
u.undet.PCNM.red <- u.PCNM.pos[,c(u.undet.PCNM.sign)]
##################### 看看保留所有樣區的效果
# u.undet2.PCNM.red <- u.PCNM.pos[,c(u.undet.PCNM.sign)]

# 4. Arbitrary split of the significant PCNMs into broad and fine scale
# ---------------------------------------------------------------------
par(mfrow=c(3,5),mar=c(2.2,1.8,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
for(i in 1:ncol(u.undet.PCNM.red)){
  s.value(u.xy, u.undet.PCNM.red[,i], sub=u.undet.PCNM.sign[i],
          csub=0.25, csize=0.25,
          origin = c(60, 250), xlim=c(60,330),ylim=c(250,460))
}


############ it's wrong
## 201308 note
## i=21 200m/3 segments = 66.67m i<20 200/2 = 100m
## i=45 200m/5 =40m, while i=46 down to 6 segments 200m/6=33.33mm
## i=51 still 6 segments, while i=52, down to non-regular small segments

# Broad scale: PCNMs 1, 2, 3, 4, 6, 7, 8, 9, 10, 11
#uu.PCNM.broad <- u.undet.PCNM.red[,1:52]
uu.PCNM.broad <- u.undet.PCNM.red[,1:20]

#uu.PCNM.med = u.undet.PCNM.red[,21:45] ## before detrend
#uu.PCNM.med = u.undet.PCNM.red[,21:37]

#uu.PCNM.fine <- u.undet.PCNM.red[,46:57] ## before detrend
#uu.PCNM.fine <- u.undet.PCNM.red[,38:49]
uu.PCNM.fine <- u.undet.PCNM.red[,21:49]  ## two scale


# require (lattice)
# require (ggplot2)

# 5. Mite - environment - trend - PCNM variation partitioning
# -----------------------------------------------------------

#(u.varpart <- varpart(xres.h[-idx.del,], u.env.red, u.XY.red,
#                      uu.PCNM.broad, uu.PCNM.fine))

(u.varpart <- varpart(u.h.det, u.env.red, u.trx.red,
                      u.undet.PCNM.red))
#                      uu.PCNM.broad, uu.PCNM.fine))
par(mfrow=c(1,2),mar=c(2.2,1.8,0.1,0.1),cex=0.7,cex.axis=0.75,cex.lab=0.75)
showvarparts(3)
plot(u.varpart, digits=3)

##################### 看u.env(topo) u.trx(tree factor)的效果
#(u.varpart2<- varpart(xres.h, u.env.red, u.trx.red,
 #                     u.undet.PCNM.red, u.XY.red))
(u.varpart2<- varpart(u.h.det, u.env.red,
                      uu.PCNM.broad , uu.PCNM.fine, u.trx.red))

# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2),mar=c(2.2,1.8,0.1,0.1),cex=0.7,cex.axis=0.75,cex.lab=0.75)
showvarparts(4)
plot(u.varpart2, digits=3)

u.varpart2$part$indfract$Adj.R.square

R = xres[,c(2,4,7,8,1)] #only residet species
require(reshape)
source(paste(rdir,"function_cy/pivot_01.R",sep=""))
source(paste(rdir,"function_book/Legendre/beta.div.R",sep=""))

Pc = pivot.02.cy(R[,c(1,2,4,5)],1) # coverage pivot matrix
beta.us = beta.div(t(Pc), method="hellinger", sqrt.D=FALSE, samp=TRUE,nperm=999)


(u.betapart <- varpart(as.data.frame(beta.us$LCBD), u.env.red, u.XY.red,
                       u.undet.PCNM.red,u.trx.red))
par(mfrow=c(1,2),mar=c(2.2,1.8,0.1,0.1),cex=0.7,cex.axis=0.75,cex.lab=0.75)
showvarparts(4)
plot(u.betapart, digits=3)
#############################
par(mfcol=c(1,1),mar=c(0.5,0.5,0.1,0.1))
signif = which(beta.us$p.LCBD <= 0.05)  # Which are the significant LCDB indices?
nonsignif = which(beta.us$p.LCBD > 0.05)  # Which are the non-significant LCDB indices?
plot(u.xy, asp=1, type="n", xlab="x coordinates (m)", ylab="y coordinates (m)", main="Map of tree LCBD (red = significant indices)")
points(u.xy[nonsignif,], pch=21, col="white", bg="blue", cex=1000*beta.us$LCBD[nonsignif])
points(u.xy[signif,], pch=21, col="white", bg="red", cex=1000*beta.us$LCBD[signif])

## if you do beta.tree...

beta.adult = beta.div(ta1, method="hellinger", sqrt.D=FALSE, samp=TRUE, nperm=999)
beta.juven = beta.div(tj1, method="hellinger", sqrt.D=FALSE, samp=TRUE, nperm=999)

(ta.betapart <- varpart(beta.adult$LCBD, ta.env.red, ta.XY.red,
                       ta.undet.PCNM.broad, ta.undet.PCNM.fine))
# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2))
showvarparts(4)
plot(ta.betapart, digits=2, cex=0.8)


(tj.betapart <- varpart(beta.juven$LCBD, tj.env.red, tj.XY.red,
                       tj.undet.PCNM.broad, tj.undet.PCNM.fine))
# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2))
showvarparts(4)
plot(tj.betapart, digits=2, cex=0.8)

par(mfrow=c(3,1),mar=c(0.5,0.5,0.1,0.1))

signifa = which(beta.adult$p.LCBD <= 0.05)  # Which are the significant LCDB indices?
nonsignifa= which(beta.adult$p.LCBD > 0.05)  # Which are the non-significant LCDB indices?
plot(t.xy, asp=1, type="n", xlab="x coordinates (m)", ylab="y coordinates (m)", main="Map of tree LCBD (red = significant indices)")
points(t.xy[nonsignifa,], pch=21, col="white", bg="blue", cex=1000*beta.adult$LCBD[nonsignifa])
points(t.xy[signifa,], pch=21, col="white", bg="red", cex=1000*beta.adult$LCBD[signifa])

signifj = which(beta.juven$p.LCBD <= 0.05)  # Which are the significant LCDB indices?
nonsignifj= which(beta.juven$p.LCBD > 0.05)  # Which are the non-significant LCDB indices?
plot(t.xy, asp=1, type="n", xlab="x coordinates (m)", ylab="y coordinates (m)", main="Map of tree LCBD (red = significant indices)")
points(t.xy[nonsignifj,], pch=21, col="white", bg="blue", cex=1000*beta.juven$LCBD[nonsignifj])
points(t.xy[signifj,], pch=21, col="white", bg="red", cex=1000*beta.juven$LCBD[signifj])

signif = which(beta.us$p.LCBD <= 0.05)  # Which are the significant LCDB indices?
nonsignif = which(beta.us$p.LCBD > 0.05)  # Which are the non-significant LCDB indices?
plot(u.xy, asp=1, type="n", xlab="x coordinates (m)", ylab="y coordinates (m)", main="Map of tree LCBD (red = significant indices)")
points(u.xy[nonsignif,], pch=21, col="white", bg="blue", cex=1000*beta.us$LCBD[nonsignif])
points(u.xy[signif,], pch=21, col="white", bg="red", cex=1000*beta.us$LCBD[signif])

uz=data.frame(u.xy,round(beta.us$LCBD*10000)/10000)
colnames(uz)[3]="beta"

# 補上空白樣方
xt = data.frame(60,346,NA); colnames(xt)=colnames(uz) #"06_044",
uz = rbind(uz,xt); rownames(uz)[dim(uz)[1]]="06_044"
xt = data.frame(90,296,NA); colnames(xt)=colnames(uz) #"09_019"
uz = rbind(uz,xt); rownames(uz)[dim(uz)[1]]="09_019"
xt = data.frame(90,302,NA); colnames(xt)=colnames(uz) #"09_022",
uz = rbind(uz,xt); rownames(uz)[dim(uz)[1]]="09_022"
xt = data.frame(120,260,NA); colnames(xt)=colnames(uz) #"12_001",
uz = rbind(uz,xt); rownames(uz)[dim(uz)[1]]="12_001"
xt = data.frame(180,342,NA); colnames(xt)=colnames(uz) #"18_042",
uz = rbind(uz,xt); rownames(uz)[dim(uz)[1]]="18_042"
xt = data.frame(300,326,NA); colnames(xt)=colnames(uz) #"30_034",
uz = rbind(uz,xt); rownames(uz)[dim(uz)[1]]="30_034"

uz=uz[order(uz$x),]
uz=uz[order(uz$y),]
uzx=seq(60,330,30)
uzy=seq(260,458,2)

zmin = range(uz$beta,na.rm=T)[1]
zmax = range(uz$beta,na.rm=T)[2]
#zt   = uz$beta; zt[which(is.na(zt))]=0
uzz=matrix(uz$beta,ncol=length(uzy),nrow=length(uzx),byrow=F)

par(mfrow=c(1,1),mar=c(0.5,0.5,0.1,0.1))

signif = which(beta.us$p.LCBD <= 0.05)  # Which are the significant LCDB indices?
nonsignif = which(beta.us$p.LCBD > 0.05)  # Which are the non-significant LCDB indices?
plot(u.xy, asp=1, type="n", xlab="x coordinates (m)", ylab="y coordinates (m)", main="Map of tree LCBD (red = significant indices)")

contour(x=uzx, y=uzy, z=uzz, #levels=seq(from=zmin,to=zmax, by=0.00001),
        drawlabels=FALSE, lwd=0.75, nlevles=3,levels=pretty( range(uz$beta,na.rm=T,finite=T),3),
        na.omit=T,#   labels = seq(from=1930,to=2070, by=20),
        add=T, col="seashell3",labcex=0.6,method="edge",xlab="",ylab="")

points(u.xy[nonsignif,], pch=21, col="white", bg="blue", cex=1000*beta.us$LCBD[nonsignif])
points(u.xy[signif,], pch=21, col="white", bg="red", cex=1000*beta.us$LCBD[signif])



ua = rda(xres.h, u.undet.PCNM.red, cbind(u.env.red, u.XY.red))
anova.ua = anova.cca(ua)

(ua.R2a <- RsquareAdj(ua)$adj.r.squared)

(ua.fwd <- forward.sel(xres.h, as.matrix(ua$CCA$u),adjR2thresh=ua.R2a))
(ua.sig <- nrow(ua.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(ua.sign <- sort(ua.fwd$order))
# Write the significant PCNMs to a new object
ua.red <- ua$CCA$u[,c(ua.sign)]

## just trial test
(tt<- varpart(xres.h, u.env.red, u.XY.red,
                      ua.red,u.trx.red))
par(mfrow=c(1,2),mar=c(2.2,1.8,0.1,0.1),cex=0.7,cex.axis=0.75,cex.lab=0.75)
showvarparts(4)
plot(tt, digits=3)

##################### Note ua is not covaring with env, so
##################### rock, cnpy_cov, soil properties tend to less correlated with ua
##################### you should plot these properties on "uae", 2013/10

#### tmp to use u.undet.PCNM.rda
ua.axes <- scores(ua, choices=c(1,2), display="lc", scaling=1)
#cor.test(u.undet.PCNM.red[,1],ua.axes[,1])
########################################### PLOT
ua.sp <- scores(ua, choices=c(1,2), display="species",
                scaling=1)
#tc.PCNM.site <- scores(tc.PCNM.rda2, choices=c(1,2), display="sites",
#                     scaling=1)
t1 = which(rank(abs(ua.sp[,1]))>(nrow(ua.sp)-8))
t2 = which(rank(abs(ua.sp[,2]))>(nrow(ua.sp)-8))
tt = union(t1,t2)

#xt = paste(out_d,"01_env_hetero_clust03t13.csv",sep="") #201310,only by uRDA1
xt = paste(out_d,"01_env_hetero_clust_RN_relativeneigh.csv",sep="") #201310,only by uRDA1, change connection
newclus = read.table(xt,header=T,na.string="",sep=",")

# if you load (Xt) from spatial_PCNM_tree.R, the u.env1 is old
# please re-run env = load_env.01.cy(facV=F)
par(mfcol=c(1,1),mar=c(4,4,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
ordiplot.cy.01(ua.axes,newclus$Gr.6,xlab="uRDA1",ylab="uRDA2")

xt = paste(out_d,"00_Final_transect2009_env05_liw.csv",sep="")
#write.table(uenv4, xt, sep=",", col.names=T, row.names=F, na="")
uenv4= read.table(xt,header=T,na.string="",sep=",")

uenv.tmp1 = uenv4[,c(21:27,29)] #uenv4[,c(21,23,26,27,29)] #uenv4[,21:29]
uenv.tmp2 = u.env2[,c(14:15,17:18,23)] #u.env2[,12:23]

#u.rda.env = envfit(u.PCNM.rda2,u.env1[,-c(1,4:12,21)])
ua.env1 = envfit(ua,uenv.tmp1,na.rm=T)
ua.env2 = envfit(ua,uenv.tmp2)

tt1 = which(ua.env1$vectors$pvals<0.05)
uenv.tmp1=uenv.tmp1[,tt1]
ua.env1 = envfit(ua,uenv.tmp1,na.rm=T)

tt2 = which(ua.env2$vectors$pvals<0.05)
uenv.tmp2=uenv.tmp2[,tt2]
ua.env2 = envfit(ua,uenv.tmp2,na.rm=T)

#u.rda.env = envfit(u.PCNM.rda2,u.env1[,-c(1:13)])
arrows(0, 0, 0.015*(ua.sp[tt,1]), 0.015*(ua.sp[tt,2]), length=0, lty=1, col="black")
text(0.015*(ua.sp[tt,]),labels=rownames(ua.sp[tt,]),cex=0.65,adj=1,font=2)
plot(ua.env1,col="red",cex=0.7,adj=1,pos=4)
plot(ua.env2,col="blue",cex=0.7,adj=1,pos=2)

##################### Note ua is not covaring with env, so
##################### rock, cnpy_cov, soil properties tend to less correlated with ua
##################### you should plot these properties on "uae", 2013/10
##
### PLOT covary with env
#ua.axes <- scores(u.undet.PCNM.rda, choices=c(1,2), display="lc", scaling=1)
#uae = rda(xres.h, u.undet.PCNM.red)
#u.PCNM.rda2<- rda(u.h.det ~ ., data=u.PCNM.red)
uae = u.PCNM.rda2

anova.uae = anova.cca(uae)

(uae.R2a <- RsquareAdj(uae)$adj.r.squared)

(uae.fwd <- forward.sel(xres.h, as.matrix(uae$CCA$u),adjR2thresh=uae.R2a))
(uae.sig <- nrow(uae.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(uae.sign <- sort(uae.fwd$order))
# Write the significant PCNMs to a new object
uae.red <- uae$CCA$u[,c(uae.sign)]

uae.axes <- scores(uae, choices=c(1,2), display="lc", scaling=1)
uae.sp <- scores(uae, choices=c(1,2), display="species", scaling=1)
t1 = which(rank(abs(uae.sp[,1]))>(nrow(uae.sp)-8))
t2 = which(rank(abs(uae.sp[,2]))>(nrow(uae.sp)-8))
tt = union(t1,t2)

par(mfcol=c(1,1),mar=c(4,4,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
ordiplot.cy.01(uae.axes,newclus$Gr.6,xlab="uRDA1",ylab="uRDA2")

uenv.tmp1 = uenv4[,c(21:27,29)] #uenv4[,c(21,23,26,27,29)] #uenv4[,21:29]
uenv.tmp2 = u.env2[,c(14:15,17:18,23)] #u.env2[,12:23]

uae.env1 = envfit(uae,uenv.tmp1,na.rm=T)
uae.env2 = envfit(uae,uenv.tmp2)

tt1 = which(uae.env1$vectors$pvals<0.05)
uenv.tmp1=uenv.tmp1[,tt1]
uae.env1 = envfit(uae,uenv.tmp1,na.rm=T)

tt2 = which(uae.env2$vectors$pvals<0.05)
uenv.tmp2=uenv.tmp2[,tt2]
uae.env2 = envfit(uae,uenv.tmp2,na.rm=T)

#u.rda.env = envfit(u.PCNM.rda2,u.env1[,-c(1:13)])
arrows(0, 0, 0.015*(ua.sp[tt,1]), 0.015*(ua.sp[tt,2]), length=0, lty=1, col="black")
text(0.015*(ua.sp[tt,]),labels=rownames(ua.sp[tt,]),cex=0.65,adj=1,font=2)
plot(uae.env1,col="red",cex=0.7,adj=1,pos=2)
plot(uae.env2,col="blue",cex=0.7,adj=1,pos=2)

eu.axes = scores(u.env.rda, choices=c(1,2), display="lc", scaling=1)
tr.axes = scores(u.trx.rda, choices=c(1,2), display="lc", scaling=1)
###############
############### strange pattern of understory distributed at ua1 and uae2
#cor.test(ua.axes[,1],uae.axes[,2]) ################# they correlated... so..
#ut.ax = data.frame(cbind(ua.axes[,1],uae.axes[,2]))

#par(mfcol=c(1,1),mar=c(4,4,0.1,0.1),cex=0.9,cex.axis=0.75,cex.lab=0.75)
#ordiplot.cy.01(ut.ax,newclus$Gr.5,xlab="uRDA1",ylab="uRDA2")




##### Warning 201310 #####
## If you use the same Y in  RDA(Y, X) and RDA(Y, W), and if
## X and W could explain Y with similar part of variations
## then the site scores of RDA result should be also similar
## so, that's why eu.axes and tr.axes tell the same thing
## also why adult~ juven, then va~ vj show simliar patterns on RDA ordination
#############################################################


#t.xy.old =t.xy


par(mfcol=c(3,2),cex=0.9,cex.axis=0.75,cex.lab=0.75)

s.value(t.xy, va.axes[,1],
        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,460)) # ade4 function: s.value
#s.value(t.xy, va.axes[,2],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

#s.value(t.xy.old, vt.axes[,1],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
#s.value(t.xy.old, vt.axes[,2],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

#s.value(u.xy, eu.axes[,1],
#        csub=0.45, csize=0.45,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
#s.value(u.xy, eu.axes[,2],
#        csub=0.45, csize=0.45,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

#s.value(t.xy, vj.axes[,1],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

#s.value(t.xy, vj.axes[,2],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

vj4 <- scores(vj, choices=4, display="lc", scaling=1)

#s.value(t.xy, vj4,
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value


#s.value(u.xy, scale(uenv5$slope1,center=F), #tr.axes[,1],#scale(uenv5$c_BA,center=F),
#        csub=0.4, csize=0.4,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value


#s.value(u.xy, tr.axes[,2],#scale(uenv5$s_BA,center=F),
#        csub=0.45, csize=0.45,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

s.value(u.xy, ua.axes[,1],
        csub=0.45, csize=0.45,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
#s.value(u.xy, ua.axes[,2],
#       csub=0.45, csize=0.45,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

#s.value(u.xy, scale(uenv5$den,center=F),
#        csub=0.45, csize=0.45,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

## cor.test(uenv6$uRDA1,ua.axes[,1]) ## exactly the same, check 201310

#s.value(u.xy, scale(data.frame(xres.h)$miscfl,center=F),
#        csub=0.45, csize=0.45,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

s.value(u.xy, scale(data.frame(xres.h)$dryofo,center=F),
        csub=0.45, csize=0.45,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

#s.value(u.xy, scale(uenv5$tcvex1,center=F), #tr.axes[,1],#scale(uenv5$c_BA,center=F),
#        csub=0.5, csize=0.5,
#        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value

s.value(t.xy, va.axes[,1],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,460)) # ade4 function: s.value
s.value(u.xy, ua.axes[,1],
        csub=0.45, csize=0.45,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value
s.value(u.xy, scale(data.frame(xres.h)$miscfl,center=F),
        csub=0.45, csize=0.45,
        origin = c(50, 250), xlim=c(50,340),ylim=c(250,460)) # ade4 function: s.value


# Tests of the unique fractions [a], [b], [c] and [d]
# ***************************************************
# Fraction [a], pure environmental
tt = rda(xres.h[-idx.del,], u.env.red, cbind(u.XY.red, uu.PCNM.broad, uu.PCNM.fine))
(xt = RsquareAdj(tt)$adj.r.squared)
anova.cca(tt)
# (a.R2a <- RsquareAdj(u.env.rda)$adj.r.squared)
# R2 = 0.01653783
# Model: rda(X = xres.h[-idx.del, ], Y = u.env.red, Z = cbind(u.XY.red, uu.PCNM.broad, uu.PCNM.fine))
# Df     Var      F N.Perm Pr(>F)
# Model     17 0.02748 1.7568    199  0.005 **
# Residual 530 0.48774
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
#>
# Fraction [b], pure trend
anova.cca(rda(xres.h[-idx.del,], u.XY.red, cbind(u.env.red, uu.PCNM.broad, uu.PCNM.fine)))

# Model: rda(X = xres.h[-idx.del, ], Y = u.XY.red, Z = cbind(u.env.red, uu.PCNM.broad, uu.PCNM.fine))
# Df     Var      F N.Perm Pr(>F)
# Model      2 0.00257 1.3937    399  0.025 *
# Residual 530 0.48774
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# >
# Fraction [c], pure broad scale spatial
anova.cca(rda(xres.h[-idx.del,], uu.PCNM.broad, cbind(u.env.red, u.XY.red,
                                        uu.PCNM.fine)))
#Permutation test for rda under reduced model

# Model: rda(X = xres.h[-idx.del, ], Y = uu.PCNM.broad, Z = cbind(u.env.red, u.XY.red, uu.PCNM.fine))
# Df     Var      F N.Perm Pr(>F)
# Model     33 0.08709 2.8679    199  0.005 **
# Residual 530 0.48774
# ---
# Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
# >
# Fraction [d], pure fine scale spatial
anova.cca(rda(xres.h[-idx.del,], uu.PCNM.fine, cbind(u.env.red, u.XY.red,
                                       uu.PCNM.broad)))
# Model: rda(X = xres.h[-idx.del, ], Y = uu.PCNM.fine, Z = cbind(u.env.red, u.XY.red, uu.PCNM.broad))
# Df     Var      F N.Perm Pr(>F)
# Model     19 0.03483 1.9921    199  0.005 **
#   Residual 530 0.48774
# ---
#   Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
