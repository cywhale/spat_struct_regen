# SPATIAL ANALYSIS of adult tree, split adult and small tree #201307
# ******************************
library(NanhsiDT)

WD0=c("D:/","/media/cywhale/data/") # working in win or ubuntu
wi =1

rdir = paste0(WD0[wi],"R/")
dir1=paste0(rdir,"01paper_transect2009/")
dir2=paste0(WD0[wi],"backup/bak_paper/2012_transect_2009/")

raw_d  = paste(dir2,"raw_data/",sep="")
#raw_d  = paste(dir1,"raw_data/",sep="")
out_d  = paste(dir1,"analysis/",sep="")

library(ade4)  ## s.value, ...
library(vegan)   ## rda,...
library(packfor) ## forward.sel, ...
library(sp)
library(ape)
#library(packfor)  # https://r-forge.r-project.org/R/?group_id=195
library(spacemakeR)	# https://r-forge.r-project.org/R/?group_id=195
#library(ade4)
library(spdep)
#library(vegan)
library(AEM)	# https://r-forge.r-project.org/R/?group_id=195
library(PCNM)	# https://r-forge.r-project.org/R/?group_id=195
source(paste(rdir,"function_book/numerical_ecology/func/plot.links.R",sep=""))  # Function must be in working directory
source(paste(rdir,"function_book/numerical_ecology/func/sr.value.R",sep=""))    # Function must be in working directory
source(paste(rdir,"function_cy/plot_01.R",sep=""))
source(paste(rdir,"function_cy/eval_func_01.R",sep=""))

# ========================
##
#xt = paste(out_d,"90_PCNM__obj201202_03.rda",sep="")     #201307 divide adult,juvenile
#load(xt)
##
load("D:/R/01paper_ssn/NanhsiDT/debug/chklist_sciname_us2009_tree2006.RData")

# source("d:/ecology/R/01paper_transect2009/init_head_tree_01.R")
# source("d:/ecology/R/function_cy/quadrat_analysis_01.R")
#source(paste(rdir,"function_cy/plot_01.R",sep=""))

xt = paste(out_d,"00_Final_xtree.csv",sep="")
xtree= read.table(xt,header=T,na.string="",sep=",")
DBH= xtree$main_cir/pi
BA = pi*(DBH/200)^2 + xtree$sprout_ba/10000
td = data.frame(xtree[,c(1,12,7)],BA)

tt=which(xtree$layer=="S" & DBH<5) ## ?O?_?Ҽ{?u?d?Ulayer=="S"???????Y?i??
#tt=which(xtree$layer=="S")

adult = td[-tt,]; (dim(adult))
juven = td[tt,];  (dim(juven)) #juvenile

##################################################### just test adult and juvenile community
(count_different_elements.01.cy(xtree$spcode))
(count_different_elements.01.cy(adult$spcode))
(count_different_elements.01.cy(juven$spcode))
tapply(xtree$tag, xtree$species, count_different_elements.01.cy)
tapply(adult$tag, adult$species, count_different_elements.01.cy)
tapply(juven$tag, juven$species, count_different_elements.01.cy)
tt1=tapply(xtree$tag, xtree$tplot, count_different_elements.01.cy); (length(which(tt1==0)))
tt2=tapply(adult$tag, adult$tplot, count_different_elements.01.cy); (length(which(tt2==0)))
tt3=tapply(juven$tag, juven$tplot, count_different_elements.01.cy); (length(which(tt3==0)))
###############################################################################
#den = cbind(tapply(xtree$tag, xtree$tplot, count_different_elements.01.cy))/100
#den = data.frame(rownames(den),den)
#colnames(den)[1]="tplot"

##xt = paste(out_d,"02_tree_env_neighbor_ba.csv",sep="")
xt = paste(out_d,"00_Final_tree_env_cvex.csv",sep="")
tenv0= read.table(xt,header=T,na.string="",sep=",")
xt = paste(out_d,"02_tree_terran_newHI.csv",sep="")
tenv= read.table(xt,header=T,na.string="",sep=",")
#x=tenv$px*10 ; y = tenv$py*10
#terran = data.frame(tenv[,1],x,y,tenv[,c(4,6,7)])
#terran = data.frame(tenv[,1],x,y,tenv[,c(4:14)])
#colnames(terran)[1]="tplot"
#tenv1= data.frame(tenv[,c(3,18,19,14:17,20)])
#terran = merge(terran,den,by="tplot",all=T)
## xt = paste(out_d,"02_tree_terran_with_den.csv",sep="")
#xt = paste(out_d,"02_tree_terran_with_den02.csv",sep="")
##write.table(terran,xt,row.names=F, col.names=TRUE, na="0", quote=FALSE, sep=",")
#terran= read.table(xt,header=T,na.string="",sep=",")
#===========================================================
# tree community/pivot data
require(reshape)
source(paste(rdir,"function_cy/pivot_01.R",sep=""))
ta = t(pivot.02.cy(adult[,c(1,2,4,3)],1)) #
tj = t(pivot.02.cy(juven[,c(1,2,4,3)],1)) #
ta.o = data.frame(rownames(ta),ta) ## ?n???S?????ت??ˤ??ɦ^?h
tj.o = data.frame(rownames(tj),tj)
colnames(ta.o)[1]="tplot"
colnames(tj.o)[1]="tplot"

ta.o = merge(tenv,ta.o,by="tplot",all=T)
tj.o = merge(tenv,tj.o,by="tplot",all=T)
ta.o = ta.o[order(ta.o$y),]
ta.o = ta.o[order(ta.o$x),]
tj.o = tj.o[order(tj.o$y),]
tj.o = tj.o[order(tj.o$x),]
xt = paste(out_d,"02_adult_community_data.csv",sep="")
write.table(ta.o,xt,row.names=F, col.names=TRUE, na="0", quote=FALSE, sep=",")
ta = read.table(xt,header=T,na.string="",sep=",")

xt = paste(out_d,"02_juvenile_community_data.csv",sep="")
write.table(tj.o,xt,row.names=F, col.names=TRUE, na="0", quote=FALSE, sep=",")
tj = read.table(xt,header=T,na.string="",sep=",")

#########################
#####################?????D?`?p?? ta,tj ??tplot?ƦC???ǩMtenv???P
#########################


#terran = tc[,c(1:7)]
ta1 = ta[,15:dim(ta)[2]];rownames(ta1)=ta[,1]
tj1 = tj[,15:dim(tj)[2]];rownames(tj1)=tj[,1]
# Load the required packages
# head(tc)
ta.h  = decostand(ta1, "hellinger")
tj.h  = decostand(tj1, "hellinger")

#####################?????D?`?p?? ta,tj ??tplot?ƦC???ǩMtenv???P, now adjust!!
tenv=tenv[order(tenv$y),]
tenv=tenv[order(tenv$x),]
## check
match(tenv$tplot,ta$tplot)
match(tenv$tplot,tj$tplot)

#t.env = terran[,c(4:7)]
t.xy  = tenv[,c(2:3)] ##?????D?`?p?? ta,tj ??tplot?ƦC???ǩMtenv???P
t.xy.c= scale(t.xy, center=TRUE, scale=FALSE)

# The species data are first detrended; see Section 7.3
tt1 = lm(as.matrix(ta.h) ~ ., data=t.xy)
summary(tt1)
tt2 = lm(as.matrix(tj.h) ~ ., data=t.xy)
summary(tt2)

#ta.h.det <- resid(lm(as.matrix(ta.h) ~ ., data=t.xy))
#tj.h.det <- resid(lm(as.matrix(tj.h) ~ ., data=t.xy))

ta.h.det <- resid(lm(as.matrix(ta.h) ~ x, data=t.xy))
tj.h.det <- resid(lm(as.matrix(tj.h) ~ x, data=t.xy))

# $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# PCNM analysis
# *************

# Detrending the mite data
# ************************
#anova(rda(tc.h, t.xy))  # Result: significant trend
# Computation of linearly detrended mite data
#tc.h.det <- resid(lm(as.matrix(tc.h) ~ ., data=t.xy))

#par(mfrow=c(1,2))
#s.value(t.xy, scale(apply(tc.h,1,sum),center=T,scale=F),
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
#s.value(t.xy, apply(tc.h.det,1,sum),
#        csub=0.65, csize=0.65,
#origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

# Constructing PCNM variables step by step
# ****************************************
# PCNM analysis of the oribatid mite data
# ***************************************

# 1a. Construct the matrix of PCNM variables step by step...
# ----------------------------------------------------------
txy.d <- dist(t.xy)
tspan<- spantree(txy.d)
tdmin<- max(tspan$dist)
	# Truncate the distance matrix
txy.d[txy.d > tdmin] <- 4*tdmin
	# PCoA of truncated distance matrix
txy.PCoA <- cmdscale(txy.d, k=nrow(t.xy)-1, eig=TRUE)
	# Count the positive eigenvalues (PCNM with positive AND negative spatial
	# correlation)
(tnb.ev <- length(which(txy.PCoA$eig > 0.0000001)))
	# Construct a data frame containing the PCNM variables
tc.PCNM <- as.data.frame(txy.PCoA$points[1:nrow(t.xy), 1:tnb.ev])

# 1b. ... or construct the PCNM variables automatically
# -----------------------------------------------------

# library(PCNM) # If not already loaded
# windows(title="PCNM Moran's I")
#txy.d <- dist(t.xy)
tc.PCNM.auto <- PCNM(txy.d)#,thresh=14.143)
summary(tc.PCNM.auto)
# Plot the minimum spaning tree used to find the truncation distance
windows(title="Minimum spanning tree")
# plot.spantree(mite.PCNM.auto$spanning, mite.xy)
plot(tc.PCNM.auto$spanning,t.xy)
(tdmin <- tc.PCNM.auto$thresh) # Truncation distance
(tnb.ev <- length(tc.PCNM.auto$values)) # Number of eigenvalues

# Moran's I of the PCNM variables (in the first distance class,
# 0 to truncation threshold); also see figure generated by the PCNM() function
# (not reproduced here).

tc.PCNM.auto$expected_Moran # Expected value of I, no spatial correlation
tc.PCNM.auto$Moran_I

# Eigenfunctions with positive spatial correlation
(selt <- which(tc.PCNM.auto$Moran_I$Positive == TRUE))
length(selt)  # Number of PCNM with I > E(I)
tc.PCNM.pos <- as.data.frame(tc.PCNM.auto$vectors)[,selt]

# 1c. ... or use vegan's function pcnm()
# --------------------------------------

### PUT AS COMMENTARY: PCNM produced above are used below ###
# mite.PCNM.vegan <- pcnm(dist(mite.xy))
# mite.PCNM <- as.data.frame(mite.PCNM.vegan$vectors)
# dmin <- mite.PCNM.vegan$threshold
# mite.PCNM <- as.data.frame(mite.PCNM.vegan$vectors)
# nb.ev <- length(which(mite.PCNM.vegan$values > 0.0000001))
	# The eigenvectors obtained by this function are divided by the square root
	# of their eigenvalue. This is not important for their use as spatial
	# variables.
	# Contrary to function PCNM(), vegan's pcnm() does not provide Moran's I,
	# which must be computed separately if one chooses to retain only the
	# eigenfunctions with positive spatial correlation.
### END PUT AS COMMENTARY

# 2. Run the global PCNM analysis on the *detrended* mite data
# ------------------------------------------------------------

ta.PCNM.rda <- rda(ta.h.det, tc.PCNM.pos)
anova.cca(ta.PCNM.rda)
tj.PCNM.rda <- rda(tj.h.det, tc.PCNM.pos)
anova.cca(tj.PCNM.rda)

# 3. Since the analysis is significant, compute the adjusted R2
#    and run a forward selection of the PCNM variables

(ta.R2a <- RsquareAdj(ta.PCNM.rda)$adj.r.squared)
(ta.PCNM.fwd <- forward.sel(ta.h.det, as.matrix(tc.PCNM.pos),
  adjR2thresh=ta.R2a))
	# According to the R2a criterion, if we retain PCNM 5 we get a model with
	# a R2adj slightly higher than that of the complete model. This slight
	# excess is not too serious, however.
(ta.sig.PCNM <- nrow(ta.PCNM.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(ta.sign <- sort(ta.PCNM.fwd[,2]))
# Write the significant PCNMs to a new object
ta.PCNM.red <- tc.PCNM.pos[,c(ta.sign)]


(tj.R2a <- RsquareAdj(tj.PCNM.rda)$adj.r.squared)
(tj.PCNM.fwd <- forward.sel(tj.h.det, as.matrix(tc.PCNM.pos),
                            adjR2thresh=tj.R2a))
(tj.sig.PCNM <- nrow(tj.PCNM.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(tj.sign <- sort(tj.PCNM.fwd[,2]))
# Write the significant PCNMs to a new object
tj.PCNM.red <- tc.PCNM.pos[,c(tj.sign)]

# 4. New PCNM analysis with 10 significant PCNM variables
#    Adjusted R-square after forward selection: R2adj=0.2713

ta.PCNM.rda2 <- rda(ta.h.det ~ ., data=ta.PCNM.red)
(ta.fwd.R2a <- RsquareAdj(ta.PCNM.rda2)$adj.r.squared)
anova.cca(ta.PCNM.rda2)
ta.axes.test <- anova.cca(ta.PCNM.rda2, by="axis")
(tnb.a <- length(which(ta.axes.test[,5] <= 0.05))) # Number of significant axes

tj.PCNM.rda2 <- rda(tj.h.det ~ ., data=tj.PCNM.red)
(tj.fwd.R2a <- RsquareAdj(tj.PCNM.rda2)$adj.r.squared)
anova.cca(tj.PCNM.rda2)
tj.axes.test <- anova.cca(tj.PCNM.rda2, by="axis")
(tnb.j <- length(which(tj.axes.test[,5] <= 0.05))) # Number of significant axes

# 5. Plot the two significant canonical axes
# mite.PCNM.axes <- scores.cca(mite.PCNM.rda2, choices=c(1,2), display="lc",
#   scaling=1)
ta.PCNM.axes <- scores(ta.PCNM.rda2, choices=c(1,2), display="lc",
                       scaling=1)


ta.PCNM.sp <- scores(ta.PCNM.rda2, choices=c(1,2), display="species",
                     scaling=1)
#tc.PCNM.site <- scores(tc.PCNM.rda2, choices=c(1,2), display="sites",
#                     scaling=1)
at1 = which(rank(abs(ta.PCNM.sp[,1]))>(nrow(ta.PCNM.sp)-8))
at2 = which(rank(abs(ta.PCNM.sp[,2]))>(nrow(ta.PCNM.sp)-8))
att = union(at1,at2)
par(mfcol=c(1,1),mar=c(4,4,0.1,0.1))
#par(mfcol=c(1,1))
# ordiplot(tc.PCNM.sp,display="species")
# text(tc.PCNM.sp[tt,],labels=rownames(tc.PCNM.sp[tt,]),cex=0.65)

ordiplot.cy.01(ta.PCNM.axes,tenv0$tveg,xlab="tRDA1",ylab="tRDA2")
arrows(0, 0, 0.033*(ta.PCNM.sp[att,1]), 0.033*(ta.PCNM.sp[att,2]), length=0, lty=1, col="black")
text(0.033*(ta.PCNM.sp[att,]),labels=rownames(ta.PCNM.sp[att,]),cex=0.65,adj=1,font=2)


tj.PCNM.axes <- scores(tj.PCNM.rda2, choices=c(1,2), display="lc",
                       scaling=1)
tj.PCNM.sp <- scores(tj.PCNM.rda2, choices=c(1,2), display="species",
                     scaling=1)
#tc.PCNM.site <- scores(tc.PCNM.rda2, choices=c(1,2), display="sites",
#                     scaling=1)
jt1 = which(rank(abs(tj.PCNM.sp[,1]))>(nrow(tj.PCNM.sp)-8))
jt2 = which(rank(abs(tj.PCNM.sp[,2]))>(nrow(tj.PCNM.sp)-8))
jtt = union(jt1,jt2)
par(mfcol=c(1,1),mar=c(4,4,0.1,0.1))
#par(mfcol=c(1,1))
# ordiplot(tc.PCNM.sp,display="species")
# text(tc.PCNM.sp[tt,],labels=rownames(tc.PCNM.sp[tt,]),cex=0.65)

ordiplot.cy.01(tj.PCNM.axes,tenv0$tveg,xlab="tRDA1",ylab="tRDA2")
arrows(0, 0, 0.033*(tj.PCNM.sp[jtt,1]), 0.033*(tj.PCNM.sp[jtt,2]), length=0, lty=1, col="black")
text(0.033*(tj.PCNM.sp[jtt,]),labels=rownames(tj.PCNM.sp[jtt,]),cex=0.65,adj=1,font=2)


# Mite - trend - environment - PCNM variation partitioning
# ********************************************************

# 1. Test trend. If significant, forward selection of coordinates
# ---------------------------------------------------------------

ta.XY.rda <- rda(ta.h, t.xy)
anova.cca(ta.XY.rda)
(ta.XY.R2a <- RsquareAdj(ta.XY.rda)$adj.r.squared)
(ta.XY.fwd <- forward.sel(ta.h, as.matrix(t.xy),
  adjR2thresh=ta.XY.R2a))
ta.XY.sign <- sort(ta.XY.fwd$order)
# Write the significant coordinates to a new object
ta.XY.red <- t.xy[,c(ta.XY.sign)]

tj.XY.rda <- rda(tj.h, t.xy)
anova.cca(tj.XY.rda)
(tj.XY.R2a <- RsquareAdj(tj.XY.rda)$adj.r.squared)
(tj.XY.fwd <- forward.sel(tj.h, as.matrix(t.xy),
                          adjR2thresh=tj.XY.R2a))
tj.XY.sign <- sort(tj.XY.fwd$order)
# Write the significant coordinates to a new object
tj.XY.red <- t.xy[,c(tj.XY.sign)]

# 2. Test and forward selection of environmental variables
# --------------------------------------------------------

# Recode environmental variables 3 to 5 into dummy binary variables
# substrate <- model.matrix(~mite.env[,3])[,-1]
# shrubs <- model.matrix(~mite.env[,4])[,-1]
# topo <- model.matrix(~mite.env[,5])[,-1]
# mite.env2 <- cbind(mite.env[,1:2], substrate, shrubs, topo)

#t.env2 = t.env[,1:3]
###==================== modified 2013.04
t.env2 = tenv[4:dim(tenv)[2]]


# Forward selection of the environmental variables
ta.env.rda <- rda(ta.h.det, t.env2)
(ta.env.R2a <- RsquareAdj(ta.env.rda)$adj.r.squared)
ta.env.fwd <- forward.sel(ta.h.det, t.env2, adjR2thresh=ta.env.R2a)
# nperm=999) # original nperm=9999
ta.env.sign <- sort(ta.env.fwd$order)
ta.env.red <- t.env2[,c(ta.env.sign)]
colnames(ta.env.red)


tj.env.rda <- rda(tj.h.det, t.env2)
(tj.env.R2a <- RsquareAdj(tj.env.rda)$adj.r.squared)
tj.env.fwd <- forward.sel(tj.h.det, t.env2, adjR2thresh=tj.env.R2a)
# nperm=999) # original nperm=9999
tj.env.sign <- sort(tj.env.fwd$order)
tj.env.red <- t.env2[,c(tj.env.sign)]
colnames(tj.env.red)


tj.tax.rda <- rda(tj.h.det, va.red)
(tj.tax.R2a <- RsquareAdj(tj.tax.rda)$adj.r.squared)
tj.tax.fwd <- forward.sel(tj.h.det, va.red, adjR2thresh=tj.tax.R2a)
# nperm=999) # original nperm=9999
tj.tax.sign <- sort(tj.tax.fwd$order)
tj.tax.red <- va.red[,c(tj.tax.sign)]
colnames(tj.tax.red)

# 3. Test and forward selection of PCNM variables
# -----------------------------------------------

# Run the global PCNM analysis on the *undetrended* mite data
ta.undet.PCNM.rda <- rda(ta.h.det, tc.PCNM.pos)
anova.cca(ta.undet.PCNM.rda)
# Since the analysis is significant, compute the adjusted R2
#    and run a forward selection of the PCNM variables
(ta.undet.PCNM.R2a <- RsquareAdj(ta.undet.PCNM.rda)$adj.r.squared)
(ta.undet.PCNM.fwd <- forward.sel(ta.h.det, as.matrix(tc.PCNM.pos),
  adjR2thresh=ta.undet.PCNM.R2a))
(ta.sig.undet.PCNM <- nrow(ta.undet.PCNM.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(ta.undet.PCNM.sign <- sort(ta.undet.PCNM.fwd$order))
# Write the significant PCNMs to a new object

### ??? check original
ta.undet.PCNM.red <- tc.PCNM.pos[,c(ta.undet.PCNM.sign)] ##? ? check original

par(mfrow=c(3,5))
for(i in 1:ncol(ta.undet.PCNM.red)){
  sr.value(t.xy, ta.undet.PCNM.red[,i], sub=ta.undet.PCNM.sign[i], #xax = 1, yax = 1,
           csub=0.65, csize=0.65,
           origin = c(0, 250), xlim=c(0,350),ylim=c(250,500))
}

# Run the global PCNM analysis on the *undetrended* mite data
tj.undet.PCNM.rda <- rda(tj.h.det, tc.PCNM.pos)
anova.cca(tj.undet.PCNM.rda)
# Since the analysis is significant, compute the adjusted R2
#    and run a forward selection of the PCNM variables
(tj.undet.PCNM.R2a <- RsquareAdj(tj.undet.PCNM.rda)$adj.r.squared)
(tj.undet.PCNM.fwd <- forward.sel(tj.h.det, as.matrix(tc.PCNM.pos),
                                  adjR2thresh=tj.undet.PCNM.R2a))
(tj.sig.undet.PCNM <- nrow(tj.undet.PCNM.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(tj.undet.PCNM.sign <- sort(tj.undet.PCNM.fwd$order))
# Write the significant PCNMs to a new object

### ??? check original
tj.undet.PCNM.red <- tc.PCNM.pos[,c(tj.undet.PCNM.sign)] ##? ? check original

par(mfrow=c(3,5))
for(i in 1:ncol(tj.undet.PCNM.red)){
  sr.value(t.xy, tj.undet.PCNM.red[,i], sub=tj.undet.PCNM.sign[i], #xax = 1, yax = 1,
           csub=0.65, csize=0.65,
           origin = c(0, 250), xlim=c(0,350),ylim=c(250,500))
}



# 4. Arbitrary split of the significant PCNMs into broad and fine scale
# ---------------------------------------------------------------------
# Broad scale: PCNMs 1, 2, 3, 4, 6, 7, 8, 9, 10, 11
ta.undet.PCNM.broad <- ta.undet.PCNM.red[,c(1:18)]
ta.undet.PCNM.med <- ta.undet.PCNM.red[,c(19:41)]
# Fine scale: PCNMs 16, 20
ta.undet.PCNM.fine <- ta.undet.PCNM.red[,c(42:ncol(ta.undet.PCNM.red))]
#======================================================== tmporarily modified 2013
tj.undet.PCNM.broad <- tj.undet.PCNM.red[,c(1:60)]
# Fine scale: PCNMs 16, 20
tj.undet.PCNM.fine <- tj.undet.PCNM.red[,c(61:ncol(tj.undet.PCNM.red))]


#####################################
### Update 2013/11 for new Table1 in my paper
a.ax1.env <- lm(ta.PCNM.axes[,1] ~ ., data=t.env2)
summary(a.ax1.env)

a.ax1.env <- lm(ta.PCNM.axes[,1] ~ ., data=t.env2)
summary(a.ax1.env)









# 5. Mite - environment - trend - PCNM variation partitioning
# -----------------------------------------------------------

(ta.varpart <- varpart(ta.h, ta.env.red, #ta.XY.red,
                       ta.undet.PCNM.red))
                       #ta.undet.PCNM.broad, ta.undet.PCNM.fine))
# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2))
#showvarparts(4)
showvarparts(2)
plot(ta.varpart, digits=2, cex=0.75,main="adult trees")


(tj.varpart <- varpart(tj.h, tj.env.red, tj.tax.red, tj.undet.PCNM.red))#, tj.XY.red))
#                       tj.undet.PCNM.broad, tj.undet.PCNM.fine))
# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2),mai=c(0.5,0.5,0.2,0.2))
showvarparts(3)
plot(tj.varpart, digits=2, cex=0.7,main="juvenile trees")


### find pure spatial structure, without co-varying with ENV

va = rda(ta.h, ta.undet.PCNM.red, cbind(ta.env.red, ta.XY.red))
anova.va = anova.cca(va)


vj = rda(tj.h, tj.undet.PCNM.red, cbind(tj.env.red, tj.XY.red))
anova.vj = anova.cca(vj)

#===============================================
(va.R2a <- RsquareAdj(va)$adj.r.squared)

(va.fwd <- forward.sel(ta.h, as.matrix(va$CCA$u),adjR2thresh=va.R2a))
(va.sig <- nrow(va.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(va.sign <- sort(va.fwd$order))
# Write the significant PCNMs to a new object
va.red <- va$CCA$u[,c(va.sign)]

(vj.R2a <- RsquareAdj(vj)$adj.r.squared)

(vj.fwd <- forward.sel(tj.h, as.matrix(vj$CCA$u),adjR2thresh=vj.R2a))
(vj.sig <- nrow(vj.fwd)) # Number of signif. PCNM
# Identity of significant PCNMs in increasing order
(vj.sign <- sort(vj.fwd$order))
# Write the significant PCNMs to a new object
vj.red <- vj$CCA$u[,c(vj.sign)]

### check intersection if = 0 or not
(t2.varpart <- varpart(ta.h, ta.env.red, ta.XY.red,
                       va.red,vj.red))
# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2))
showvarparts(4)
plot(t2.varpart, digits=2, cex=0.8) ## really intersection =0

(t3.varpart <- varpart(tj.h, tj.env.red, tj.XY.red,
                       vj.red,va.red))
# windows(title="Mite - environment - PCNM variation partitioning",12,6)
par(mfrow=c(1,2))
showvarparts(4)
plot(t3.varpart, digits=2, cex=0.8) ## really intersection =0



# 5. Plot the two significant canonical axes
# mite.PCNM.axes <- scores.cca(mite.PCNM.rda2, choices=c(1,2), display="lc",
#   scaling=1)
va.axes <- scores(va, choices=c(1,2), display="lc", scaling=1)
va.sp <- scores(va, choices=c(1,2), display="species", scaling=1)

at1 = which(rank(abs(va.sp[,1]))>(nrow(va.sp)-8))
at2 = which(rank(abs(va.sp[,2]))>(nrow(va.sp)-8))
att = union(at1,at2)
par(mfcol=c(1,1),mar=c(4,4,0.1,0.1))

ordiplot.cy.01(va.axes,tenv0$tveg,xlab="aRDA1",ylab="aRDA2")
arrows(0, 0, 0.033*(va.sp[att,1]), 0.033*(va.sp[att,2]), length=0, lty=1, col="black")
text(0.033*(va.sp[att,]),labels=rownames(va.sp[att,]),cex=0.65,adj=1,font=2)

vj.axes <- scores(vj, choices=c(1,2), display="lc", scaling=1)
vj.sp <- scores(vj, choices=c(1,2), display="species", scaling=1)

jt1 = which(rank(abs(vj.sp[,1]))>(nrow(vj.sp)-8))
jt2 = which(rank(abs(vj.sp[,2]))>(nrow(vj.sp)-8))
jtt = union(jt1,jt2)
par(mfcol=c(1,1),mar=c(4,4,0.1,0.1))

ordiplot.cy.01(vj.axes,tenv0$tveg,xlab="jRDA1",ylab="jRDA2")
arrows(0, 0, 0.033*(vj.sp[jtt,1]), 0.033*(vj.sp[jtt,2]), length=0, lty=1, col="black")
text(0.033*(vj.sp[jtt,]),labels=rownames(vj.sp[jtt,]),cex=0.65,adj=1,font=2)

#ta.env.rda <- rda(ta.h, t.env2)
ev.axes = scores(ta.env.rda, choices=c(1,2), display="lc", scaling=1)

t.xy.old =t.xy


par(mfrow=c(3,2),cex=0.9,cex.axis=0.75,cex.lab=0.75)
#s.value(t.xy.old, vt.axes[,1],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
#s.value(t.xy, vt.axes[,2],
#        csub=0.65, csize=0.65,
#        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
s.value(t.xy, ev.axes[,1],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
s.value(t.xy, ev.axes[,2],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

s.value(t.xy, va.axes[,1],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
s.value(t.xy, va.axes[,2],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value

s.value(t.xy, -vj.axes[,1],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value
s.value(t.xy, vj.axes[,2],
        csub=0.65, csize=0.65,
        origin = c(0, 250), xlim=c(0,350),ylim=c(250,500)) # ade4 function: s.value


library("venneuler")
vd <- venneuler(c(A=0.3, B=0.3, C=1.1, "A&B"=0.1, "A&C"=0.2, "B&C"=0.1 ,"A&B&C"=0.1))
plot(vd)

